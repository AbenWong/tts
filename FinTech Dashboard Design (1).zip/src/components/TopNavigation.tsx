import { Button } from "./ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "./ui/dropdown-menu";
import { Sun, Moon, User, Settings, LogOut, Menu } from "lucide-react";

interface TopNavigationProps {
  isDark: boolean;
  onThemeToggle: () => void;
  dateFilter: string;
  onDateFilterChange: (value: string) => void;
  isMobile?: boolean;
  onMenuToggle?: () => void;
}

export function TopNavigation({ isDark, onThemeToggle, dateFilter, onDateFilterChange, isMobile = false, onMenuToggle }: TopNavigationProps) {
  return (
    <div className="h-[60px] bg-card border-b border-border flex items-center justify-between px-6 transition-colors duration-300">
      {/* Left side - Mobile Menu + Page Title */}
      <div className="flex items-center space-x-3">
        {isMobile && (
          <Button
            variant="ghost"
            size="icon"
            onClick={onMenuToggle}
            className="h-8 w-8"
          >
            <Menu className="h-5 w-5" />
          </Button>
        )}
        <h1 className="text-xl font-semibold text-foreground">Dashboard Overview</h1>
      </div>

      {/* Right side - Controls */}
      <div className="flex items-center gap-4">
        {/* Date Filter */}
        <Select value={dateFilter} onValueChange={onDateFilterChange}>
          <SelectTrigger className="w-32 relative">
            <SelectValue />
            <div className={`absolute bottom-0 left-0 h-0.5 bg-primary transition-all duration-200 ${
              dateFilter === 'today' ? 'w-1/3' : 
              dateFilter === 'week' ? 'w-1/3 translate-x-full' : 
              'w-1/3 translate-x-[200%]'
            }`} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="today">Today</SelectItem>
            <SelectItem value="week">This Week</SelectItem>
            <SelectItem value="month">This Month</SelectItem>
          </SelectContent>
        </Select>

        {/* Theme Toggle */}
        <Button
          variant="ghost"
          size="icon"
          onClick={onThemeToggle}
          className="transition-transform duration-150 hover:scale-95 active:scale-95"
        >
          {isDark ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
        </Button>

        {/* User Avatar with Dropdown */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="relative h-8 w-8 rounded-full">
              <Avatar className="h-8 w-8">
                <AvatarFallback className="bg-primary text-primary-foreground">
                  <User className="h-4 w-4" />
                </AvatarFallback>
              </Avatar>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-56" align="end" forceMount>
            <DropdownMenuItem>
              <Settings className="mr-2 h-4 w-4" />
              <span>Settings</span>
            </DropdownMenuItem>
            <DropdownMenuItem>
              <LogOut className="mr-2 h-4 w-4" />
              <span>Log out</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
}