import { Card, CardContent } from "../ui/card";
import { TrendingUp, TrendingDown } from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip } from 'recharts';

const investmentData = [
  { name: 'Digital Banking', value: 35, color: '#165DFF' },
  { name: 'Security', value: 25, color: '#36CFC9' },
  { name: 'Infrastructure', value: 20, color: '#52C41A' },
  { name: 'Analytics', value: 20, color: '#FAAD14' },
];

const mobileUsersData = [
  { month: 'Jan', users: 10.2 },
  { month: 'Feb', users: 10.8 },
  { month: 'Mar', users: 11.5 },
  { month: 'Apr', users: 12.1 },
  { month: 'May', users: 12.5 },
  { month: 'Jun', users: 13.2 },
];

export function StrategyValueModule() {
  return (
    <Card className="col-span-full h-[220px] hover:shadow-lg transition-all duration-300 hover:-translate-y-0.5">
      <CardContent className="p-6 h-full">
        <div className="flex h-full gap-6">
          {/* Left 25% - Core Indicators */}
          <div className="w-1/4 flex flex-col gap-4">
            {/* Total Tech Investment */}
            <div className="flex-1 bg-gradient-to-r from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 rounded-lg p-4 border border-primary/20">
              <p className="text-sm text-muted-foreground mb-1">Total Tech Investment</p>
              <div className="flex items-center gap-2">
                <span className="text-3xl font-bold text-foreground">$2.4B</span>
                <div className="flex items-center text-green-600">
                  <TrendingUp className="h-4 w-4" />
                  <span className="text-sm font-medium">12%</span>
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-1">YoY Growth</p>
            </div>

            {/* Tech Investment as % of Revenue */}
            <div className="flex-1 flex items-center gap-4">
              <div className="relative w-16 h-16">
                <svg className="w-16 h-16 transform -rotate-90" viewBox="0 0 64 64">
                  <circle cx="32" cy="32" r="28" stroke="currentColor" strokeWidth="4" fill="none" className="text-muted/20" />
                  <circle 
                    cx="32" 
                    cy="32" 
                    r="28" 
                    stroke="#165DFF" 
                    strokeWidth="4" 
                    fill="none"
                    strokeDasharray={`${2.4 * 176 / 4} 176`}
                    className="transition-all duration-500"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-lg font-bold text-foreground">2.4%</span>
                </div>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Tech Investment</p>
                <p className="text-sm text-muted-foreground">% of Revenue</p>
                <p className="text-xs text-green-600 mt-1">Within Target</p>
              </div>
            </div>
          </div>

          {/* Right 75% - Charts */}
          <div className="flex-1 flex gap-6">
            {/* Online/Digital Business Ratio */}
            <div className="flex-1">
              <p className="text-sm text-muted-foreground mb-4">Online/Digital Business Ratio</p>
              <div className="h-32 flex items-center justify-center">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={investmentData}
                      cx="50%"
                      cy="50%"
                      innerRadius={30}
                      outerRadius={50}
                      dataKey="value"
                    >
                      {investmentData.map((entry, index) => (
                        <Cell key={index} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip 
                      formatter={(value: number) => [`${value}%`, 'Share']}
                      labelStyle={{ color: 'var(--foreground)' }}
                      contentStyle={{ 
                        backgroundColor: 'var(--card)', 
                        border: '1px solid var(--border)',
                        borderRadius: '6px'
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Mobile Banking Users */}
            <div className="flex-1">
              <div className="flex items-center justify-between mb-4">
                <p className="text-sm text-muted-foreground">Mobile Banking Users</p>
                <div className="text-right">
                  <span className="text-2xl font-bold text-foreground">12.5M</span>
                  <p className="text-xs text-muted-foreground">Active Users</p>
                </div>
              </div>
              <div className="h-24">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={mobileUsersData}>
                    <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 10 }} />
                    <YAxis hide />
                    <Tooltip 
                      formatter={(value: number) => [`${value}M`, 'Users']}
                      labelStyle={{ color: 'var(--foreground)' }}
                      contentStyle={{ 
                        backgroundColor: 'var(--card)', 
                        border: '1px solid var(--border)',
                        borderRadius: '6px'
                      }}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="users" 
                      stroke="#52C41A" 
                      fill="#52C41A" 
                      fillOpacity={0.1}
                      strokeWidth={2}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}