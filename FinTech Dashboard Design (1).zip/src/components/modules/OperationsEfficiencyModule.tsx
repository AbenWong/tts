import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { AlertTriangle } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, LineChart, Line, Tooltip } from 'recharts';

const systemResponseData = [
  { system: 'Core Banking', time: 45, threshold: 50, status: 'good' },
  { system: 'Mobile App', time: 125, threshold: 100, status: 'warning' },
  { system: 'Web Portal', time: 78, threshold: 80, status: 'good' },
  { system: 'API Gateway', time: 35, threshold: 40, status: 'good' },
];

const tpsData = [
  { time: '10:00', tps: 12500 },
  { time: '10:05', tps: 13200 },
  { time: '10:10', tps: 12800 },
  { time: '10:15', tps: 14100 },
  { time: '10:20', tps: 13900 },
  { time: '10:25', tps: 14500 },
];

const resourceData = [
  { name: 'Computing', usage: 72, threshold: 80 },
  { name: 'Storage', usage: 65, threshold: 80 },
  { name: 'Network', usage: 83, threshold: 80 },
];

export function OperationsEfficiencyModule() {
  const [currentTPS, setCurrentTPS] = useState(14500);
  const [tpsHistory, setTpsHistory] = useState(tpsData);

  // Simulate real-time TPS updates
  useEffect(() => {
    const interval = setInterval(() => {
      const newTPS = 14000 + Math.floor(Math.random() * 1000);
      setCurrentTPS(newTPS);
      
      // Update history
      setTpsHistory(prev => {
        const newHistory = [...prev];
        newHistory.shift(); // Remove first item
        const now = new Date();
        const timeString = `${now.getHours()}:${now.getMinutes().toString().padStart(2, '0')}`;
        newHistory.push({ time: timeString, tps: newTPS });
        return newHistory;
      });
    }, 3000); // Update every 3 seconds

    return () => clearInterval(interval);
  }, []);
  return (
    <Card className="h-[380px] hover:shadow-lg transition-all duration-300 hover:-translate-y-0.5">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg">Operations & Efficiency</CardTitle>
      </CardHeader>
      <CardContent className="p-6 pt-0">
        <div className="flex gap-6 h-full">
          {/* Left 30% - Indicators */}
          <div className="w-[30%] space-y-4">
            {/* System Availability */}
            <div className="bg-gradient-to-r from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20 rounded-lg p-4">
              <p className="text-xs text-muted-foreground mb-1">System Availability</p>
              <span className="text-2xl font-bold text-green-600">99.97%</span>
              <p className="text-xs text-muted-foreground mt-1">Last 30 days</p>
            </div>

            {/* TPS Indicator */}
            <div className="bg-muted/30 rounded-lg p-4 transition-all duration-200">
              <p className="text-xs text-muted-foreground mb-1">Current TPS</p>
              <span className="text-xl font-bold text-foreground transition-all duration-200">
                {currentTPS.toLocaleString()}
              </span>
              <p className="text-xs text-green-600 mt-1">
                {currentTPS > 14200 ? '+' : ''}{Math.round((currentTPS - 14200) / 14200 * 100)}% from avg
              </p>
            </div>

            {/* Resource Utilization Gauges */}
            <div>
              <p className="text-xs font-medium mb-3">Resource Utilization</p>
              <div className="space-y-3">
                {resourceData.map((resource, index) => (
                  <div key={index} className="space-y-1">
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-muted-foreground">{resource.name}</span>
                      <span className={`text-xs font-medium ${
                        resource.usage > resource.threshold ? 'text-red-500' : 'text-foreground'
                      }`}>
                        {resource.usage}%
                      </span>
                    </div>
                    <div className="relative w-full bg-muted rounded-full h-2">
                      <div 
                        className={`h-2 rounded-full transition-all duration-500 ${
                          resource.usage > resource.threshold ? 'bg-red-500' : 'bg-primary'
                        }`}
                        style={{ width: `${resource.usage}%` }}
                      />
                      {/* Threshold marker */}
                      <div 
                        className="absolute top-0 h-2 w-0.5 bg-orange-400"
                        style={{ left: `${resource.threshold}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right 70% - Charts */}
          <div className="flex-1 space-y-6">
            {/* System Response Time */}
            <div>
              <p className="text-sm font-medium mb-3">Key Application Response Time (ms)</p>
              <div className="h-24">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={systemResponseData}>
                    <XAxis 
                      dataKey="system" 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fontSize: 10 }}
                    />
                    <YAxis hide />
                    <Tooltip 
                      formatter={(value: number) => [`${value}ms`, 'Response Time']}
                      labelStyle={{ color: 'var(--foreground)' }}
                      contentStyle={{ 
                        backgroundColor: 'var(--card)', 
                        border: '1px solid var(--border)',
                        borderRadius: '6px'
                      }}
                    />
                    <Bar 
                      dataKey="time" 
                      fill="#165DFF"
                      radius={[2, 2, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              {/* Warning indicators */}
              <div className="flex justify-center mt-2">
                {systemResponseData.map((system, index) => (
                  system.status === 'warning' && (
                    <div key={index} className="flex items-center gap-1 text-red-500">
                      <AlertTriangle className="h-3 w-3" />
                      <span className="text-xs">{system.system} exceeds threshold</span>
                    </div>
                  )
                ))}
              </div>
            </div>

            {/* TPS Trend */}
            <div>
              <p className="text-sm font-medium mb-3">TPS Real-time Trend</p>
              <div className="h-20">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={tpsHistory}>
                    <XAxis 
                      dataKey="time" 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fontSize: 10 }}
                    />
                    <YAxis hide />
                    <Tooltip 
                      formatter={(value: number) => [`${value.toLocaleString()}`, 'TPS']}
                      labelStyle={{ color: 'var(--foreground)' }}
                      contentStyle={{ 
                        backgroundColor: 'var(--card)', 
                        border: '1px solid var(--border)',
                        borderRadius: '6px'
                      }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="tps" 
                      stroke="#36CFC9" 
                      strokeWidth={2}
                      dot={{ r: 2 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}