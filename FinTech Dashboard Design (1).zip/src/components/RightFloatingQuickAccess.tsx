import { useState } from "react";
import { cn } from "./ui/utils";
import { Button } from "./ui/button";
import { Menu, X } from "lucide-react";

interface RightFloatingQuickAccessProps {
  onModuleJump: (moduleId: string) => void;
}

const moduleItems = [
  { id: "strategy-value", label: "Strategy Value", number: "1" },
  { id: "finance-budget", label: "Finance Budget", number: "2" },
  { id: "operations-efficiency", label: "Operations & Efficiency", number: "3" },
  { id: "risk-security", label: "Risk & Security", number: "4" },
  { id: "talent-innovation", label: "Talent & Innovation", number: "5" },
];

export function RightFloatingQuickAccess({ onModuleJump }: RightFloatingQuickAccessProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  const handleModuleClick = (moduleId: string) => {
    onModuleJump(moduleId);
    setIsExpanded(false);
  };

  const toggleExpanded = () => {
    setIsExpanded(!isExpanded);
  };

  return (
    <div className="fixed right-6 top-1/2 -translate-y-1/2 z-50">
      {/* Expanded Panel */}
      {isExpanded && (
        <div className={cn(
          "absolute right-16 top-1/2 -translate-y-1/2",
          "w-50 bg-card border border-border rounded-xl",
          "shadow-[0_4px_20px_rgba(0,0,0,0.15)] dark:shadow-[0_4px_20px_rgba(0,0,0,0.3)]",
          "transition-all duration-250 ease-out animate-slide-in-right"
        )}>
          <div className="p-3">
            <div className="space-y-1">
              {moduleItems.map((item) => (
                <Button
                  key={item.id}
                  variant="ghost"
                  className={cn(
                    "w-full h-11 px-3 justify-start",
                    "hover:bg-blue-50 dark:hover:bg-blue-950/30 rounded-lg",
                    "transition-all duration-200 group"
                  )}
                  onClick={() => handleModuleClick(item.id)}
                >
                  <span className="text-primary font-medium mr-2 text-sm">{item.number}</span>
                  <span className="text-sm text-foreground group-hover:text-primary">
                    {item.label}
                  </span>
                </Button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Floating Button */}
      <Button
        size="icon"
        onClick={toggleExpanded}
        className={cn(
          "w-14 h-14 rounded-full transition-all duration-200",
          "bg-primary hover:bg-primary/90 text-primary-foreground",
          "border-2 border-primary-foreground/10",
          "shadow-[0_4px_12px_rgba(22,93,255,0.3)] hover:shadow-[0_6px_16px_rgba(22,93,255,0.4)]",
          isExpanded ? "scale-100" : "hover:scale-110 active:scale-95"
        )}
      >
        {isExpanded ? (
          <X className="h-6 w-6 transition-transform duration-200" />
        ) : (
          <Menu className="h-6 w-6 transition-transform duration-200" />
        )}
      </Button>
    </div>
  );
}