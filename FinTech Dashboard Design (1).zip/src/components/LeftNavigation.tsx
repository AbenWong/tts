import { cn } from "./ui/utils";
import { Button } from "./ui/button";
import { 
  LayoutDashboard, 
  DollarSign, 
  Activity, 
  Shield, 
  Users, 
  FolderKanban,
  ChevronLeft,
  ChevronRight,
  TrendingUp
} from "lucide-react";

interface LeftNavigationProps {
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  isMobile?: boolean;
}

const navigationItems = [
  { icon: LayoutDashboard, label: "Overview", active: true },
  { icon: TrendingUp, label: "Financial Details", active: false },
  { icon: Activity, label: "Operational Analytics", active: false },
  { icon: Shield, label: "Risk Management", active: false },
  { icon: Users, label: "Talent Insights", active: false },
  { icon: FolderKanban, label: "Project Tracking", active: false },
];

export function LeftNavigation({ isCollapsed, onToggleCollapse, isMobile = false }: LeftNavigationProps) {
  return (
    <div className={cn(
      "fixed left-0 top-0 h-screen bg-background border-r border-border transition-all duration-300 ease-out flex flex-col z-40",
      isMobile ? (isCollapsed ? "-translate-x-full" : "w-60") : (isCollapsed ? "w-20" : "w-60")
    )}>
      {/* Top Area - Logo & Title */}
      <div className="h-[10vh] min-h-[80px] flex items-center px-4 border-b border-border">
        {isCollapsed ? (
          <div className="w-full flex justify-center">
            <div className="w-6 h-6 bg-primary rounded flex items-center justify-center">
              <div className="w-3 h-3 bg-primary-foreground rounded-sm" />
            </div>
          </div>
        ) : (
          <div className="flex items-center space-x-2">
            <div className="w-6 h-6 bg-primary rounded flex items-center justify-center">
              <div className="w-3 h-3 bg-primary-foreground rounded-sm" />
            </div>
            <span className="text-primary font-bold">FinTech Dashboard</span>
          </div>
        )}
      </div>

      {/* Middle Navigation Area */}
      <div className="flex-1 flex items-center px-2">
        <nav className="w-full space-y-2">
          {navigationItems.map((item, index) => (
            <Button
              key={index}
              variant={item.active ? "default" : "ghost"}
              className={cn(
                "w-full h-12 transition-all duration-200 relative",
                isCollapsed ? "px-3 justify-center" : "px-4 justify-start",
                item.active
                  ? "bg-blue-50 dark:bg-blue-950/30 text-primary hover:bg-blue-50 dark:hover:bg-blue-950/30"
                  : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
              )}
            >
              {/* Active indicator */}
              {item.active && (
                <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-4 bg-primary rounded-r" />
              )}
              
              <item.icon className={cn("h-6 w-6", !isCollapsed && "mr-3")} />
              
              {!isCollapsed && (
                <span className="text-sm">{item.label}</span>
              )}
            </Button>
          ))}
        </nav>
      </div>

      {/* Bottom Collapse Control Area */}
      <div className="h-[15vh] min-h-[100px] flex items-center justify-center px-4 border-t border-border">
        <Button
          variant="outline"
          size="icon"
          onClick={onToggleCollapse}
          className={cn(
            "w-9 h-9 rounded-full border-2 bg-muted hover:bg-accent transition-all duration-200",
            "hover:scale-105 active:scale-95"
          )}
        >
          {isCollapsed ? (
            <ChevronRight className="h-4 w-4 text-primary" />
          ) : (
            <ChevronLeft className="h-4 w-4 text-primary" />
          )}
        </Button>
      </div>
    </div>
  );
}