import { useState, useEffect, useRef } from "react";
import { TopNavigation } from "./TopNavigation";
import { LeftNavigation } from "./LeftNavigation";
import { RightFloatingQuickAccess } from "./RightFloatingQuickAccess";
import { StrategyValueModule } from "./modules/StrategyValueModule";
import { FinanceBudgetModule } from "./modules/FinanceBudgetModule";
import { OperationsEfficiencyModule } from "./modules/OperationsEfficiencyModule";
import { RiskSecurityModule } from "./modules/RiskSecurityModule";
import { TalentInnovationModule } from "./modules/TalentInnovationModule";
import { ProjectsProgramsModule } from "./modules/ProjectsProgramsModule";
import { cn } from "./ui/utils";

export function DashboardLayout() {
  const [isDark, setIsDark] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('theme') === 'dark' || 
             (!localStorage.getItem('theme') && window.matchMedia('(prefers-color-scheme: dark)').matches);
    }
    return false;
  });
  const [isLeftNavCollapsed, setIsLeftNavCollapsed] = useState(false);
  const [dateFilter, setDateFilter] = useState("month");
  const [isMobile, setIsMobile] = useState(false);
  const [highlightedModule, setHighlightedModule] = useState<string | null>(null);

  // Refs for module scrolling
  const moduleRefs = useRef<{ [key: string]: HTMLDivElement | null }>({});

  // Check for mobile on mount and resize
  useEffect(() => {
    const checkMobile = () => {
      const mobile = window.innerWidth <= 1023;
      setIsMobile(mobile);
      if (mobile) {
        setIsLeftNavCollapsed(true);
      }
    };

    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Apply theme on mount
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, []);

  // Theme toggle
  const toggleTheme = () => {
    const newTheme = !isDark;
    setIsDark(newTheme);
    
    if (newTheme) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  };

  // Left navigation toggle
  const toggleLeftNavigation = () => {
    setIsLeftNavCollapsed(!isLeftNavCollapsed);
  };

  // Module jump functionality
  const handleModuleJump = (moduleId: string) => {
    const element = moduleRefs.current[moduleId];
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
      
      // Highlight the module temporarily
      setHighlightedModule(moduleId);
      setTimeout(() => setHighlightedModule(null), 2000);
    }
  };

  // Helper to set module refs
  const setModuleRef = (moduleId: string) => (ref: HTMLDivElement | null) => {
    moduleRefs.current[moduleId] = ref;
  };

  return (
    <div className={cn("min-h-screen bg-background transition-colors duration-300", isDark && "dark")}>
      {/* Mobile Overlay */}
      {isMobile && !isLeftNavCollapsed && (
        <div 
          className="fixed inset-0 bg-black/50 z-30 transition-opacity duration-300"
          onClick={toggleLeftNavigation}
        />
      )}

      {/* Left Navigation */}
      <LeftNavigation 
        isCollapsed={isLeftNavCollapsed}
        onToggleCollapse={toggleLeftNavigation}
        isMobile={isMobile}
      />

      {/* Right Floating Quick Access */}
      <RightFloatingQuickAccess onModuleJump={handleModuleJump} />

      {/* Main Content Area */}
      <div className={cn(
        "min-h-screen transition-all duration-300 ease-out",
        isMobile ? "ml-0" : (isLeftNavCollapsed ? "ml-20" : "ml-60")
      )}>
        {/* Top Navigation */}
        <TopNavigation
          isDark={isDark}
          onThemeToggle={toggleTheme}
          dateFilter={dateFilter}
          onDateFilterChange={setDateFilter}
          isMobile={isMobile}
          onMenuToggle={toggleLeftNavigation}
        />

        {/* Dashboard Content */}
        <main className="max-w-[1920px] mx-auto w-full">
          <div className="p-6 space-y-6 animate-fade-in-up">
            {/* Strategy & Value Module */}
            <div 
              ref={setModuleRef("strategy-value")}
              className={cn(
                "w-full transition-all duration-300",
                highlightedModule === "strategy-value" && "ring-2 ring-primary ring-opacity-50 rounded-lg"
              )}
            >
              <div className={cn(
                "relative",
                highlightedModule === "strategy-value" && "animate-pulse"
              )}>
                <div className="flex items-center mb-4">
                  <div className="w-1 h-4 bg-primary rounded mr-2" />
                  <h2 className={cn(
                    "text-lg font-bold transition-colors duration-300",
                    highlightedModule === "strategy-value" ? "text-primary" : "text-primary"
                  )}>
                    Strategy & Value
                  </h2>
                </div>
                <StrategyValueModule />
              </div>
            </div>

            {/* Finance & Budget Module */}
            <div 
              ref={setModuleRef("finance-budget")}
              className={cn(
                "w-full transition-all duration-300",
                highlightedModule === "finance-budget" && "ring-2 ring-primary ring-opacity-50 rounded-lg"
              )}
            >
              <div className={cn(
                "relative",
                highlightedModule === "finance-budget" && "animate-pulse"
              )}>
                <div className="flex items-center mb-4">
                  <div className="w-1 h-4 bg-primary rounded mr-2" />
                  <h2 className={cn(
                    "text-lg font-bold transition-colors duration-300",
                    highlightedModule === "finance-budget" ? "text-primary" : "text-primary"
                  )}>
                    Finance & Budget
                  </h2>
                </div>
                <FinanceBudgetModule />
              </div>
            </div>

            {/* Operations & Efficiency Module */}
            <div 
              ref={setModuleRef("operations-efficiency")}
              className={cn(
                "w-full transition-all duration-300",
                highlightedModule === "operations-efficiency" && "ring-2 ring-primary ring-opacity-50 rounded-lg"
              )}
            >
              <div className={cn(
                "relative",
                highlightedModule === "operations-efficiency" && "animate-pulse"
              )}>
                <div className="flex items-center mb-4">
                  <div className="w-1 h-4 bg-primary rounded mr-2" />
                  <h2 className={cn(
                    "text-lg font-bold transition-colors duration-300",
                    highlightedModule === "operations-efficiency" ? "text-primary" : "text-primary"
                  )}>
                    Operations & Efficiency
                  </h2>
                </div>
                <OperationsEfficiencyModule />
              </div>
            </div>

            {/* Risk & Security Module */}
            <div 
              ref={setModuleRef("risk-security")}
              className={cn(
                "w-full transition-all duration-300",
                highlightedModule === "risk-security" && "ring-2 ring-primary ring-opacity-50 rounded-lg"
              )}
            >
              <div className={cn(
                "relative",
                highlightedModule === "risk-security" && "animate-pulse"
              )}>
                <div className="flex items-center mb-4">
                  <div className="w-1 h-4 bg-primary rounded mr-2" />
                  <h2 className={cn(
                    "text-lg font-bold transition-colors duration-300",
                    highlightedModule === "risk-security" ? "text-primary" : "text-primary"
                  )}>
                    Risk & Security
                  </h2>
                </div>
                <RiskSecurityModule />
              </div>
            </div>

            {/* Talent & Innovation Module */}
            <div 
              ref={setModuleRef("talent-innovation")}
              className={cn(
                "w-full transition-all duration-300",
                highlightedModule === "talent-innovation" && "ring-2 ring-primary ring-opacity-50 rounded-lg"
              )}
            >
              <div className={cn(
                "relative",
                highlightedModule === "talent-innovation" && "animate-pulse"
              )}>
                <div className="flex items-center mb-4">
                  <div className="w-1 h-4 bg-primary rounded mr-2" />
                  <h2 className={cn(
                    "text-lg font-bold transition-colors duration-300",
                    highlightedModule === "talent-innovation" ? "text-primary" : "text-primary"
                  )}>
                    Talent & Innovation
                  </h2>
                </div>
                <TalentInnovationModule />
              </div>
            </div>

            {/* Projects & Programs Module */}
            <div className="w-full">
              <div className="flex items-center mb-4">
                <div className="w-1 h-4 bg-primary rounded mr-2" />
                <h2 className="text-lg font-bold text-primary">Projects & Programs</h2>
              </div>
              <ProjectsProgramsModule />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}