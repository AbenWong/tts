import { Button } from "./ui/button";
import { 
  BarChart3, 
  DollarSign, 
  Activity, 
  Shield, 
  Users, 
  FolderKanban, 
  Settings,
  ChevronLeft,
  ChevronRight,
  LayoutDashboard
} from "lucide-react";
import { cn } from "./ui/utils";

interface DashboardSidebarProps {
  isCollapsed: boolean;
  onToggleCollapse: () => void;
}

const menuItems = [
  { icon: LayoutDashboard, label: "Overview", active: true },
  { icon: DollarSign, label: "Finance", active: false },
  { icon: Activity, label: "Operations", active: false },
  { icon: Shield, label: "Security", active: false },
  { icon: Users, label: "Talent", active: false },
  { icon: FolderKanban, label: "Projects", active: false },
  { icon: BarChart3, label: "Analytics", active: false },
  { icon: Settings, label: "Settings", active: false },
];

export function DashboardSidebar({ isCollapsed, onToggleCollapse }: DashboardSidebarProps) {
  return (
    <div className={cn(
      "h-full bg-sidebar border-r border-sidebar-border transition-all duration-300 ease-out flex flex-col",
      isCollapsed ? "w-20" : "w-60"
    )}>
      {/* Header */}
      <div className="h-[60px] flex items-center justify-between px-4 border-b border-sidebar-border">
        {!isCollapsed && (
          <h2 className="text-lg font-semibold text-sidebar-foreground">Dashboard</h2>
        )}
        <Button
          variant="ghost"
          size="icon"
          onClick={onToggleCollapse}
          className="h-8 w-8 text-sidebar-foreground hover:bg-sidebar-accent transition-transform duration-150 hover:scale-95"
        >
          {isCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </Button>
      </div>

      {/* Navigation Menu */}
      <div className="flex-1 py-4">
        <nav className="space-y-2 px-3">
          {menuItems.slice(0, -1).map((item, index) => (
            <Button
              key={index}
              variant={item.active ? "default" : "ghost"}
              className={cn(
                "w-full justify-start h-12 transition-all duration-200",
                isCollapsed ? "px-3" : "px-4",
                item.active 
                  ? "bg-sidebar-primary text-sidebar-primary-foreground hover:bg-sidebar-primary/90" 
                  : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
              )}
            >
              <item.icon className={cn("h-5 w-5", isCollapsed ? "" : "mr-3")} />
              {!isCollapsed && <span className="text-left">{item.label}</span>}
            </Button>
          ))}
        </nav>
      </div>

      {/* Bottom Settings */}
      <div className="p-3 border-t border-sidebar-border">
        <Button
          variant="ghost"
          className={cn(
            "w-full justify-start h-12 text-sidebar-foreground hover:bg-sidebar-accent",
            isCollapsed ? "px-3" : "px-4"
          )}
        >
          <Settings className={cn("h-5 w-5", isCollapsed ? "" : "mr-3")} />
          {!isCollapsed && <span>Settings</span>}
        </Button>
      </div>
    </div>
  );
}