
  # Plateforme SaaS START Modules (Community)

  This is a code bundle for Plateforme SaaS START Modules (Community). The original project is available at https://www.figma.com/design/VIxE2JRsvabUEfSUKgorLn/Plateforme-SaaS-START-Modules--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  