import React, { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { ModuleDetails } from './components/ModuleDetails';
import { VideoPlayer } from './components/VideoPlayer';
import { CertificatesPage } from './components/CertificatesPage';
import { ServicesPage } from './components/ServicesPage';
import { UserDashboard } from './components/UserDashboard';
import { AdminLayout } from './components/AdminLayout';
import { useAppNavigation } from './hooks/useAppNavigation';
import { useResponsive } from './hooks/useResponsive';
import { mockUser, mockModules } from './data/mockData';
import { ModulePage } from './components/ModulePage';
import { Button } from './components/ui/button';
import { Menu, X } from 'lucide-react';

export default function App() {
  const {
    activeCategory,
    selectedModule,
    selectedLesson,
    currentView,
    isAdminMode,
    adminSection,
    handleCategoryChange,
    handleModuleClick,
    handleLessonStart,
    handleLessonChange,
    handleBackToModules,
    handleBackToModule,
    handleAccessAdmin,
    handleBackToUser,
    handleAdminSectionChange,
    handleModulePageLessonStart
  } = useAppNavigation();

  const { isMobile, isTablet, isDesktop, breakpoint } = useResponsive();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // État pour gérer le live actif et la session
  const [liveSession] = React.useState({
    id: '1',
    title: '🔴 Live en direct',
    subtitle: 'Session en cours avec l\'équipe START',
    zoomUrl: 'https://zoom.us/j/123456789',
    isActive: true,
    conversionURL: 'https://start-modules.com/offre-speciale',
    conversionText: 'Voir l\'offre en direct',
    viewerCount: 127,
    autoPlay: true
  });
  
  const [isLiveActive] = React.useState(liveSession?.isActive || false);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const closeSidebar = () => {
    setIsSidebarOpen(false);
  };

  const renderMainContent = () => {
    if (currentView === 'video' && selectedModule && selectedLesson) {
      return (
        <VideoPlayer 
          moduleId={selectedModule}
          lessonId={selectedLesson}
          onBack={handleBackToModule}
          onLessonChange={handleLessonChange}
          isMobile={isMobile}
        />
      );
    }

    if (currentView === 'module-page' && selectedModule) {
      // Mapper les IDs des modules aux identifiants des modules détaillés
      const moduleIdMap: { [key: string]: string } = {
        '1': 'ia',
        '2': 'seo',
        '3': 'ecommerce',
        '4': 'copywriting',
        '5': 'branding',
        '6': 'analytics', 
        '7': 'ads'
      };
      
      const detailedModuleId = moduleIdMap[selectedModule] || selectedModule;
      
      return (
        <ModulePage 
          moduleId={detailedModuleId}
          onBack={handleBackToModules}
          onStartLesson={handleModulePageLessonStart}
          isMobile={isMobile}
        />
      );
    }

    if (currentView === 'module' && selectedModule) {
      return (
        <ModuleDetails 
          moduleId={selectedModule} 
          onBack={handleBackToModules}
          onLessonStart={handleLessonStart}
          isMobile={isMobile}
        />
      );
    }

    if (currentView === 'certificates') {
      return <CertificatesPage isMobile={isMobile} />;
    }

    if (currentView === 'services') {
      return <ServicesPage isMobile={isMobile} />;
    }

    return (
      <UserDashboard
        activeCategory={activeCategory}
        modules={mockModules}
        onModuleClick={handleModuleClick}
        liveSession={liveSession}
        isLiveActive={isLiveActive}
        isMobile={isMobile}
        breakpoint={breakpoint}
      />
    );
  };

  if (isAdminMode) {
    return (
      <AdminLayout
        adminSection={adminSection}
        onSectionChange={handleAdminSectionChange}
        onBackToUser={handleBackToUser}
        isMobile={isMobile}
        breakpoint={breakpoint}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 dark flex relative">
      {/* Mobile Overlay */}
      {isMobile && isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={closeSidebar}
        />
      )}

      {/* Sidebar */}
      <div className={`
        ${isMobile ? 'fixed' : 'relative'} 
        ${isMobile && !isSidebarOpen ? '-translate-x-full' : 'translate-x-0'}
        transition-transform duration-300 ease-in-out z-50
        ${isMobile ? 'w-80' : 'w-64'}
        ${isTablet ? 'w-72' : ''}
      `}>
        <Sidebar 
          activeCategory={activeCategory}
          onCategoryChange={handleCategoryChange}
          isMobile={isMobile}
          isTablet={isTablet}
          isOpen={isSidebarOpen}
          onClose={closeSidebar}
        />
      </div>
      
      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Mobile Menu Button */}
        {isMobile && (
          <div className="sticky top-0 z-30 bg-gray-900 border-b border-gray-800 p-4 lg:hidden">
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleSidebar}
              className="text-white hover:bg-gray-800"
            >
              {isSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        )}

        {/* Header */}
        {currentView !== 'video' && (
          <Header 
            user={mockUser} 
            onAccessAdmin={handleAccessAdmin}
            isLiveActive={isLiveActive}
            isMobile={isMobile}
            isTablet={isTablet}
          />
        )}
        
        {/* Main Content Area */}
        <main className={`
          flex-1 overflow-y-auto
          ${currentView !== 'video' ? (isMobile ? 'p-4' : isTablet ? 'p-5' : 'p-6') : ''}
          ${isMobile ? 'pb-safe-area-inset-bottom' : ''}
        `}>
          {renderMainContent()}
        </main>
      </div>
    </div>
  );
}