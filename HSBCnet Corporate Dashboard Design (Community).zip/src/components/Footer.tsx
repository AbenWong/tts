export function Footer() {
  return (
    <footer className="bg-tech-glass border-t border-tech-glass-border backdrop-blur-sm px-4 md:px-6 py-3 md:py-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
        {/* Quick Links */}
        <div className="flex items-center space-x-2 md:space-x-4 text-xs md:text-sm">
          <a 
            href="#" 
            className="text-tech-cyan hover:text-white transition-colors"
          >
            Terms
          </a>
          <span className="text-tech-cyan/50">|</span>
          <a 
            href="#" 
            className="text-tech-cyan hover:text-white transition-colors"
          >
            Privacy
          </a>
          <span className="text-tech-cyan/50">|</span>
          <a 
            href="#" 
            className="text-tech-cyan hover:text-white transition-colors"
          >
            <span className="hidden sm:inline">Tech </span>Support
          </a>
        </div>

        {/* Disclaimer */}
        <div className="text-xs md:text-sm text-tech-cyan">
          <span className="hidden sm:inline">Technology Strategy Dashboard - </span>Executive Access<span className="hidden sm:inline"> Only</span>
        </div>
      </div>
    </footer>
  );
}