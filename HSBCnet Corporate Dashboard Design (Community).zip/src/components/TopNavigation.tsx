import { useState } from 'react';
import { User, Settings, LogOut, CreditCard } from 'lucide-react';
import { Button } from './ui/button';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Separator } from './ui/separator';

interface TopNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export function TopNavigation({ activeTab, onTabChange }: TopNavigationProps) {
  const tabs = [
    { id: 'command-center', label: 'Command Center', shortLabel: 'Command' },
    { id: 'strategy-value', label: 'Strategy & Value', shortLabel: 'Strategy' },
    { id: 'finance-budget', label: 'Finance & Budget', shortLabel: 'Finance' },
    { id: 'operations-efficiency', label: 'Operations & Efficiency', shortLabel: 'Ops' },
    { id: 'risk-security', label: 'Risk & Security', shortLabel: 'Risk' },
    { id: 'talent-innovation', label: 'Talent & Innovation', shortLabel: 'Talent' },
    { id: 'portfolio-programs', label: 'Portfolio & Programs', shortLabel: 'Portfolio' }
  ];

  return (
    <nav className="glass-morphism border-b neon-border backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Left side - HSBC Logo with glow */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-hsbc-red rounded-lg flex items-center justify-center pulse-glow">
                <span className="text-white font-bold text-lg">H</span>
              </div>
            </div>
            <div>
              <h1 className="text-lg md:text-xl text-tech-cyan hidden sm:block glow-text tracking-wider">
                TECH OPERATIONS INTELLIGENCE
              </h1>
              <h1 className="text-base text-tech-cyan sm:hidden glow-text">TOI</h1>
            </div>
          </div>

          {/* Center - Tab Navigation (Desktop) */}
          <div className="hidden lg:flex items-center space-x-1">
            {tabs.map((tab) => (
              <Button
                key={tab.id}
                variant="ghost"
                onClick={() => onTabChange(tab.id)}
                className={`px-3 py-2 text-xs transition-colors rounded-none h-16 ${
                  activeTab === tab.id
                    ? 'text-tech-cyan border-b-2 border-tech-cyan bg-tech-glass'
                    : 'text-white hover:text-tech-cyan hover:bg-tech-glass'
                }`}
              >
                {tab.shortLabel}
              </Button>
            ))}
          </div>

          {/* Right side - Time Selector + Profile */}
          <div className="flex items-center space-x-4">
            {/* Live Time Display */}
            <div className="hidden md:flex items-center space-x-2">
              <div className="w-2 h-2 bg-tech-success rounded-full animate-pulse"></div>
              <span className="text-tech-cyan text-sm tech-counter">2025 JULY</span>
            </div>
            
            {/* Mobile Tab Navigation */}
            <div className="lg:hidden">
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" size="sm" className="glass-morphism border-tech-cyan text-tech-cyan hover:bg-tech-glass">
                    {tabs.find(tab => tab.id === activeTab)?.shortLabel || 'Menu'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="glass-morphism w-56 p-2" align="center">
                  <div className="space-y-1">
                    {tabs.map((tab) => (
                      <Button
                        key={tab.id}
                        variant="ghost"
                        onClick={() => onTabChange(tab.id)}
                        className={`w-full justify-start text-sm ${
                          activeTab === tab.id ? 'bg-tech-glass text-tech-cyan glow-text' : 'text-white hover:text-tech-cyan'
                        }`}
                      >
                        {tab.label}
                      </Button>
                    ))}
                  </div>
                </PopoverContent>
              </Popover>
            </div>
        
            {/* Profile Menu */}
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="ghost" size="icon" className="hover:bg-tech-glass pulse-glow">
                  <User className="h-5 w-5 text-tech-cyan" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="glass-morphism w-56 md:w-64 p-0" align="end">
                <div className="p-4">
                  <div className="mb-4">
                    <h3 className="font-medium text-white">Commander Smith</h3>
                    <p className="text-sm text-tech-cyan">Tech Operations</p>
                    <p className="text-xs text-tech-cyan tech-counter">ID: CTO-12345</p>
                  </div>
                  <Separator className="my-3 bg-tech-glass-border" />
                  <div className="space-y-1">
                    <Button variant="ghost" className="w-full justify-start text-white hover:text-tech-cyan" size="sm">
                      <User className="h-4 w-4 mr-2" />
                      Profile Settings
                    </Button>
                    <Button variant="ghost" className="w-full justify-start text-white hover:text-tech-cyan" size="sm">
                      <CreditCard className="h-4 w-4 mr-2" />
                      Access Control
                    </Button>
                    <Button variant="ghost" className="w-full justify-start text-white hover:text-tech-cyan" size="sm">
                      <Settings className="h-4 w-4 mr-2" />
                      Preferences
                    </Button>
                    <Separator className="my-2 bg-tech-glass-border" />
                    <Button variant="ghost" className="w-full justify-start text-tech-alert hover:text-white" size="sm">
                      <LogOut className="h-4 w-4 mr-2" />
                      Sign Out
                    </Button>
                  </div>
                </div>
              </PopoverContent>
            </Popover>
          </div>
        </div>
      </div>
    </nav>
  );
}