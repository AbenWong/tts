import { ReactNode } from 'react';
import { LucideIcon } from 'lucide-react';

interface LinearDataModuleProps {
  title: string;
  icon: LucideIcon;
  children: ReactNode;
  size?: 'small' | 'medium' | 'large';
  className?: string;
}

export function LinearDataModule({ 
  title, 
  icon: Icon, 
  children, 
  size = 'medium',
  className = ''
}: LinearDataModuleProps) {
  const sizeClasses = {
    small: 'p-4',
    medium: 'p-6',
    large: 'p-8'
  };

  return (
    <div className={`linear-card linear-hover ${sizeClasses[size]} ${className}`}>
      <div className="flex items-center gap-3 mb-4">
        <div className="w-8 h-8 bg-linear-accent/10 rounded-lg flex items-center justify-center">
          <Icon className="w-4 h-4 text-linear-accent" />
        </div>
        <h3 className="linear-header text-linear-text-primary text-lg font-medium">{title}</h3>
      </div>
      <div className="space-y-4">
        {children}
      </div>
    </div>
  );
}