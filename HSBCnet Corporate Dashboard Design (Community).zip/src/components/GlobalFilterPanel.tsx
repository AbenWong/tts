import { Calendar } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';

interface GlobalFilterPanelProps {
  filters: {
    businessUnit: string;
    region: string;
    costCenter: string;
  };
  onFiltersChange: (filters: any) => void;
  selectedPeriod: {
    year: number;
    month: number;
    monthName: string;
  };
  onPeriodChange: (period: any) => void;
  currentPeriodDisplay: string;
}

export function GlobalFilterPanel({ filters, onFiltersChange, selectedPeriod, onPeriodChange, currentPeriodDisplay }: GlobalFilterPanelProps) {
  const handleFilterChange = (key: string, value: string) => {
    onFiltersChange({
      ...filters,
      [key]: value
    });
  };

  const handleYearChange = (year: string) => {
    const yearNum = parseInt(year);
    onPeriodChange({
      ...selectedPeriod,
      year: yearNum
    });
  };

  const handleMonthChange = (month: string) => {
    const monthNum = parseInt(month);
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 
                   'July', 'August', 'September', 'October', 'November', 'December'];
    onPeriodChange({
      ...selectedPeriod,
      month: monthNum,
      monthName: months[monthNum - 1]
    });
  };

  const years = [2023, 2024, 2025, 2026];
  const months = [
    { value: 1, label: 'January' },
    { value: 2, label: 'February' },
    { value: 3, label: 'March' },
    { value: 4, label: 'April' },
    { value: 5, label: 'May' },
    { value: 6, label: 'June' },
    { value: 7, label: 'July' },
    { value: 8, label: 'August' },
    { value: 9, label: 'September' },
    { value: 10, label: 'October' },
    { value: 11, label: 'November' },
    { value: 12, label: 'December' }
  ];

  return (
    <div className="bg-tech-glass border-b border-tech-glass-border py-3 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center">
          {/* Year-Month Selector - Primary Filter */}
          <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center">
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4 text-tech-cyan" />
              <span className="text-sm text-white">Data Period:</span>
            </div>
            
            <div className="flex gap-2">
              {/* Year Selector */}
              <Select 
                value={selectedPeriod.year.toString()} 
                onValueChange={handleYearChange}
              >
                <SelectTrigger className="w-24 h-8 text-sm bg-tech-glass border-tech-cyan text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {years.map((year) => (
                    <SelectItem key={year} value={year.toString()}>{year}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Month Selector */}
              <Select 
                value={selectedPeriod.month.toString()} 
                onValueChange={handleMonthChange}
              >
                <SelectTrigger className="w-32 h-8 text-sm bg-tech-glass border-tech-cyan text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {months.map((month) => (
                    <SelectItem key={month.value} value={month.value.toString()}>{month.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Live Data Indicator */}
          <div className="flex items-center gap-2 ml-auto">
            <div className="w-2 h-2 bg-tech-success rounded-full animate-pulse"></div>
            <span className="text-xs text-tech-cyan">Live Data</span>
          </div>
        </div>
      </div>
    </div>
  );
}