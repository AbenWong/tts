import { 
  BarChart3, Shield, DollarSign, Settings, Users, Briefcase,
  Globe, Target, Zap, MapPin
} from 'lucide-react';

interface LinearSidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export function LinearSidebar({ activeTab, onTabChange }: LinearSidebarProps) {
  const navigationItems = [
    { id: 'earth-dashboard', label: 'Global Overview', icon: Globe },
    { id: 'china-dashboard', label: 'China Regional', icon: MapPin },
    { id: 'strategy-value', label: 'Strategy & Value', icon: Target },
    { id: 'finance-budget', label: 'Finance & Budget', icon: DollarSign },
    { id: 'operations-efficiency', label: 'Operations', icon: Zap },
    { id: 'risk-security', label: 'Risk & Security', icon: Shield },
    { id: 'talent-innovation', label: 'Talent & Innovation', icon: Users },
    { id: 'portfolio-programs', label: 'Portfolio', icon: Briefcase }
  ];

  return (
    <div className="linear-sidebar w-64 h-screen fixed left-0 top-0 z-50 flex flex-col">
      {/* Logo/Header */}
      <div className="p-6 border-b border-linear-border">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-linear-accent rounded-lg flex items-center justify-center">
            <BarChart3 className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-white font-semibold text-lg linear-header">TechOps</h1>
            <p className="text-gray-400 text-sm linear-body">Analytics Hub</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2">
        {navigationItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 linear-hover relative ${
                isActive 
                  ? 'bg-linear-accent text-white' 
                  : 'text-gray-400 hover:text-white hover:bg-linear-slate'
              }`}
            >
              {isActive && (
                <div className="absolute left-0 top-0 bottom-0 linear-accent-bar"></div>
              )}
              <Icon className="w-5 h-5" />
              <span className="linear-body text-sm">{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-linear-border">
        <div className="flex items-center gap-3 px-4 py-3">
          <Settings className="w-5 h-5 text-gray-400" />
          <span className="text-gray-400 text-sm linear-body">Settings</span>
        </div>
      </div>
    </div>
  );
}