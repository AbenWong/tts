import { useState } from 'react';
import { Key, CheckCircle } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Label } from './ui/label';

interface PasswordResetModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function PasswordResetModal({ isOpen, onClose }: PasswordResetModalProps) {
  const [step, setStep] = useState<'input' | 'sent' | 'verify'>('input');
  const [formData, setFormData] = useState({
    username: '',
    securityCode: '',
    newPassword: '',
    confirmPassword: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (step === 'input') {
      setStep('sent');
      setTimeout(() => setStep('verify'), 2000);
    } else if (step === 'verify') {
      alert('Password reset successfully!');
      onClose();
      setStep('input');
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md mx-4 md:mx-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Key className="h-5 w-5 text-hsbc-red" />
            <span>Reset Password</span>
          </DialogTitle>
        </DialogHeader>
        
        {step === 'input' && (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label>Username or Customer ID</Label>
              <Input
                value={formData.username}
                onChange={(e) => setFormData({...formData, username: e.target.value})}
                placeholder="Enter your username"
                required
              />
            </div>
            <p className="text-sm text-hsbc-grey-dark">
              We'll send a security code to your registered mobile number and email.
            </p>
            <div className="flex space-x-2 pt-4">
              <Button 
                type="submit" 
                className="flex-1 bg-hsbc-red hover:bg-hsbc-red/90"
                disabled={!formData.username}
              >
                Send Security Code
              </Button>
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
            </div>
          </form>
        )}

        {step === 'sent' && (
          <div className="text-center py-8">
            <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
            <p className="text-foreground mb-2">Security code sent!</p>
            <p className="text-sm text-hsbc-grey-dark">
              Please check your mobile phone and email for the verification code.
            </p>
          </div>
        )}

        {step === 'verify' && (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label>Security Code</Label>
              <Input
                value={formData.securityCode}
                onChange={(e) => setFormData({...formData, securityCode: e.target.value})}
                placeholder="Enter 6-digit code"
                maxLength={6}
                required
              />
            </div>
            <div>
              <Label>New Password</Label>
              <Input
                type="password"
                value={formData.newPassword}
                onChange={(e) => setFormData({...formData, newPassword: e.target.value})}
                placeholder="Enter new password"
                required
              />
            </div>
            <div>
              <Label>Confirm New Password</Label>
              <Input
                type="password"
                value={formData.confirmPassword}
                onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
                placeholder="Confirm new password"
                required
              />
            </div>
            <div className="flex space-x-2 pt-4">
              <Button 
                type="submit" 
                className="flex-1 bg-hsbc-red hover:bg-hsbc-red/90"
                disabled={!formData.securityCode || !formData.newPassword || formData.newPassword !== formData.confirmPassword}
              >
                Reset Password
              </Button>
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
            </div>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}