import { Filter, ChevronDown } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card } from './ui/card';

interface FilterPanelProps {
  filters: {
    businessUnit: string;
    region: string;
    timePeriod: string;
  };
  onFiltersChange: (filters: any) => void;
}

export function FilterPanel({ filters, onFiltersChange }: FilterPanelProps) {
  const handleFilterChange = (key: string, value: string) => {
    onFiltersChange({
      ...filters,
      [key]: value
    });
  };

  return (
    <div className="py-4">
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
        <div className="flex items-center gap-2">
          <Filter className="h-5 w-5 text-hsbc-grey-dark" />
          <span className="text-hsbc-grey-dark">Filters:</span>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-3 flex-1 max-w-4xl">
          {/* Business Unit Filter */}
          <div className="flex-1 min-w-48">
            <Select 
              value={filters.businessUnit} 
              onValueChange={(value) => handleFilterChange('businessUnit', value)}
            >
              <SelectTrigger className="bg-white border-hsbc-grey-medium">
                <SelectValue placeholder="Business Unit" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Business Units</SelectItem>
                <SelectItem value="commercial">Commercial Banking</SelectItem>
                <SelectItem value="retail">Retail Banking & Wealth</SelectItem>
                <SelectItem value="global">Global Banking & Markets</SelectItem>
                <SelectItem value="technology">Technology & Operations</SelectItem>
                <SelectItem value="risk">Risk & Compliance</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Region Filter */}
          <div className="flex-1 min-w-40">
            <Select 
              value={filters.region} 
              onValueChange={(value) => handleFilterChange('region', value)}
            >
              <SelectTrigger className="bg-white border-hsbc-grey-medium">
                <SelectValue placeholder="Region" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Regions</SelectItem>
                <SelectItem value="apac">Asia Pacific</SelectItem>
                <SelectItem value="europe">Europe</SelectItem>
                <SelectItem value="americas">Americas</SelectItem>
                <SelectItem value="mena">Middle East & North Africa</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Time Period Filter */}
          <div className="flex-1 min-w-36">
            <Select 
              value={filters.timePeriod} 
              onValueChange={(value) => handleFilterChange('timePeriod', value)}
            >
              <SelectTrigger className="bg-white border-hsbc-grey-medium">
                <SelectValue placeholder="Time Period" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="current">Current Quarter</SelectItem>
                <SelectItem value="q1-2024">Q1 2024</SelectItem>
                <SelectItem value="q4-2023">Q4 2023</SelectItem>
                <SelectItem value="q3-2023">Q3 2023</SelectItem>
                <SelectItem value="ytd">Year to Date</SelectItem>
                <SelectItem value="12months">Last 12 Months</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>
    </div>
  );
}