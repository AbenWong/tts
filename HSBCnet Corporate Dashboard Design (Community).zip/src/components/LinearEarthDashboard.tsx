import { EarthVisualization } from './EarthVisualization';
import { LinearDataModule } from './LinearDataModule';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { 
  BarChart, Bar, XAxis, YAxis, ResponsiveContainer, LineChart, Line,
  PieChart, Pie, Cell, AreaChart, Area
} from 'recharts';
import { 
  TrendingUp, DollarSign, Shield, Users, Target, Zap, 
  Activity, CheckCircle, AlertTriangle, Briefcase
} from 'lucide-react';

interface LinearEarthDashboardProps {
  filters: any;
  selectedPeriod: any;
  currentPeriodDisplay: string;
}

export function LinearEarthDashboard({ filters, selectedPeriod, currentPeriodDisplay }: LinearEarthDashboardProps) {
  
  // Strategy & Value Metrics
  const strategyMetrics = {
    techInvestment: 2.4,
    digitalRevenue: 67.3,
    mobileBankingUsers: 2.8,
    npsScore: 67
  };

  const digitalTrend = [
    { month: 'Jan', value: 58 },
    { month: 'Feb', value: 62 },
    { month: 'Mar', value: 65 },
    { month: 'Apr', value: 68 },
    { month: 'May', value: 71 },
    { month: 'Jun', value: 67 }
  ];

  // Finance & Budget Metrics
  const financeMetrics = {
    budgetAdherence: 98.2,
    costSavings: 156.7,
    unitCost: 0.23,
    operationalSpending: 67.4
  };

  const budgetAllocation = [
    { name: 'Infrastructure', value: 35.2, color: '#4361EE' },
    { name: 'Applications', value: 28.7, color: '#10B981' },
    { name: 'Security', value: 18.4, color: '#EF4444' },
    { name: 'Innovation', value: 17.7, color: '#8B5CF6' }
  ];

  // Operations Metrics
  const opsMetrics = {
    systemAvailability: 99.97,
    mttr: 2.3,
    automationCoverage: 85.4,
    changeSuccessRate: 94.5
  };

  const performanceData = [
    { time: '08:00', value: 67 },
    { time: '12:00', value: 89 },
    { time: '16:00', value: 95 },
    { time: '20:00', value: 78 }
  ];

  // Risk & Security Metrics
  const riskMetrics = {
    threatLevel: 'LOW',
    vulnerabilities: 3,
    complianceScore: 96.8,
    securityIncidents: 2
  };

  // Talent & Innovation Metrics
  const talentMetrics = {
    techHeadcount: 1247,
    attritionRate: 8.2,
    trainingCoverage: 92.5,
    innovationProjects: 47
  };

  // Portfolio Metrics
  const portfolioMetrics = {
    deliveryRate: 94.5,
    projectHealth: 87.3,
    innovationRatio: 23.8,
    budgetUtilization: 91.2
  };

  return (
    <div className="min-h-screen bg-linear-deep-blue p-8">
      <div className="max-w-7xl mx-auto">
        
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-white text-3xl font-semibold linear-header mb-2">
            Global Technology Performance
          </h1>
          <p className="text-gray-400 linear-body">
            Real-time insights across all technology domains - {currentPeriodDisplay}
          </p>
        </div>

        {/* Main Grid Layout */}
        <div className="grid grid-cols-12 gap-6 min-h-[800px]">
          
          {/* Left Cluster - Strategy & Talent */}
          <div className="col-span-3 space-y-6 animate-slide-in-left">
            
            {/* Strategy & Value Module */}
            <LinearDataModule title="Strategy & Value" icon={Target} size="medium">
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-linear-text-secondary linear-body text-sm">Tech Investment</span>
                  <span className="linear-metric text-linear-accent text-xl">${strategyMetrics.techInvestment}B</span>
                </div>
                
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-linear-text-secondary linear-body text-sm">Digital Revenue</span>
                    <span className="linear-metric text-linear-text-primary">{strategyMetrics.digitalRevenue}%</span>
                  </div>
                  <Progress value={strategyMetrics.digitalRevenue} className="h-2" />
                </div>

                <div className="h-16">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={digitalTrend}>
                      <Line 
                        type="monotone" 
                        dataKey="value" 
                        stroke="#4361EE" 
                        strokeWidth={2}
                        dot={false}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-linear-text-secondary linear-body text-sm">NPS Score</span>
                  <Badge className="bg-linear-positive text-white">{strategyMetrics.npsScore}</Badge>
                </div>
              </div>
            </LinearDataModule>

            {/* Talent & Innovation Module */}
            <LinearDataModule title="Talent & Innovation" icon={Users} size="medium">
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div className="text-center">
                    <div className="linear-metric text-linear-accent text-2xl">{talentMetrics.techHeadcount}</div>
                    <div className="text-linear-text-secondary text-xs linear-body">Tech Staff</div>
                  </div>
                  <div className="text-center">
                    <div className="linear-metric text-linear-warning text-2xl">{talentMetrics.attritionRate}%</div>
                    <div className="text-linear-text-secondary text-xs linear-body">Attrition</div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-linear-text-secondary linear-body text-sm">Training Coverage</span>
                    <span className="linear-metric text-linear-text-primary">{talentMetrics.trainingCoverage}%</span>
                  </div>
                  <Progress value={talentMetrics.trainingCoverage} className="h-2" />
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-linear-text-secondary linear-body text-sm">Innovation Projects</span>
                  <span className="linear-metric text-linear-neutral text-xl">{talentMetrics.innovationProjects}</span>
                </div>
              </div>
            </LinearDataModule>
          </div>

          {/* Center - Earth Visualization */}
          <div className="col-span-6 flex items-center justify-center animate-fade-in">
            <div className="text-center">
              <EarthVisualization />
              <div className="mt-6 space-y-2">
                <h2 className="text-white text-xl linear-header">Global Operations Center</h2>
                <p className="text-gray-400 linear-body text-sm">
                  Real-time monitoring across all regions
                </p>
                <div className="flex justify-center gap-4 mt-4">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-linear-positive rounded-full animate-pulse"></div>
                    <span className="text-gray-400 text-xs">12 Data Centers</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-linear-accent rounded-full animate-pulse"></div>
                    <span className="text-gray-400 text-xs">24/7 Monitoring</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Cluster - Operations & Risk */}
          <div className="col-span-3 space-y-6 animate-slide-in-right">
            
            {/* Operations & Efficiency Module */}
            <LinearDataModule title="Operations" icon={Zap} size="medium">
              <div className="space-y-4">
                <div className="text-center mb-4">
                  <div className="linear-metric text-linear-positive text-3xl">{opsMetrics.systemAvailability}%</div>
                  <div className="text-linear-text-secondary text-sm linear-body">Availability</div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="text-center">
                    <div className="linear-metric text-linear-accent text-lg">{opsMetrics.mttr}h</div>
                    <div className="text-linear-text-secondary text-xs linear-body">MTTR</div>
                  </div>
                  <div className="text-center">
                    <div className="linear-metric text-linear-neutral text-lg">{opsMetrics.changeSuccessRate}%</div>
                    <div className="text-linear-text-secondary text-xs linear-body">Changes</div>
                  </div>
                </div>

                <div className="h-12">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={performanceData}>
                      <Area 
                        type="monotone" 
                        dataKey="value" 
                        stroke="#10B981" 
                        fill="#10B981"
                        fillOpacity={0.2}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </LinearDataModule>

            {/* Risk & Security Module */}
            <LinearDataModule title="Risk & Security" icon={Shield} size="medium">
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-linear-text-secondary linear-body text-sm">Threat Level</span>
                  <Badge className="bg-linear-positive text-white">{riskMetrics.threatLevel}</Badge>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="text-center">
                    <div className="linear-metric text-linear-warning text-xl">{riskMetrics.vulnerabilities}</div>
                    <div className="text-linear-text-secondary text-xs linear-body">Open Vulns</div>
                  </div>
                  <div className="text-center">
                    <div className="linear-metric text-linear-critical text-xl">{riskMetrics.securityIncidents}</div>
                    <div className="text-linear-text-secondary text-xs linear-body">Incidents</div>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-linear-text-secondary linear-body text-sm">Compliance Score</span>
                    <span className="linear-metric text-linear-text-primary">{riskMetrics.complianceScore}%</span>
                  </div>
                  <Progress value={riskMetrics.complianceScore} className="h-2" />
                </div>
              </div>
            </LinearDataModule>
          </div>
        </div>

        {/* Bottom Row - Finance & Portfolio */}
        <div className="grid grid-cols-2 gap-6 mt-6">
          
          {/* Finance & Budget Module */}
          <LinearDataModule title="Finance & Budget" icon={DollarSign} size="large" className="animate-fade-in">
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-linear-text-secondary linear-body text-sm">Budget Adherence</span>
                    <span className="linear-metric text-linear-positive text-lg">{financeMetrics.budgetAdherence}%</span>
                  </div>
                  <Progress value={financeMetrics.budgetAdherence} className="h-2" />
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-linear-text-secondary linear-body text-sm">Cost Savings</span>
                  <span className="linear-metric text-linear-accent text-xl">${financeMetrics.costSavings}M</span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-linear-text-secondary linear-body text-sm">Unit Cost</span>
                  <span className="linear-metric text-linear-text-primary">${financeMetrics.unitCost}</span>
                </div>
              </div>

              <div className="h-32">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={budgetAllocation}
                      cx="50%"
                      cy="50%"
                      innerRadius={30}
                      outerRadius={50}
                      paddingAngle={2}
                      dataKey="value"
                    >
                      {budgetAllocation.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </LinearDataModule>

          {/* Portfolio & Programs Module */}
          <LinearDataModule title="Portfolio & Programs" icon={Briefcase} size="large" className="animate-fade-in">
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-linear-text-secondary linear-body text-sm">Delivery Rate</span>
                    <span className="linear-metric text-linear-positive text-lg">{portfolioMetrics.deliveryRate}%</span>
                  </div>
                  <Progress value={portfolioMetrics.deliveryRate} className="h-2" />
                </div>

                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-linear-text-secondary linear-body text-sm">Project Health</span>
                    <span className="linear-metric text-linear-accent text-lg">{portfolioMetrics.projectHealth}%</span>
                  </div>
                  <Progress value={portfolioMetrics.projectHealth} className="h-2" />
                </div>
              </div>

              <div className="space-y-4">
                <div className="text-center">
                  <div className="linear-metric text-linear-neutral text-2xl">{portfolioMetrics.innovationRatio}%</div>
                  <div className="text-linear-text-secondary text-sm linear-body">Innovation Ratio</div>
                </div>

                <div className="text-center">
                  <div className="linear-metric text-linear-warning text-2xl">{portfolioMetrics.budgetUtilization}%</div>
                  <div className="text-linear-text-secondary text-sm linear-body">Budget Used</div>
                </div>
              </div>
            </div>
          </LinearDataModule>
        </div>
      </div>
    </div>
  );
}