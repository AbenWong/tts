import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { 
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell, ComposedChart, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar
} from 'recharts';
import { 
  Shield, AlertTriangle, Eye, Lock, Bug, Clock, Target, Zap,
  CheckCircle, XCircle, Timer, Database, Server, Wifi
} from 'lucide-react';

interface RiskSecurityTabProps {
  filters: any;
  selectedPeriod: any;
  currentPeriodDisplay: string;
}

export function RiskSecurityTab({ filters, selectedPeriod, currentPeriodDisplay }: RiskSecurityTabProps) {
  
  // KRI (Key Risk Indicators) Status
  const kriData = [
    { indicator: 'Cyber Threats', status: 'GREEN', value: 2, threshold: 5, trend: 'stable' },
    { indicator: 'Data Breaches', status: 'GREEN', value: 0, threshold: 1, trend: 'down' },
    { indicator: 'Compliance Gaps', status: 'AMBER', value: 3, threshold: 2, trend: 'up' },
    { indicator: 'System Outages', status: 'GREEN', value: 1, threshold: 3, trend: 'down' },
    { indicator: 'Vendor Risks', status: 'GREEN', value: 4, threshold: 8, trend: 'stable' },
    { indicator: 'Operational Risks', status: 'AMBER', value: 6, threshold: 5, trend: 'up' }
  ];

  // Security Threat Radar
  const threatRadarData = [
    { threat: 'Malware', current: 85, baseline: 90 },
    { threat: 'Phishing', current: 92, baseline: 85 },
    { threat: 'DDoS', current: 78, baseline: 80 },
    { threat: 'Insider Threat', current: 88, baseline: 85 },
    { threat: 'Data Exfiltration', current: 95, baseline: 88 },
    { threat: 'Zero-day', current: 72, baseline: 75 }
  ];

  // Vulnerability Management Timeline
  const vulnerabilityData = [
    { month: 'Jan', critical: 12, high: 34, medium: 67, low: 89, resolved: 145 },
    { month: 'Feb', critical: 8, high: 28, medium: 52, low: 73, resolved: 132 },
    { month: 'Mar', critical: 15, high: 42, medium: 81, low: 95, resolved: 178 },
    { month: 'Apr', critical: 6, high: 31, medium: 59, low: 78, resolved: 156 },
    { month: 'May', critical: 9, high: 37, medium: 71, low: 84, resolved: 168 },
    { month: 'Jun', critical: 3, high: 22, medium: 45, low: 63, resolved: 124 }
  ];

  // Compliance Progress
  const complianceData = [
    { framework: 'PCI DSS', progress: 96, requirements: 200, completed: 192 },
    { framework: 'GDPR', progress: 94, requirements: 150, completed: 141 },
    { framework: 'SOX', progress: 98, requirements: 180, completed: 176 },
    { framework: 'Basel III', progress: 92, requirements: 120, completed: 110 },
    { framework: 'FFIEC', progress: 89, requirements: 95, completed: 85 }
  ];

  // Disaster Recovery Metrics
  const drMetrics = {
    rto: 15, // minutes
    rpo: 5, // minutes
    testSuccessRate: 94.5,
    lastTestDate: '2025-06-28',
    nextTestDate: '2025-07-28'
  };

  // Security Incidents Timeline
  const securityIncidents = [
    {
      id: 'SEC-001',
      type: 'Unauthorized Access',
      severity: 'HIGH',
      status: 'RESOLVED',
      detectedAt: '14:23:45',
      resolvedAt: '14:45:12',
      duration: 21.45,
      region: 'US-East'
    },
    {
      id: 'SEC-002',
      type: 'Suspicious Activity',
      severity: 'MEDIUM',
      status: 'INVESTIGATING',
      detectedAt: '15:12:33',
      resolvedAt: null,
      duration: null,
      region: 'EU-West'
    },
    {
      id: 'SEC-003',
      type: 'Failed Login Attempts',
      severity: 'LOW',
      status: 'RESOLVED',
      detectedAt: '15:45:18',
      resolvedAt: '15:52:03',
      duration: 6.75,
      region: 'APAC'
    }
  ];

  // GRAS (Governance, Risk and Security) Status
  const grasStatus = {
    governance: 92,
    risk: 88,
    architecture: 94,
    security: 91
  };

  const COLORS = ['#4361EE', '#7209B7', '#4CC9F0', '#10B981', '#F59E0B', '#DB0011'];

  const getKRIStatusColor = (status: string) => {
    switch (status) {
      case 'GREEN': return 'bg-tech-success text-white';
      case 'AMBER': return 'bg-tech-warning text-white';
      case 'RED': return 'bg-tech-alert text-white';
      default: return 'bg-tech-blue text-white';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'HIGH': return <AlertTriangle className="w-4 h-4 text-tech-alert" />;
      case 'MEDIUM': return <Eye className="w-4 h-4 text-tech-warning" />;
      case 'LOW': return <CheckCircle className="w-4 h-4 text-tech-success" />;
      default: return <Shield className="w-4 h-4 text-tech-blue" />;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'RESOLVED': return <CheckCircle className="w-4 h-4 text-tech-success" />;
      case 'INVESTIGATING': return <Eye className="w-4 h-4 text-tech-warning" />;
      case 'OPEN': return <XCircle className="w-4 h-4 text-tech-alert" />;
      default: return <Timer className="w-4 h-4 text-tech-cyan" />;
    }
  };

  return (
    <div className="p-6 space-y-6 bg-tech-navy min-h-screen">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div className="animate-fade-in-up">
          <h1 className="text-3xl font-bold text-white mb-2 glow-text">RISK & SECURITY</h1>
          <p className="text-tech-cyan">Threat Detection & Compliance Monitoring - {currentPeriodDisplay}</p>
        </div>
      </div>

      {/* KRI Status Dashboard */}
      <Card className="glass-morphism neon-border animate-slide-in">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2 glow-text">
            <Target className="w-6 h-6 text-tech-cyan" />
            KEY RISK INDICATORS (KRI) STATUS
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {kriData.map((kri, index) => (
              <div key={kri.indicator} className="p-4 rounded-lg glass-morphism">
                <div className="flex justify-between items-center mb-3">
                  <h4 className="text-white font-medium text-sm">{kri.indicator}</h4>
                  <Badge className={getKRIStatusColor(kri.status)}>
                    {kri.status}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-2xl font-bold text-white tech-counter">{kri.value}</div>
                    <div className="text-xs text-tech-cyan">Threshold: {kri.threshold}</div>
                  </div>
                  <div className="w-16 h-16">
                    <div className="relative">
                      <svg className="w-16 h-16 transform -rotate-90">
                        <circle
                          cx="32"
                          cy="32"
                          r="28"
                          stroke="rgba(76, 201, 240, 0.2)"
                          strokeWidth="4"
                          fill="transparent"
                        />
                        <circle
                          cx="32"
                          cy="32"
                          r="28"
                          stroke={kri.status === 'GREEN' ? '#10B981' : kri.status === 'AMBER' ? '#F59E0B' : '#DB0011'}
                          strokeWidth="4"
                          fill="transparent"
                          strokeLinecap="round"
                          strokeDasharray={`${((kri.threshold - kri.value) / kri.threshold) * 175.9} 175.9`}
                          className="pulse-glow"
                        />
                      </svg>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <Shield className="h-6 w-6 text-tech-cyan" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Security Threat Radar */}
        <Card className="glass-morphism neon-border animate-fade-in-up">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2 glow-text">
              <Eye className="w-5 h-5 text-tech-purple" />
              THREAT DETECTION RADAR
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart data={threatRadarData}>
                  <PolarGrid stroke="rgba(76, 201, 240, 0.2)" />
                  <PolarAngleAxis dataKey="threat" tick={{ fontSize: 12, fill: '#4CC9F0' }} />
                  <PolarRadiusAxis 
                    angle={0} 
                    domain={[0, 100]} 
                    tick={{ fontSize: 10, fill: '#4CC9F0' }}
                  />
                  <Radar
                    name="Current Protection"
                    dataKey="current"
                    stroke="#4361EE"
                    fill="#4361EE"
                    fillOpacity={0.3}
                    strokeWidth={2}
                  />
                  <Radar
                    name="Baseline"
                    dataKey="baseline"
                    stroke="#7209B7"
                    fill="transparent"
                    strokeWidth={2}
                    strokeDasharray="5 5"
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'rgba(10, 12, 23, 0.9)', 
                      border: '1px solid #4CC9F0',
                      borderRadius: '8px',
                      color: '#ffffff'
                    }}
                  />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Vulnerability Management */}
        <Card className="glass-morphism neon-border animate-fade-in-up">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2 glow-text">
              <Bug className="w-5 h-5 text-tech-warning" />
              VULNERABILITY MANAGEMENT
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={vulnerabilityData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(76, 201, 240, 0.1)" />
                  <XAxis dataKey="month" stroke="#4CC9F0" />
                  <YAxis yAxisId="left" stroke="#4CC9F0" />
                  <YAxis yAxisId="right" orientation="right" stroke="#10B981" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'rgba(10, 12, 23, 0.9)', 
                      border: '1px solid #4CC9F0',
                      borderRadius: '8px',
                      color: '#ffffff'
                    }}
                  />
                  <Bar yAxisId="left" dataKey="critical" stackId="vuln" fill="#DB0011" name="Critical" />
                  <Bar yAxisId="left" dataKey="high" stackId="vuln" fill="#F59E0B" name="High" />
                  <Bar yAxisId="left" dataKey="medium" stackId="vuln" fill="#4CC9F0" name="Medium" />
                  <Bar yAxisId="left" dataKey="low" stackId="vuln" fill="#10B981" name="Low" />
                  <Line yAxisId="right" type="monotone" dataKey="resolved" stroke="#7209B7" strokeWidth={3} name="Resolved" />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Compliance & GRAS */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Compliance Progress */}
        <Card className="glass-morphism neon-border animate-fade-in-up">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2 glow-text">
              <CheckCircle className="w-5 h-5 text-tech-success" />
              COMPLIANCE REMEDIATION
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {complianceData.map((compliance, index) => (
                <div key={compliance.framework} className="p-4 rounded-lg glass-morphism">
                  <div className="flex justify-between items-center mb-3">
                    <span className="text-white font-medium">{compliance.framework}</span>
                    <Badge variant="outline" className="border-tech-cyan text-tech-cyan">
                      {compliance.progress}%
                    </Badge>
                  </div>
                  <Progress value={compliance.progress} className="h-3 mb-2" />
                  <div className="flex justify-between text-xs">
                    <span className="text-tech-cyan">
                      {compliance.completed}/{compliance.requirements} Requirements
                    </span>
                    <span className="text-white">
                      {compliance.requirements - compliance.completed} Remaining
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* GRAS Status & DR Metrics */}
        <Card className="glass-morphism neon-border animate-fade-in-up">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2 glow-text">
              <Shield className="w-5 h-5 text-tech-blue" />
              GRAS STATUS & DISASTER RECOVERY
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {/* GRAS Metrics */}
              <div>
                <h4 className="text-white font-medium mb-3">GRAS Framework</h4>
                <div className="grid grid-cols-2 gap-3">
                  <div className="text-center p-3 rounded-lg bg-gradient-to-r from-tech-blue/20 to-transparent">
                    <div className="text-2xl font-bold text-tech-blue tech-counter">{grasStatus.governance}%</div>
                    <div className="text-xs text-tech-cyan">Governance</div>
                  </div>
                  <div className="text-center p-3 rounded-lg bg-gradient-to-r from-tech-purple/20 to-transparent">
                    <div className="text-2xl font-bold text-tech-purple tech-counter">{grasStatus.risk}%</div>
                    <div className="text-xs text-tech-cyan">Risk</div>
                  </div>
                  <div className="text-center p-3 rounded-lg bg-gradient-to-r from-tech-cyan/20 to-transparent">
                    <div className="text-2xl font-bold text-tech-cyan tech-counter">{grasStatus.architecture}%</div>
                    <div className="text-xs text-tech-cyan">Architecture</div>
                  </div>
                  <div className="text-center p-3 rounded-lg bg-gradient-to-r from-tech-success/20 to-transparent">
                    <div className="text-2xl font-bold text-tech-success tech-counter">{grasStatus.security}%</div>
                    <div className="text-xs text-tech-cyan">Security</div>
                  </div>
                </div>
              </div>

              {/* DR Metrics */}
              <div>
                <h4 className="text-white font-medium mb-3">Disaster Recovery</h4>
                <div className="space-y-3">
                  <div className="flex justify-between items-center p-3 rounded-lg bg-gradient-to-r from-tech-glass to-transparent">
                    <span className="text-tech-cyan">RTO Target</span>
                    <span className="text-white font-bold tech-counter">{drMetrics.rto} min</span>
                  </div>
                  <div className="flex justify-between items-center p-3 rounded-lg bg-gradient-to-r from-tech-glass to-transparent">
                    <span className="text-tech-cyan">RPO Target</span>
                    <span className="text-white font-bold tech-counter">{drMetrics.rpo} min</span>
                  </div>
                  <div className="flex justify-between items-center p-3 rounded-lg bg-gradient-to-r from-tech-glass to-transparent">
                    <span className="text-tech-cyan">Test Success Rate</span>
                    <span className="text-white font-bold tech-counter">{drMetrics.testSuccessRate}%</span>
                  </div>
                  <div className="flex justify-between items-center p-3 rounded-lg bg-gradient-to-r from-tech-glass to-transparent">
                    <span className="text-tech-cyan">Next Test Date</span>
                    <span className="text-white font-bold">{drMetrics.nextTestDate}</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Security Incidents */}
      <Card className="glass-morphism neon-border animate-fade-in-up">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2 glow-text">
            <AlertTriangle className="w-5 h-5 text-tech-warning" />
            SECURITY INCIDENTS (Real-time)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {securityIncidents.map((incident) => (
              <div key={incident.id} className="p-4 rounded-lg glass-morphism border-l-4 border-tech-cyan">
                <div className="grid grid-cols-1 md:grid-cols-6 gap-4 items-center">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="border-tech-blue text-tech-blue">
                      {incident.id}
                    </Badge>
                  </div>
                  
                  <div>
                    <span className="text-white text-sm">{incident.type}</span>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {getSeverityIcon(incident.severity)}
                    <span className="text-white text-sm">{incident.severity}</span>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {getStatusIcon(incident.status)}
                    <span className="text-white text-sm">{incident.status}</span>
                  </div>
                  
                  <div>
                    <span className="text-tech-cyan text-sm">
                      {incident.duration ? `${incident.duration}min` : 'Ongoing'}
                    </span>
                  </div>
                  
                  <div>
                    <Badge variant="outline" className="border-tech-purple text-tech-purple">
                      {incident.region}
                    </Badge>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}