import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { 
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell, ComposedChart, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar
} from 'recharts';
import { 
  Globe, Zap, Shield, DollarSign, Users, Target, Brain, Activity,
  AlertTriangle, CheckCircle, TrendingUp, Cpu, Network, Server
} from 'lucide-react';

interface CommandCenterDashboardProps {
  filters: any;
  selectedPeriod: any;
  currentPeriodDisplay: string;
}

export function CommandCenterDashboard({ filters, selectedPeriod, currentPeriodDisplay }: CommandCenterDashboardProps) {
  
  // Global KPIs for world map overlay
  const globalMetrics = {
    systemAvailability: 99.97,
    threatLevel: 'LOW',
    activeUsers: 2.8, // Million
    dataFlowTB: 847.3,
    energyEfficiency: 94.2,
    securityScore: 96.8
  };

  // Regional data for world map
  const regionalData = [
    {
      region: 'North America',
      availability: 99.98,
      users: 0.9,
      risk: 'GREEN',
      dataCenter: 'NYC-DC-01',
      coords: { x: 20, y: 35 }
    },
    {
      region: 'Europe',
      availability: 99.96,
      users: 0.8,
      risk: 'GREEN',
      dataCenter: 'LON-DC-01',
      coords: { x: 50, y: 30 }
    },
    {
      region: 'Asia Pacific',
      availability: 99.97,
      users: 1.1,
      risk: 'AMBER',
      dataCenter: 'HKG-DC-01',
      coords: { x: 80, y: 40 }
    }
  ];

  // Real-time metrics for animated displays
  const realtimeMetrics = [
    { label: 'CPU Utilization', value: 73, unit: '%', trend: 'stable', color: '#4361EE' },
    { label: 'Memory Usage', value: 68, unit: '%', trend: 'down', color: '#7209B7' },
    { label: 'Network I/O', value: 1247, unit: 'Mbps', trend: 'up', color: '#4CC9F0' },
    { label: 'Storage IOPS', value: 8945, unit: 'ops/s', trend: 'up', color: '#10B981' },
    { label: 'Response Time', value: 23, unit: 'ms', trend: 'stable', color: '#F59E0B' },
    { label: 'Error Rate', value: 0.02, unit: '%', trend: 'down', color: '#DB0011' }
  ];

  // Critical alerts
  const criticalAlerts = [
    {
      id: 1,
      type: 'SECURITY',
      message: 'Unusual login pattern detected - Asia Pacific',
      severity: 'HIGH',
      timestamp: '14:23:45',
      status: 'INVESTIGATING'
    },
    {
      id: 2,
      type: 'PERFORMANCE',
      message: 'Database response time threshold exceeded',
      severity: 'MEDIUM',
      timestamp: '14:19:12',
      status: 'RESOLVED'
    },
    {
      id: 3,
      type: 'CAPACITY',
      message: 'Storage utilization approaching 85% - EU West',
      severity: 'LOW',
      timestamp: '14:15:33',
      status: 'MONITORING'
    }
  ];

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'HIGH': return 'text-tech-alert';
      case 'MEDIUM': return 'text-tech-warning';
      case 'LOW': return 'text-tech-cyan';
      default: return 'text-white';
    }
  };

  const getRegionRiskColor = (risk: string) => {
    switch (risk) {
      case 'GREEN': return 'bg-tech-success';
      case 'AMBER': return 'bg-tech-warning';
      case 'RED': return 'bg-tech-alert';
      default: return 'bg-tech-blue';
    }
  };

  return (
    <div className="p-6 space-y-6 bg-tech-navy min-h-screen">
      {/* Command Center Header */}
      <div className="flex justify-between items-center mb-8">
        <div className="animate-fade-in-up">
          <h1 className="text-4xl font-bold text-white glow-text mb-2">GLOBAL COMMAND CENTER</h1>
          <p className="text-tech-cyan tech-counter">Real-time Technology Operations Monitor - {currentPeriodDisplay}</p>
        </div>
        <div className="flex items-center gap-4">
          <Badge variant="outline" className="border-tech-success text-tech-success bg-tech-glass pulse-glow">
            <Activity className="w-4 h-4 mr-1" />
            OPERATIONAL
          </Badge>
        </div>
      </div>

      {/* Global Status Bar */}
      <Card className="glass-morphism neon-border animate-slide-in">
        <CardContent className="p-4">
          <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-tech-success tech-counter">{globalMetrics.systemAvailability}%</div>
              <div className="text-xs text-tech-cyan">AVAILABILITY</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-tech-cyan tech-counter">{globalMetrics.activeUsers}M</div>
              <div className="text-xs text-tech-cyan">ACTIVE USERS</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-tech-purple tech-counter">{globalMetrics.dataFlowTB}</div>
              <div className="text-xs text-tech-cyan">DATA FLOW (TB)</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-tech-success tech-counter">{globalMetrics.energyEfficiency}%</div>
              <div className="text-xs text-tech-cyan">EFFICIENCY</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-tech-blue tech-counter">{globalMetrics.securityScore}</div>
              <div className="text-xs text-tech-cyan">SECURITY SCORE</div>
            </div>
            <div className="text-center">
              <Badge className={`${globalMetrics.threatLevel === 'LOW' ? 'bg-tech-success' : 'bg-tech-warning'} text-white`}>
                {globalMetrics.threatLevel} THREAT
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Interactive World Map - Center Piece */}
        <div className="lg:col-span-2">
          <Card className="glass-morphism neon-border h-96 animate-fade-in-up">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2 glow-text">
                <Globe className="w-6 h-6 text-tech-cyan" />
                GLOBAL OPERATIONS MAP
              </CardTitle>
            </CardHeader>
            <CardContent className="relative h-full">
              {/* Simplified World Map Visualization */}
              <div className="relative w-full h-64 bg-gradient-to-br from-tech-navy to-tech-blue/20 rounded-lg overflow-hidden">
                {/* Animated background grid */}
                <div className="absolute inset-0 opacity-20">
                  <div className="grid grid-cols-12 grid-rows-8 h-full w-full">
                    {Array.from({ length: 96 }).map((_, i) => (
                      <div key={i} className="border border-tech-cyan/20"></div>
                    ))}
                  </div>
                </div>
                
                {/* Regional Data Points */}
                {regionalData.map((region, index) => (
                  <div
                    key={region.region}
                    className="absolute transform -translate-x-1/2 -translate-y-1/2 group cursor-pointer"
                    style={{ 
                      left: `${region.coords.x}%`, 
                      top: `${region.coords.y}%`,
                      animationDelay: `${index * 0.5}s`
                    }}
                  >
                    {/* Pulsing indicator */}
                    <div className={`w-4 h-4 rounded-full ${getRegionRiskColor(region.risk)} pulse-glow animate-pulse`}></div>
                    
                    {/* Data flow lines */}
                    <div className="absolute top-1/2 left-1/2 w-32 h-px bg-gradient-to-r from-transparent via-tech-cyan to-transparent data-flow"></div>
                    
                    {/* Hover card */}
                    <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 glass-morphism p-3 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity z-10 min-w-48">
                      <h4 className="text-white font-bold text-sm">{region.region}</h4>
                      <div className="space-y-1 text-xs">
                        <div className="flex justify-between">
                          <span className="text-tech-cyan">Availability:</span>
                          <span className="text-white">{region.availability}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-tech-cyan">Users:</span>
                          <span className="text-white">{region.users}M</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-tech-cyan">Data Center:</span>
                          <span className="text-white">{region.dataCenter}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                
                {/* Animated data flow particles */}
                <div className="absolute inset-0 pointer-events-none">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <div
                      key={i}
                      className="absolute w-1 h-1 bg-tech-cyan rounded-full floating-animation"
                      style={{
                        left: `${20 + i * 15}%`,
                        top: `${30 + (i % 2) * 20}%`,
                        animationDelay: `${i * 1.2}s`
                      }}
                    ></div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Real-time Metrics Panel */}
        <div className="space-y-4">
          <Card className="glass-morphism neon-border animate-fade-in-up">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2 glow-text">
                <Activity className="w-5 h-5 text-tech-cyan" />
                REAL-TIME METRICS
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {realtimeMetrics.map((metric, index) => (
                <div key={metric.label} className="flex items-center justify-between p-2 rounded-lg bg-gradient-to-r from-tech-glass to-transparent">
                  <div className="flex items-center gap-2">
                    <div 
                      className="w-2 h-2 rounded-full animate-pulse"
                      style={{ backgroundColor: metric.color }}
                    ></div>
                    <span className="text-white text-sm">{metric.label}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-white font-bold tech-counter">
                      {typeof metric.value === 'number' && metric.value < 1 
                        ? metric.value.toFixed(2) 
                        : metric.value.toLocaleString()}
                    </span>
                    <span className="text-tech-cyan text-xs">{metric.unit}</span>
                    {metric.trend === 'up' && <TrendingUp className="w-3 h-3 text-tech-success" />}
                    {metric.trend === 'down' && <TrendingUp className="w-3 h-3 text-tech-alert rotate-180" />}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Critical Alerts */}
          <Card className="glass-morphism neon-border animate-fade-in-up">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2 glow-text">
                <AlertTriangle className="w-5 h-5 text-tech-warning" />
                ALERT CENTER
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {criticalAlerts.map((alert) => (
                <div key={alert.id} className="p-3 rounded-lg glass-morphism border-l-4 border-tech-cyan">
                  <div className="flex justify-between items-start mb-2">
                    <Badge variant="outline" className={`border-tech-cyan ${getSeverityColor(alert.severity)}`}>
                      {alert.type}
                    </Badge>
                    <span className="text-tech-cyan text-xs tech-counter">{alert.timestamp}</span>
                  </div>
                  <p className="text-white text-sm mb-2">{alert.message}</p>
                  <div className="flex justify-between items-center">
                    <span className={`text-xs font-bold ${getSeverityColor(alert.severity)}`}>
                      {alert.severity}
                    </span>
                    <Badge variant="outline" className="border-tech-blue text-tech-blue">
                      {alert.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* System Health Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="glass-morphism neon-border animate-fade-in-up">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2 glow-text">
              <Server className="w-5 h-5 text-tech-blue" />
              INFRASTRUCTURE
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-tech-cyan">Data Centers</span>
                <span className="text-white font-bold tech-counter">12 Active</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-tech-cyan">Servers</span>
                <span className="text-white font-bold tech-counter">3,247</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-tech-cyan">Cloud Instances</span>
                <span className="text-white font-bold tech-counter">8,934</span>
              </div>
              <Progress value={87} className="h-2" />
              <span className="text-tech-cyan text-xs">Capacity Utilization: 87%</span>
            </div>
          </CardContent>
        </Card>

        <Card className="glass-morphism neon-border animate-fade-in-up">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2 glow-text">
              <Network className="w-5 h-5 text-tech-purple" />
              NETWORK
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-tech-cyan">Bandwidth</span>
                <span className="text-white font-bold tech-counter">2.4 Tbps</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-tech-cyan">Latency</span>
                <span className="text-white font-bold tech-counter">15ms</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-tech-cyan">Packet Loss</span>
                <span className="text-white font-bold tech-counter">0.001%</span>
              </div>
              <Progress value={94} className="h-2" />
              <span className="text-tech-cyan text-xs">Network Health: 94%</span>
            </div>
          </CardContent>
        </Card>

        <Card className="glass-morphism neon-border animate-fade-in-up">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2 glow-text">
              <Shield className="w-5 h-5 text-tech-success" />
              SECURITY
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-tech-cyan">Threats Blocked</span>
                <span className="text-white font-bold tech-counter">12,847</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-tech-cyan">Vulnerabilities</span>
                <span className="text-white font-bold tech-counter">3 Open</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-tech-cyan">Compliance</span>
                <span className="text-white font-bold tech-counter">98.9%</span>
              </div>
              <Progress value={97} className="h-2" />
              <span className="text-tech-cyan text-xs">Security Score: 97%</span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}