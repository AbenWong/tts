import { useState } from 'react';
import { ZoomIn, ZoomOut, Activity, TrendingUp, Shield, Users, Zap, DollarSign } from 'lucide-react';

interface ChinaDashboardProps {
  filters: any;
  selectedPeriod: any;
  currentPeriodDisplay: string;
}

interface ProvinceData {
  id: string;
  name: string;
  digitalRevenue: number;
  mobileUsers: number;
  systemAvailability: number;
  riskLevel: 'low' | 'medium' | 'high';
}

const provinceData: Record<string, ProvinceData> = {
  'beijing': { id: 'beijing', name: 'Beijing', digitalRevenue: 72.5, mobileUsers: 8.9, systemAvailability: 99.98, riskLevel: 'low' },
  'shanghai': { id: 'shanghai', name: 'Shanghai', digitalRevenue: 78.2, mobileUsers: 12.3, systemAvailability: 99.97, riskLevel: 'low' },
  'guangdong': { id: 'guangdong', name: 'Guangdong', digitalRevenue: 65.8, mobileUsers: 45.2, systemAvailability: 99.95, riskLevel: 'medium' },
  'jiangsu': { id: 'jiangsu', name: 'Jiangsu', digitalRevenue: 61.4, mobileUsers: 22.8, systemAvailability: 99.96, riskLevel: 'low' },
  'zhejiang': { id: 'zhejiang', name: 'Zhejiang', digitalRevenue: 69.3, mobileUsers: 18.7, systemAvailability: 99.94, riskLevel: 'medium' },
  'shandong': { id: 'shandong', name: 'Shandong', digitalRevenue: 58.9, mobileUsers: 28.1, systemAvailability: 99.93, riskLevel: 'medium' }
};

export function ChinaDashboard({ filters, selectedPeriod, currentPeriodDisplay }: ChinaDashboardProps) {
  const [selectedProvince, setSelectedProvince] = useState<string | null>(null);
  const [hoveredProvince, setHoveredProvince] = useState<string | null>(null);

  const selectedData = selectedProvince ? provinceData[selectedProvince] : null;

  const getHeatmapColor = (value: number) => {
    if (value >= 70) return '#06B6D4';
    if (value >= 60) return '#3B82F6';
    return '#60A5FA';
  };

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'high': return '#EF4444';
      case 'medium': return '#F59E0B';
      case 'low': return '#10B981';
      default: return '#60A5FA';
    }
  };

  const globalMetrics = {
    totalInvestment: '¥85.2M',
    digitalShare: 62.5,
    systemAvailability: 99.98,
    coreTPS: 3800,
    responseTime: '0.42s',
    riskAlerts: { red: 2, amber: 3 },
    costSavings: 96,
    annualSavings: '¥4.8M',
    techPersonnel: 420,
    aiScenarios: 15
  };

  return (
    <div className="min-h-screen p-8" style={{ backgroundColor: '#0F172A' }}>
      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-semibold text-white linear-header mb-2">
          China Regional Overview
        </h1>
        <p className="text-gray-400 linear-body">
          Geographic performance analytics for {currentPeriodDisplay}
        </p>
      </div>

      {/* Main Dashboard Grid */}
      <div className="grid grid-cols-12 gap-6">
        
        {/* Top Row - Strategic Value Cards */}
        <div className="col-span-6 grid grid-cols-2 gap-4">
          {/* Tech Investment Card */}
          <div 
            className="rounded-xl p-6 border transition-all duration-200 hover:scale-105"
            style={{ 
              backgroundColor: '#1E293B',
              borderColor: '#374151',
              boxShadow: '0 0 8px rgba(59, 130, 246, 0.15)'
            }}
          >
            <div className="flex items-center gap-3 mb-4">
              <DollarSign className="w-6 h-6" style={{ color: '#3B82F6' }} />
              <h3 className="text-white text-lg">Tech Investment</h3>
            </div>
            <div className="space-y-2">
              <div className="text-2xl font-semibold" style={{ color: '#3B82F6' }}>
                {selectedData ? `¥${(parseFloat(globalMetrics.totalInvestment.slice(1, -1)) * selectedData.digitalRevenue / 100).toFixed(1)}M` : globalMetrics.totalInvestment}
              </div>
              <div className="text-gray-400 text-sm">
                Share of Revenue: {selectedData ? `${selectedData.digitalRevenue.toFixed(1)}%` : '18.3%'}
              </div>
            </div>
          </div>

          {/* Digital Business Share Card */}
          <div 
            className="rounded-xl p-6 border transition-all duration-200 hover:scale-105"
            style={{ 
              backgroundColor: '#1E293B',
              borderColor: '#374151',
              boxShadow: '0 0 8px rgba(59, 130, 246, 0.15)'
            }}
          >
            <div className="flex items-center gap-3 mb-4">
              <TrendingUp className="w-6 h-6" style={{ color: '#06B6D4' }} />
              <h3 className="text-white text-lg">Digital Business</h3>
            </div>
            <div className="text-2xl font-semibold" style={{ color: '#06B6D4' }}>
              {selectedData ? `${selectedData.digitalRevenue.toFixed(1)}%` : `${globalMetrics.digitalShare}%`}
            </div>
          </div>
        </div>

        {/* Right Column - Operational Cards */}
        <div className="col-span-3 grid grid-rows-2 gap-4">
          {/* System Availability Card */}
          <div 
            className="rounded-xl p-6 border transition-all duration-200 hover:scale-105"
            style={{ 
              backgroundColor: '#1E293B',
              borderColor: '#374151',
              boxShadow: '0 0 8px rgba(59, 130, 246, 0.15)'
            }}
          >
            <div className="flex items-center gap-3 mb-4">
              <Activity className="w-6 h-6" style={{ color: '#10B981' }} />
              <h3 className="text-white">Availability</h3>
            </div>
            <div className="text-xl font-semibold" style={{ color: '#06B6D4' }}>
              {selectedData ? `${selectedData.systemAvailability}%` : `${globalMetrics.systemAvailability}%`}
            </div>
          </div>

          {/* Core System Performance Card */}
          <div 
            className="rounded-xl p-6 border transition-all duration-200 hover:scale-105"
            style={{ 
              backgroundColor: '#1E293B',
              borderColor: '#374151',
              boxShadow: '0 0 8px rgba(59, 130, 246, 0.15)'
            }}
          >
            <div className="flex items-center gap-3 mb-4">
              <Zap className="w-6 h-6" style={{ color: '#3B82F6' }} />
              <h3 className="text-white">Core TPS</h3>
            </div>
            <div className="text-lg font-semibold" style={{ color: '#3B82F6' }}>
              {selectedData ? Math.round(globalMetrics.coreTPS * selectedData.mobileUsers / 20).toLocaleString() : globalMetrics.coreTPS.toLocaleString()}
            </div>
          </div>
        </div>

        {/* Left Column - Additional Cards */}
        <div className="col-span-3 grid grid-rows-2 gap-4">
          {/* Risk Status Card */}
          <div 
            className="rounded-xl p-6 border transition-all duration-200 hover:scale-105"
            style={{ 
              backgroundColor: '#1E293B',
              borderColor: '#374151',
              boxShadow: '0 0 8px rgba(59, 130, 246, 0.15)'
            }}
          >
            <div className="flex items-center gap-3 mb-4">
              <Shield className="w-6 h-6" style={{ color: '#EF4444' }} />
              <h3 className="text-white">Risk Status</h3>
            </div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-1 bg-red-500 text-white text-xs rounded">
                {selectedData ? (selectedData.riskLevel === 'high' ? '1 RED' : '0 RED') : `${globalMetrics.riskAlerts.red} RED`}
              </span>
              <span className="px-2 py-1 bg-amber-500 text-white text-xs rounded">
                {selectedData ? (selectedData.riskLevel === 'medium' ? '1 AMBER' : '0 AMBER') : `${globalMetrics.riskAlerts.amber} AMBER`}
              </span>
            </div>
          </div>

          {/* Tech Talent Card */}
          <div 
            className="rounded-xl p-6 border transition-all duration-200 hover:scale-105"
            style={{ 
              backgroundColor: '#1E293B',
              borderColor: '#374151',
              boxShadow: '0 0 8px rgba(59, 130, 246, 0.15)'
            }}
          >
            <div className="flex items-center gap-3 mb-4">
              <Users className="w-6 h-6" style={{ color: '#8B5CF6' }} />
              <h3 className="text-white">Tech Talent</h3>
            </div>
            <div className="text-lg font-semibold" style={{ color: '#3B82F6' }}>
              {selectedData ? Math.round(globalMetrics.techPersonnel * selectedData.mobileUsers / 20) : globalMetrics.techPersonnel}
            </div>
          </div>
        </div>

        {/* Central China Map Card */}
        <div className="col-span-12 flex justify-center mt-8">
          <div 
            className="rounded-xl border relative overflow-hidden"
            style={{ 
              backgroundColor: '#1E293B',
              borderColor: '#374151',
              width: '70%',
              height: '400px',
              boxShadow: '0 0 8px rgba(59, 130, 246, 0.15)'
            }}
          >
            <div className="p-6">
              <h3 className="text-white text-xl mb-4 text-center">China Regional Performance Map</h3>
              
              {/* Simplified Map Visualization */}
              <div className="relative w-full h-80 flex items-center justify-center">
                <div className="grid grid-cols-3 gap-4 w-full max-w-md">
                  {Object.entries(provinceData).map(([key, data]) => (
                    <div
                      key={key}
                      className={`p-4 rounded-lg border-2 cursor-pointer transition-all duration-200 ${
                        selectedProvince === key ? 'scale-110' : 'hover:scale-105'
                      }`}
                      style={{
                        backgroundColor: getHeatmapColor(data.digitalRevenue),
                        borderColor: selectedProvince === key ? '#3B82F6' : 'transparent',
                        opacity: hoveredProvince === key || selectedProvince === key ? 1 : 0.8
                      }}
                      onMouseEnter={() => setHoveredProvince(key)}
                      onMouseLeave={() => setHoveredProvince(null)}
                      onClick={() => setSelectedProvince(selectedProvince === key ? null : key)}
                    >
                      <div className="text-white font-semibold text-sm text-center">{data.name}</div>
                      <div className="text-white text-xs text-center mt-1">{data.digitalRevenue}%</div>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Legend */}
              <div className="mt-4 flex justify-center">
                <div className="flex items-center gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded" style={{ backgroundColor: '#60A5FA' }}></div>
                    <span className="text-gray-300">50-60%</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded" style={{ backgroundColor: '#3B82F6' }}></div>
                    <span className="text-gray-300">60-70%</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded" style={{ backgroundColor: '#06B6D4' }}></div>
                    <span className="text-gray-300">70%+</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Data Refresh Indicator */}
            <div className="absolute top-4 right-4">
              <div 
                className="w-3 h-3 rounded-full animate-pulse"
                style={{ backgroundColor: '#3B82F6' }}
              ></div>
            </div>

            {/* Province Details Tooltip */}
            {hoveredProvince && (
              <div 
                className="absolute top-4 left-4 bg-slate-900 text-white p-3 rounded-lg border border-slate-600 z-10 text-sm shadow-xl"
                style={{ minWidth: '200px' }}
              >
                <div className="font-semibold text-cyan-400 mb-2">{provinceData[hoveredProvince].name}</div>
                <div className="space-y-1">
                  <div className="flex justify-between">
                    <span className="text-gray-300">Digital Revenue:</span>
                    <span className="text-blue-400 font-medium">{provinceData[hoveredProvince].digitalRevenue}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Mobile Users:</span>
                    <span className="text-blue-400 font-medium">{provinceData[hoveredProvince].mobileUsers}M</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Risk Level:</span>
                    <span 
                      className="font-medium capitalize"
                      style={{ color: getRiskColor(provinceData[hoveredProvince].riskLevel) }}
                    >
                      {provinceData[hoveredProvince].riskLevel}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Bottom Row - Additional Metrics */}
        <div className="col-span-12 grid grid-cols-2 gap-4 mt-8">
          {/* Cost Savings Card */}
          <div 
            className="rounded-xl p-6 border transition-all duration-200 hover:scale-105"
            style={{ 
              backgroundColor: '#1E293B',
              borderColor: '#374151',
              boxShadow: '0 0 8px rgba(59, 130, 246, 0.15)'
            }}
          >
            <div className="flex items-center gap-3 mb-4">
              <DollarSign className="w-6 h-6" style={{ color: '#10B981' }} />
              <h3 className="text-white text-lg">Cost Savings Achievement</h3>
            </div>
            <div className="text-2xl font-semibold" style={{ color: '#06B6D4' }}>
              {selectedData ? `${Math.min(selectedData.digitalRevenue + 30, 100).toFixed(0)}%` : `${globalMetrics.costSavings}%`}
            </div>
            <div className="text-gray-400 text-sm mt-2">
              Annual Savings: {selectedData ? `¥${(parseFloat(globalMetrics.annualSavings.slice(1, -1)) * selectedData.digitalRevenue / 65).toFixed(1)}M` : globalMetrics.annualSavings}
            </div>
          </div>

          {/* AI Applications Card */}
          <div 
            className="rounded-xl p-6 border transition-all duration-200 hover:scale-105"
            style={{ 
              backgroundColor: '#1E293B',
              borderColor: '#374151',
              boxShadow: '0 0 8px rgba(59, 130, 246, 0.15)'
            }}
          >
            <div className="flex items-center gap-3 mb-4">
              <Zap className="w-6 h-6" style={{ color: '#10B981' }} />
              <h3 className="text-white text-lg">Generative AI Applications</h3>
            </div>
            <div className="flex items-center gap-2">
              <div className="text-2xl font-semibold" style={{ color: '#06B6D4' }}>
                {selectedData ? Math.round(globalMetrics.aiScenarios * selectedData.digitalRevenue / 70) : globalMetrics.aiScenarios}
              </div>
              <div className="text-green-400 text-sm flex items-center gap-1">
                <TrendingUp className="w-3 h-3" />
                +3 This Month
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}