import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { 
  TrendingUp, DollarSign, Shield, Users, Target, Activity,
  AlertTriangle, CheckCircle, Clock, BarChart3, Zap, Brain
} from 'lucide-react';

interface ExecutiveSummaryTabProps {
  filters: any;
  selectedPeriod: any;
  currentPeriodDisplay: string;
}

export function ExecutiveSummaryTab({ filters, selectedPeriod, currentPeriodDisplay }: ExecutiveSummaryTabProps) {
  
  // Executive Summary KPIs
  const executiveMetrics = {
    techValueContribution: 24.7, // % of revenue
    digitalRevenue: 67.3, // %
    budgetAdherence: 98.2, // %
    costSavingsAchieved: 156.7, // Million USD
    systemAvailability: 99.97, // %
    mttr: 2.3, // hours
    kriStatus: 'GREEN',
    majorRisks: 3,
    keyTalentAttrition: 8.2, // %
    deliveryOnTime: 94.5 // %
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'GREEN': return 'bg-tech-success';
      case 'AMBER': return 'bg-tech-warning';
      case 'RED': return 'bg-tech-alert';
      default: return 'bg-tech-blue';
    }
  };

  const getStatusTextColor = (status: string) => {
    switch (status) {
      case 'GREEN': return 'text-tech-success';
      case 'AMBER': return 'text-tech-warning';
      case 'RED': return 'text-tech-alert';
      default: return 'text-tech-blue';
    }
  };

  return (
    <div className="p-6 space-y-6 bg-tech-navy min-h-screen">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Executive Summary</h1>
          <p className="text-tech-cyan">Technology Strategy & Performance Overview - {currentPeriodDisplay}</p>
        </div>
        <div className="flex items-center gap-4">
          <Badge variant="outline" className="border-tech-cyan text-tech-cyan bg-tech-glass">
            <Activity className="w-4 h-4 mr-1" />
            Live Data
          </Badge>
        </div>
      </div>

      {/* Key Performance Indicators Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        
        {/* Value Creation */}
        <Card className="bg-tech-glass border-tech-glass-border backdrop-blur-sm hover:border-tech-cyan transition-all duration-300">
          <CardHeader className="pb-3">
            <CardTitle className="text-white text-lg flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-tech-purple" />
              Value Creation
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-tech-cyan text-sm">Tech Value Contribution</span>
                <span className="text-white font-bold">{executiveMetrics.techValueContribution}%</span>
              </div>
              <Progress value={executiveMetrics.techValueContribution} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-tech-cyan text-sm">Digital Revenue</span>
                <span className="text-white font-bold">{executiveMetrics.digitalRevenue}%</span>
              </div>
              <Progress value={executiveMetrics.digitalRevenue} className="h-2" />
            </div>
          </CardContent>
        </Card>

        {/* Financial Health */}
        <Card className="bg-tech-glass border-tech-glass-border backdrop-blur-sm hover:border-tech-cyan transition-all duration-300">
          <CardHeader className="pb-3">
            <CardTitle className="text-white text-lg flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-tech-blue" />
              Financial Health
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-tech-cyan text-sm">Budget Adherence</span>
                <span className="text-white font-bold">{executiveMetrics.budgetAdherence}%</span>
              </div>
              <Progress value={executiveMetrics.budgetAdherence} className="h-2" />
            </div>
            <div>
              <span className="text-tech-cyan text-sm">Cost Savings Achieved</span>
              <p className="text-white font-bold text-xl">${executiveMetrics.costSavingsAchieved}M</p>
            </div>
          </CardContent>
        </Card>

        {/* Operational Excellence */}
        <Card className="bg-tech-glass border-tech-glass-border backdrop-blur-sm hover:border-tech-cyan transition-all duration-300">
          <CardHeader className="pb-3">
            <CardTitle className="text-white text-lg flex items-center gap-2">
              <Zap className="w-5 h-5 text-tech-cyan" />
              Operational Excellence
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-tech-cyan text-sm">System Availability</span>
                <span className="text-white font-bold">{executiveMetrics.systemAvailability}%</span>
              </div>
              <Progress value={executiveMetrics.systemAvailability} className="h-2" />
            </div>
            <div className="flex justify-between items-center">
              <span className="text-tech-cyan text-sm">MTTR</span>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-tech-cyan" />
                <span className="text-white font-bold">{executiveMetrics.mttr}h</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Risk Posture */}
        <Card className="bg-tech-glass border-tech-glass-border backdrop-blur-sm hover:border-tech-cyan transition-all duration-300">
          <CardHeader className="pb-3">
            <CardTitle className="text-white text-lg flex items-center gap-2">
              <Shield className="w-5 h-5 text-tech-success" />
              Risk Posture
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-tech-cyan text-sm">KRI Status</span>
              <Badge className={`${getStatusColor(executiveMetrics.kriStatus)} text-white`}>
                <CheckCircle className="w-3 h-3 mr-1" />
                {executiveMetrics.kriStatus}
              </Badge>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-tech-cyan text-sm">Major Risks Outstanding</span>
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-tech-warning" />
                <span className="text-white font-bold">{executiveMetrics.majorRisks}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Talent Health */}
        <Card className="bg-tech-glass border-tech-glass-border backdrop-blur-sm hover:border-tech-cyan transition-all duration-300">
          <CardHeader className="pb-3">
            <CardTitle className="text-white text-lg flex items-center gap-2">
              <Users className="w-5 h-5 text-tech-purple" />
              Talent Health
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-tech-cyan text-sm">Key Talent Attrition</span>
                <span className="text-white font-bold">{executiveMetrics.keyTalentAttrition}%</span>
              </div>
              <Progress value={executiveMetrics.keyTalentAttrition} className="h-2" />
              <p className="text-xs text-tech-cyan mt-1">vs. Industry benchmark: 12.5%</p>
            </div>
          </CardContent>
        </Card>

        {/* Portfolio Health */}
        <Card className="bg-tech-glass border-tech-glass-border backdrop-blur-sm hover:border-tech-cyan transition-all duration-300">
          <CardHeader className="pb-3">
            <CardTitle className="text-white text-lg flex items-center gap-2">
              <Target className="w-5 h-5 text-tech-blue" />
              Portfolio Health
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-tech-cyan text-sm">Strategic Initiative Delivery</span>
                <span className="text-white font-bold">{executiveMetrics.deliveryOnTime}%</span>
              </div>
              <Progress value={executiveMetrics.deliveryOnTime} className="h-2" />
              <p className="text-xs text-tech-cyan mt-1">On-time delivery rate</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Insights */}
      <Card className="bg-tech-glass border-tech-glass-border backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="text-white text-xl flex items-center gap-2">
            <Brain className="w-6 h-6 text-tech-purple" />
            AI-Generated Insights
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <div className="flex items-start gap-3 p-3 rounded-lg bg-gradient-to-r from-tech-success/20 to-transparent border-l-4 border-tech-success">
                <CheckCircle className="w-5 h-5 text-tech-success mt-0.5" />
                <div>
                  <p className="text-white font-medium">Strong Performance</p>
                  <p className="text-tech-cyan text-sm">System availability exceeds target by 0.47%. Cost savings 25% ahead of annual target.</p>
                </div>
              </div>
              <div className="flex items-start gap-3 p-3 rounded-lg bg-gradient-to-r from-tech-blue/20 to-transparent border-l-4 border-tech-blue">
                <BarChart3 className="w-5 h-5 text-tech-blue mt-0.5" />
                <div>
                  <p className="text-white font-medium">Digital Transformation</p>
                  <p className="text-tech-cyan text-sm">Digital revenue growth accelerating. Mobile banking adoption up 23% YoY.</p>
                </div>
              </div>
            </div>
            <div className="space-y-3">
              <div className="flex items-start gap-3 p-3 rounded-lg bg-gradient-to-r from-tech-warning/20 to-transparent border-l-4 border-tech-warning">
                <AlertTriangle className="w-5 h-5 text-tech-warning mt-0.5" />
                <div>
                  <p className="text-white font-medium">Attention Required</p>
                  <p className="text-tech-cyan text-sm">Key talent attrition trending above comfortable threshold. Retention programs recommended.</p>
                </div>
              </div>
              <div className="flex items-start gap-3 p-3 rounded-lg bg-gradient-to-r from-tech-purple/20 to-transparent border-l-4 border-tech-purple">
                <TrendingUp className="w-5 h-5 text-tech-purple mt-0.5" />
                <div>
                  <p className="text-white font-medium">Innovation Pipeline</p>
                  <p className="text-tech-cyan text-sm">CenAI applications showing 340% ROI. Expansion opportunities identified in customer service.</p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}