import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, LineChart, Line } from 'recharts';
import { Shield, Users, AlertTriangle, CheckCircle, XCircle, TrendingUp, Building, Globe } from 'lucide-react';
import { Badge } from './ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';

interface OutsourcingManagementTabProps {
  filters: any;
  selectedPeriod: {
    year: number;
    month: number;
    monthName: string;
  };
  currentPeriodDisplay: string;
}

export function OutsourcingManagementTab({ filters, selectedPeriod, currentPeriodDisplay }: OutsourcingManagementTabProps) {
  // Vendor categories data
  const itpEtpData = [
    { name: 'ITP (Important to Program)', value: 8, color: '#db0011' },
    { name: 'ETP (Easy to Program)', value: 15, color: '#767676' }
  ];

  const importanceData = [
    { name: 'Important Vendors', value: 8, color: '#db0011' },
    { name: 'Non-Important', value: 15, color: '#347893' }
  ];

  const locationData = [
    { name: 'Local', value: 12, color: '#5d9438' },
    { name: 'Global', value: 11, color: '#ed6335' }
  ];

  // Vendor staff distribution
  const siteData = [
    { name: 'On-site', value: 180, color: '#db0011' },
    { name: 'Off-site', value: 320, color: '#347893' }
  ];

  const workTypeData = [
    { name: 'Development/Testing', value: 280, color: '#5d9438' },
    { name: 'Maintenance', value: 220, color: '#ed6335' }
  ];

  // Important vendor RAG status
  const vendorRagStatus = [
    { vendor: 'Accenture', status: 'Green', issues: 0, category: 'ITP', spending: 3200 },
    { vendor: 'TCS', status: 'Yellow', issues: 2, category: 'ITP', spending: 2800 },
    { vendor: 'Infosys', status: 'Green', issues: 1, category: 'ITP', spending: 2400 },
    { vendor: 'IBM', status: 'Red', issues: 5, category: 'ITP', spending: 2100 },
    { vendor: 'Wipro', status: 'Yellow', issues: 3, category: 'ITP', spending: 1900 },
    { vendor: 'Cognizant', status: 'Green', issues: 0, category: 'ITP', spending: 1600 },
    { vendor: 'HCL', status: 'Green', issues: 1, category: 'ITP', spending: 1400 },
    { vendor: 'Capgemini', status: 'Yellow', issues: 2, category: 'ITP', spending: 1200 }
  ];

  // Monthly spending trend
  const spendingTrendData = [
    { month: 'Jan', accenture: 3100, tcs: 2750, infosys: 2300, ibm: 2050, others: 4800 },
    { month: 'Feb', accenture: 3200, tcs: 2800, infosys: 2400, ibm: 2100, others: 4900 },
    { month: 'Mar', accenture: 3150, tcs: 2780, infosys: 2350, ibm: 2080, others: 4850 },
    { month: 'Apr', accenture: 3250, tcs: 2850, infosys: 2450, ibm: 2150, others: 4950 },
    { month: 'May', accenture: 3200, tcs: 2800, infosys: 2400, ibm: 2100, others: 4900 },
    { month: 'Jun', accenture: 3300, tcs: 2900, infosys: 2500, ibm: 2200, others: 5000 }
  ];

  // YTD vendor spending
  const ytdSpendingData = [
    { vendor: 'Accenture', amount: 19200, change: 5.2 },
    { vendor: 'TCS', amount: 16950, change: 3.8 },
    { vendor: 'Infosys', amount: 14400, change: 2.1 },
    { vendor: 'IBM', amount: 12680, change: -1.5 },
    { vendor: 'Wipro', amount: 11400, change: 4.3 },
    { vendor: 'Cognizant', amount: 9600, change: 2.8 },
    { vendor: 'HCL', amount: 8400, change: 1.2 },
    { vendor: 'Capgemini', amount: 7200, change: -0.8 }
  ];

  // Open issues by vendor
  const openIssuesData = [
    { vendor: 'IBM', critical: 2, high: 2, medium: 1, total: 5 },
    { vendor: 'Wipro', critical: 1, high: 1, medium: 1, total: 3 },
    { vendor: 'TCS', critical: 0, high: 1, medium: 1, total: 2 },
    { vendor: 'Capgemini', critical: 0, high: 1, medium: 1, total: 2 },
    { vendor: 'Infosys', critical: 0, high: 0, medium: 1, total: 1 },
    { vendor: 'HCL', critical: 0, high: 0, medium: 1, total: 1 }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Green': return 'bg-green-100 text-green-800';
      case 'Yellow': return 'bg-yellow-100 text-yellow-800';
      case 'Red': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Green': return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'Yellow': return <AlertTriangle className="h-4 w-4 text-yellow-600" />;
      case 'Red': return <XCircle className="h-4 w-4 text-red-600" />;
      default: return null;
    }
  };

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white p-3 border border-hsbc-grey-medium rounded-lg shadow-lg">
          <p className="font-medium">{data.name}</p>
          <p className="text-hsbc-red">
            {data.value} {typeof data.value === 'number' && data.value > 100 ? 'staff' : 'vendors'}
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Data Context Header */}
      <div className="bg-white border border-hsbc-orange-3 rounded-lg p-4">
        <div className="flex items-center gap-3">
          <div className="w-3 h-3 bg-hsbc-orange-3 rounded-full"></div>
          <h3 className="text-hsbc-orange-3 font-medium">Outsourcing data for {currentPeriodDisplay}</h3>
        </div>
      </div>
      {/* Section 1: Vendor Overview */}
      <div className="space-y-4">
        <h2 className="text-hsbc-grey-darker">Vendor Overview</h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* ITP vs ETP */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-sm">
                <Shield className="h-4 w-4 text-hsbc-red" />
                ITP vs ETP
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={itpEtpData}
                      cx="50%"
                      cy="50%"
                      outerRadius={60}
                      dataKey="value"
                    >
                      {itpEtpData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip content={<CustomTooltip />} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="space-y-1 mt-2">
                {itpEtpData.map((item) => (
                  <div key={item.name} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1">
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                      <span>{item.name.split(' ')[0]}</span>
                    </div>
                    <span>{item.value}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Important vs Non-Important */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-sm">
                <Building className="h-4 w-4 text-hsbc-red" />
                Important vs Non-Important
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={importanceData}
                      cx="50%"
                      cy="50%"
                      innerRadius={30}
                      outerRadius={60}
                      dataKey="value"
                    >
                      {importanceData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip content={<CustomTooltip />} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="space-y-1 mt-2">
                {importanceData.map((item) => (
                  <div key={item.name} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1">
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                      <span>{item.name.split(' ')[0]}</span>
                    </div>
                    <span>{item.value}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Local vs Global */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-sm">
                <Globe className="h-4 w-4 text-hsbc-red" />
                Local vs Global
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={locationData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="value" fill="#db0011" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Vendor Staff Distribution */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-hsbc-red" />
                On-site vs Off-site Staff
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={siteData}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      dataKey="value"
                    >
                      {siteData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip content={<CustomTooltip />} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="grid grid-cols-2 gap-4 mt-4">
                {siteData.map((item) => (
                  <div key={item.name} className="text-center">
                    <div className="flex items-center justify-center gap-1 mb-1">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                      <span className="text-sm">{item.name}</span>
                    </div>
                    <p className="text-lg font-medium">{item.value}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Dev/Testing vs Maintenance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={workTypeData} layout="horizontal">
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" />
                    <YAxis type="category" dataKey="name" width={120} />
                    <Tooltip />
                    <Bar dataKey="value" fill="#5d9438" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Section 2: Vendor Risk & Actions */}
      <div className="space-y-4">
        <h2 className="text-hsbc-grey-darker">Vendor Risk & Actions</h2>
        
        {/* RAG Status Dashboard */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-hsbc-red" />
              Important Vendor RAG Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {vendorRagStatus.map((vendor) => (
                <div key={vendor.vendor} className="bg-hsbc-grey-light p-4 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-sm">{vendor.vendor}</h4>
                    {getStatusIcon(vendor.status)}
                  </div>
                  <Badge className={`text-xs mb-2 ${getStatusColor(vendor.status)}`}>
                    {vendor.status}
                  </Badge>
                  <div className="text-xs text-hsbc-grey-dark">
                    <p>Issues: {vendor.issues}</p>
                    <p>Spending: ${vendor.spending}K</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Open Issues */}
        <Card>
          <CardHeader>
            <CardTitle>Open Issues/Actions by Vendor</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Vendor</TableHead>
                  <TableHead>Critical</TableHead>
                  <TableHead>High</TableHead>
                  <TableHead>Medium</TableHead>
                  <TableHead>Total</TableHead>
                  <TableHead>Priority Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {openIssuesData.map((issue) => (
                  <TableRow key={issue.vendor}>
                    <TableCell className="font-medium">{issue.vendor}</TableCell>
                    <TableCell>
                      {issue.critical > 0 && (
                        <Badge className="bg-red-100 text-red-800">{issue.critical}</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      {issue.high > 0 && (
                        <Badge className="bg-orange-100 text-orange-800">{issue.high}</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      {issue.medium > 0 && (
                        <Badge className="bg-yellow-100 text-yellow-800">{issue.medium}</Badge>
                      )}
                    </TableCell>
                    <TableCell>{issue.total}</TableCell>
                    <TableCell className="text-xs">
                      {issue.critical > 0 ? 'Escalate to Exec' : 
                       issue.high > 0 ? 'RM Review Req' : 
                       'Monitor Progress'}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {/* Section 3: Spending Analysis */}
      <div className="space-y-4">
        <h2 className="text-hsbc-grey-darker">Spending Analysis</h2>
        
        {/* Monthly Trend */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-hsbc-red" />
              Monthly Spending Trend by Vendor
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={spendingTrendData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="accenture" stroke="#db0011" strokeWidth={2} name="Accenture" />
                  <Line type="monotone" dataKey="tcs" stroke="#347893" strokeWidth={2} name="TCS" />
                  <Line type="monotone" dataKey="infosys" stroke="#5d9438" strokeWidth={2} name="Infosys" />
                  <Line type="monotone" dataKey="ibm" stroke="#ed6335" strokeWidth={2} name="IBM" />
                  <Line type="monotone" dataKey="others" stroke="#767676" strokeWidth={2} name="Others" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* YTD Spending */}
        <Card>
          <CardHeader>
            <CardTitle>YTD Total by Vendor</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {ytdSpendingData.map((vendor, index) => (
                <div key={vendor.vendor} className="flex items-center justify-between p-3 bg-hsbc-grey-light rounded-lg">
                  <div className="flex items-center gap-3">
                    <Badge variant="secondary" className="w-8 h-8 rounded-full flex items-center justify-center">
                      {index + 1}
                    </Badge>
                    <div>
                      <p className="font-medium">{vendor.vendor}</p>
                      <p className="text-sm text-hsbc-grey-dark">
                        {vendor.change > 0 ? '+' : ''}{vendor.change}% vs last period
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">${vendor.amount.toLocaleString()}K</p>
                    <div className="w-20 h-2 bg-hsbc-grey-medium rounded-full mt-1">
                      <div 
                        className="h-2 bg-hsbc-red rounded-full" 
                        style={{ width: `${(vendor.amount / ytdSpendingData[0].amount) * 100}%` }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}