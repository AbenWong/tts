import { useState, useEffect, useRef } from 'react';
import { Send, User, Bot, Phone } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ScrollArea } from './ui/scroll-area';
import { HSBCChatbotService } from '../services/chatbotService';
import { PaymentModal } from './PaymentModal';
import { PasswordResetModal } from './PasswordResetModal';
import { DocumentUploadModal } from './DocumentUploadModal';
import { PaymentStatusModal } from './PaymentStatusModal';

interface Message {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  actions?: string[];
  messageType?: 'info' | 'success' | 'warning' | 'error';
}

export function ChatInterface() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'assistant',
      content: 'Hello! I\'m your HSBCnet AI Assistant. I can help you with payments, account access, security devices, statements, and more. How can I assist you today?',
      timestamp: new Date(),
      actions: ['Make a Payment', 'Reset Password', 'Upload Document', 'Payment Status']
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  
  // Modal states
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showStatusModal, setShowStatusModal] = useState(false);

  const quickActions = [
    'Make a Payment',
    'Reset Password', 
    'Upload Document',
    'Payment Status'
  ];

  // Auto-scroll to bottom when new messages are added
  useEffect(() => {
    if (scrollAreaRef.current) {
      const scrollContainer = scrollAreaRef.current.querySelector('[data-radix-scroll-area-viewport]');
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight;
      }
    }
  }, [messages]);

  const handleSendMessage = () => {
    if (!inputValue.trim() || isTyping) return;
    
    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: inputValue,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    const currentInput = inputValue;
    setInputValue('');
    setIsTyping(true);
    
    // Get AI response
    setTimeout(() => {
      const chatResponse = HSBCChatbotService.getResponse(currentInput);
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: chatResponse.content,
        timestamp: new Date(),
        actions: chatResponse.actions,
        messageType: chatResponse.type
      };
      setMessages(prev => [...prev, assistantMessage]);
      setIsTyping(false);
    }, 800 + Math.random() * 1200); // Realistic typing delay
  };

  const handleQuickAction = (action: string) => {
    // Handle modal opening for specific actions
    if (action === 'Make a Payment') {
      setShowPaymentModal(true);
    } else if (action === 'Reset Password') {
      setShowPasswordModal(true);
    } else if (action === 'Upload Document') {
      setShowUploadModal(true);
    } else if (action === 'Payment Status') {
      setShowStatusModal(true);
    } else {
      // For other actions, send as message
      setInputValue(action);
    }
    
    // Also send the action as a chat message for context
    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user', 
      content: action,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setIsTyping(true);
    
    setTimeout(() => {
      const chatResponse = HSBCChatbotService.getQuickActionResponse(action);
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: chatResponse.content,
        timestamp: new Date(),
        actions: chatResponse.actions,
        messageType: chatResponse.type
      };
      setMessages(prev => [...prev, assistantMessage]);
      setIsTyping(false);
    }, 500);
  };

  const handleActionButtonClick = (action: string) => {
    if (action === 'Open Payment Form') {
      setShowPaymentModal(true);
    } else if (action === 'Start Password Reset') {
      setShowPasswordModal(true);
    } else if (action === 'Open Upload Form') {
      setShowUploadModal(true);
    } else if (action === 'Check Payment Status') {
      setShowStatusModal(true);
    } else if (action === 'Escalate to Agent') {
      handleEscalateToAgent();
    } else {
      // Send as regular message
      setInputValue(action);
    }
  };

  const handleEscalateToAgent = () => {
    const escalationMessage: Message = {
      id: Date.now().toString(),
      type: 'assistant',
      content: 'I\'m connecting you to a live agent. Please hold on while I transfer your chat. A specialist will be with you shortly to provide personalized assistance.',
      timestamp: new Date(),
      messageType: 'info'
    };
    setMessages(prev => [...prev, escalationMessage]);
    
    // Simulate connection delay
    setTimeout(() => {
      const agentMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: 'Hello! This is Sarah from HSBC Business Banking. I\'ve reviewed your previous messages and I\'m here to help. How can I assist you today?',
        timestamp: new Date(),
        messageType: 'success'
      };
      setMessages(prev => [...prev, agentMessage]);
    }, 3000);
  };

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Chat Header */}
      <div className="p-4 md:p-6 border-b border-hsbc-grey-medium">
        <h2 className="text-lg md:text-xl text-foreground">Ask HSBCnet AI Assistant</h2>
      </div>

      {/* Chat Messages */}
      <ScrollArea className="flex-1 p-4 md:p-6" ref={scrollAreaRef}>
        <div className="space-y-4">
          {messages.map((message) => (
            <div key={message.id} className="space-y-2">
              <div
                className={`flex items-start space-x-3 ${
                  message.type === 'user' ? 'justify-end' : 'justify-start'
                }`}
              >
                {message.type === 'assistant' && (
                  <div className="w-8 h-8 bg-hsbc-grey-light rounded-full flex items-center justify-center flex-shrink-0">
                    <Bot className="h-4 w-4 text-hsbc-grey-dark" />
                  </div>
                )}
                
                <div
                  className={`max-w-[85%] md:max-w-md px-3 md:px-4 py-2 md:py-3 rounded-lg ${
                    message.type === 'user'
                      ? 'bg-white border-2 border-hsbc-red text-foreground'
                      : message.messageType === 'warning'
                      ? 'bg-yellow-50 border border-yellow-200 text-foreground'
                      : message.messageType === 'error'
                      ? 'bg-red-50 border border-red-200 text-foreground'
                      : message.messageType === 'success'
                      ? 'bg-green-50 border border-green-200 text-foreground'
                      : 'bg-hsbc-grey-light text-foreground'
                  }`}
                >
                  <p className="whitespace-pre-line text-sm md:text-base">{message.content}</p>
                </div>
                
                {message.type === 'user' && (
                  <div className="w-8 h-8 bg-hsbc-red rounded-full flex items-center justify-center flex-shrink-0">
                    <User className="h-4 w-4 text-white" />
                  </div>
                )}
              </div>

              {/* Action buttons for assistant messages */}
              {message.type === 'assistant' && message.actions && (
                <div className="ml-8 md:ml-11 flex flex-wrap gap-2">
                  {message.actions.map((action) => (
                    <Button
                      key={action}
                      variant="outline"
                      size="sm"
                      onClick={() => handleActionButtonClick(action)}
                      className="border-hsbc-grey-medium hover:border-hsbc-red hover:text-hsbc-red"
                    >
                      {action}
                    </Button>
                  ))}
                </div>
              )}
            </div>
          ))}

          {/* Typing indicator */}
          {isTyping && (
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 bg-hsbc-grey-light rounded-full flex items-center justify-center flex-shrink-0">
                <Bot className="h-4 w-4 text-hsbc-grey-dark" />
              </div>
              <div className="bg-hsbc-grey-light px-4 py-3 rounded-lg">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-hsbc-grey-dark rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-hsbc-grey-dark rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                  <div className="w-2 h-2 bg-hsbc-grey-dark rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                </div>
              </div>
            </div>
          )}
        </div>
      </ScrollArea>

      {/* Quick Actions */}
      <div className="p-4 md:p-6 border-t border-hsbc-grey-medium">
        <div className="flex flex-wrap gap-2 mb-4">
          {quickActions.map((action) => (
            <Button
              key={action}
              variant="outline"
              size="sm"
              onClick={() => handleQuickAction(action)}
              className="border-hsbc-grey-medium hover:border-hsbc-red hover:text-hsbc-red"
            >
              {action}
            </Button>
          ))}
        </div>

        {/* Chat Input */}
        <div className="flex space-x-2">
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Type your question or choose from options…"
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            className="flex-1 text-sm md:text-base"
          />
          <Button onClick={handleSendMessage} className="bg-hsbc-red hover:bg-hsbc-red/90 px-3" disabled={isTyping}>
            <Send className="h-4 w-4" />
          </Button>
        </div>

        {/* Escalate Button */}
        <Button 
          variant="outline" 
          onClick={handleEscalateToAgent}
          className="w-full mt-3 border-hsbc-red text-hsbc-red hover:bg-hsbc-red hover:text-white"
          disabled={isTyping}
        >
          <Phone className="h-4 w-4 mr-2" />
          Escalate to Live Agent
        </Button>
      </div>

      {/* Modals */}
      <PaymentModal isOpen={showPaymentModal} onClose={() => setShowPaymentModal(false)} />
      <PasswordResetModal isOpen={showPasswordModal} onClose={() => setShowPasswordModal(false)} />
      <DocumentUploadModal isOpen={showUploadModal} onClose={() => setShowUploadModal(false)} />
      <PaymentStatusModal isOpen={showStatusModal} onClose={() => setShowStatusModal(false)} />
    </div>
  );
}