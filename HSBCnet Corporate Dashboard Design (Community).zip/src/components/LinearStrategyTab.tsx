import { LinearDataModule } from './LinearDataModule';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { 
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell, ComposedChart
} from 'recharts';
import { 
  TrendingUp, DollarSign, Smartphone, Brain, Star, Users,
  Target, Zap, Award, ArrowUp, ArrowDown
} from 'lucide-react';

interface LinearStrategyTabProps {
  filters: any;
  selectedPeriod: any;
  currentPeriodDisplay: string;
}

export function LinearStrategyTab({ filters, selectedPeriod, currentPeriodDisplay }: LinearStrategyTabProps) {
  
  // Tech Investment Data
  const investmentData = {
    totalInvestment: 2.4,
    revenuePercentage: 15.7,
    valueContribution: 24.7,
    roi: 340
  };

  // Digital Transformation Metrics
  const digitalTrendData = [
    { month: 'Jan', online: 58.2, digital: 62.1 },
    { month: 'Feb', online: 61.5, digital: 64.3 },
    { month: 'Mar', online: 63.8, digital: 66.8 },
    { month: 'Apr', online: 66.2, digital: 68.9 },
    { month: 'May', online: 68.7, digital: 71.2 },
    { month: 'Jun', online: 71.1, digital: 73.5 }
  ];

  const digitalRevenueData = [
    { category: 'Mobile Banking', percentage: 45.2, value: 1.8 },
    { category: 'Online Lending', percentage: 28.7, value: 1.1 },
    { category: 'Digital Payments', percentage: 18.4, value: 0.7 },
    { category: 'Robo Advisory', percentage: 7.7, value: 0.3 }
  ];

  // Customer Satisfaction
  const customerMetrics = {
    nps: 67,
    satisfaction: 4.3,
    digitalSatisfaction: 4.5
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-white text-3xl font-semibold linear-header mb-2">Strategy & Value</h1>
        <p className="text-gray-400 linear-body">Technology Investment Impact & Digital Transformation - {currentPeriodDisplay}</p>
      </div>

      {/* Investment Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <LinearDataModule title="Total Investment" icon={DollarSign} size="small">
          <div className="text-center">
            <div className="linear-metric text-linear-accent text-2xl">${investmentData.totalInvestment}B</div>
            <p className="text-linear-text-muted text-sm linear-body">{investmentData.revenuePercentage}% of revenue</p>
          </div>
        </LinearDataModule>

        <LinearDataModule title="Business Value" icon={Target} size="small">
          <div className="text-center">
            <div className="linear-metric text-linear-positive text-2xl">{investmentData.valueContribution}%</div>
            <div className="flex items-center justify-center gap-1 mt-2">
              <ArrowUp className="h-3 w-3 text-linear-positive" />
              <p className="text-linear-positive text-xs linear-body">+3.2% vs Q1</p>
            </div>
          </div>
        </LinearDataModule>

        <LinearDataModule title="Technology ROI" icon={TrendingUp} size="small">
          <div className="text-center">
            <div className="linear-metric text-linear-neutral text-2xl">{investmentData.roi}%</div>
            <p className="text-linear-text-muted text-sm linear-body">Industry leading</p>
          </div>
        </LinearDataModule>

        <LinearDataModule title="CenAI Scenarios" icon={Brain} size="small">
          <div className="text-center">
            <div className="linear-metric text-linear-accent text-2xl">47</div>
            <div className="flex items-center justify-center gap-1 mt-2">
              <ArrowUp className="h-3 w-3 text-linear-positive" />
              <p className="text-linear-positive text-xs linear-body">+23% growth</p>
            </div>
          </div>
        </LinearDataModule>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Digital Transformation Trend */}
        <LinearDataModule title="Digital Transformation Progress" icon={Zap} size="large">
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={digitalTrendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#2D3748" />
                <XAxis dataKey="month" stroke="#718096" />
                <YAxis stroke="#718096" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#ffffff', 
                    border: '1px solid #2D3748',
                    borderRadius: '8px',
                    color: '#1a202c'
                  }}
                />
                <Area type="monotone" dataKey="online" stackId="1" stroke="#4361EE" fill="#4361EE" fillOpacity={0.6} />
                <Area type="monotone" dataKey="digital" stackId="1" stroke="#8B5CF6" fill="#8B5CF6" fillOpacity={0.6} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </LinearDataModule>

        {/* Digital Revenue Breakdown */}
        <LinearDataModule title="Digital Revenue by Channel" icon={DollarSign} size="large">
          <div className="space-y-4">
            {digitalRevenueData.map((item, index) => (
              <div key={item.category} className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-linear-text-primary linear-body">{item.category}</span>
                  <span className="text-linear-text-secondary linear-metric">{item.percentage}% (${item.value}B)</span>
                </div>
                <Progress value={item.percentage} className="h-2" />
              </div>
            ))}
          </div>
        </LinearDataModule>
      </div>

      {/* Customer Satisfaction */}
      <LinearDataModule title="Customer Experience & Satisfaction" icon={Star} size="large">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="relative w-24 h-24 mx-auto mb-4">
              <svg className="w-24 h-24 transform -rotate-90">
                <circle
                  cx="48"
                  cy="48"
                  r="40"
                  stroke="#E2E8F0"
                  strokeWidth="8"
                  fill="transparent"
                />
                <circle
                  cx="48"
                  cy="48"
                  r="40"
                  stroke="#4361EE"
                  strokeWidth="8"
                  fill="transparent"
                  strokeLinecap="round"
                  strokeDasharray={`${(customerMetrics.nps / 100) * 251.2} 251.2`}
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-2xl font-semibold text-linear-text-primary linear-metric">{customerMetrics.nps}</span>
              </div>
            </div>
            <p className="text-linear-text-primary linear-header font-medium">Net Promoter Score</p>
            <p className="text-linear-text-muted text-sm linear-body">Industry Leading</p>
          </div>
          
          <div className="text-center">
            <div className="relative w-24 h-24 mx-auto mb-4">
              <svg className="w-24 h-24 transform -rotate-90">
                <circle
                  cx="48"
                  cy="48"
                  r="40"
                  stroke="#E2E8F0"
                  strokeWidth="8"
                  fill="transparent"
                />
                <circle
                  cx="48"
                  cy="48"
                  r="40"
                  stroke="#10B981"
                  strokeWidth="8"
                  fill="transparent"
                  strokeLinecap="round"
                  strokeDasharray={`${(customerMetrics.satisfaction / 5) * 251.2} 251.2`}
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-2xl font-semibold text-linear-text-primary linear-metric">{customerMetrics.satisfaction}</span>
              </div>
            </div>
            <p className="text-linear-text-primary linear-header font-medium">Overall Satisfaction</p>
            <p className="text-linear-text-muted text-sm linear-body">Out of 5.0</p>
          </div>
          
          <div className="text-center">
            <div className="relative w-24 h-24 mx-auto mb-4">
              <svg className="w-24 h-24 transform -rotate-90">
                <circle
                  cx="48"
                  cy="48"
                  r="40"
                  stroke="#E2E8F0"
                  strokeWidth="8"
                  fill="transparent"
                />
                <circle
                  cx="48"
                  cy="48"
                  r="40"
                  stroke="#8B5CF6"
                  strokeWidth="8"
                  fill="transparent"
                  strokeLinecap="round"
                  strokeDasharray={`${(customerMetrics.digitalSatisfaction / 5) * 251.2} 251.2`}
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-2xl font-semibold text-linear-text-primary linear-metric">{customerMetrics.digitalSatisfaction}</span>
              </div>
            </div>
            <p className="text-linear-text-primary linear-header font-medium">Digital Satisfaction</p>
            <p className="text-linear-text-muted text-sm linear-body">Mobile & Online</p>
          </div>
        </div>
      </LinearDataModule>
    </div>
  );
}