import { useEffect, useRef } from 'react';

export function EarthVisualization() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    const size = 400;
    canvas.width = size;
    canvas.height = size;

    let animationFrame: number;
    let rotation = 0;

    const drawEarth = () => {
      ctx.clearRect(0, 0, size, size);
      
      const centerX = size / 2;
      const centerY = size / 2;
      const radius = size * 0.35;

      // Create radial gradient for depth
      const gradient = ctx.createRadialGradient(
        centerX - radius * 0.3, centerY - radius * 0.3, 0,
        centerX, centerY, radius
      );
      gradient.addColorStop(0, '#4A90E2');
      gradient.addColorStop(0.7, '#2E5C8A');
      gradient.addColorStop(1, '#1B3A5C');

      // Draw main sphere
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
      ctx.fillStyle = gradient;
      ctx.fill();

      // Add continents (simplified)
      ctx.fillStyle = '#3E5C2A';
      drawContinents(ctx, centerX, centerY, radius, rotation);

      // Add atmospheric glow
      const glowGradient = ctx.createRadialGradient(
        centerX, centerY, radius,
        centerX, centerY, radius * 1.15
      );
      glowGradient.addColorStop(0, 'rgba(135, 206, 235, 0.3)');
      glowGradient.addColorStop(1, 'rgba(135, 206, 235, 0)');
      
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius * 1.15, 0, Math.PI * 2);
      ctx.fillStyle = glowGradient;
      ctx.fill();

      // Update rotation
      rotation += 0.003;
      animationFrame = requestAnimationFrame(drawEarth);
    };

    const drawContinents = (ctx: CanvasRenderingContext2D, x: number, y: number, r: number, rot: number) => {
      // Simplified continent shapes that appear to move as Earth rotates
      const continents = [
        // North America
        { x: -0.3, y: -0.2, w: 0.4, h: 0.6 },
        // Europe/Africa
        { x: 0.1, y: -0.1, w: 0.3, h: 0.8 },
        // Asia
        { x: 0.5, y: -0.3, w: 0.4, h: 0.5 },
        // South America
        { x: -0.2, y: 0.3, w: 0.2, h: 0.4 }
      ];

      continents.forEach(continent => {
        const adjustedX = continent.x * Math.cos(rot) * r + x;
        const adjustedY = continent.y * r + y;
        const adjustedW = continent.w * r * Math.abs(Math.cos(rot));
        const adjustedH = continent.h * r;

        if (Math.cos(rot) > 0) { // Only draw if facing us
          ctx.fillRect(
            adjustedX - adjustedW / 2,
            adjustedY - adjustedH / 2,
            adjustedW,
            adjustedH
          );
        }
      });
    };

    drawEarth();

    return () => {
      if (animationFrame) {
        cancelAnimationFrame(animationFrame);
      }
    };
  }, []);

  return (
    <div className="flex items-center justify-center">
      <div className="relative">
        <canvas
          ref={canvasRef}
          className="earth-glow rounded-full"
          style={{ filter: 'drop-shadow(0 20px 40px rgba(67, 97, 238, 0.15))' }}
        />
        {/* Subtle orbiting elements */}
        <div className="absolute inset-0 pointer-events-none">
          <div 
            className="absolute w-2 h-2 bg-linear-accent rounded-full opacity-60"
            style={{
              top: '20%',
              left: '80%',
              animation: 'earthSpin 60s linear infinite reverse'
            }}
          />
          <div 
            className="absolute w-1.5 h-1.5 bg-linear-positive rounded-full opacity-40"
            style={{
              top: '70%',
              left: '15%',
              animation: 'earthSpin 45s linear infinite'
            }}
          />
        </div>
      </div>
    </div>
  );
}