import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { 
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell, ComposedChart, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar
} from 'recharts';
import { 
  Activity, Zap, Clock, Server, Gauge, Bot, Shield, AlertTriangle,
  CheckCircle, TrendingUp, Cpu, HardDrive, Wifi, Database
} from 'lucide-react';

interface OperationsEfficiencyTabProps {
  filters: any;
  selectedPeriod: any;
  currentPeriodDisplay: string;
}

export function OperationsEfficiencyTab({ filters, selectedPeriod, currentPeriodDisplay }: OperationsEfficiencyTabProps) {
  
  // System Reliability Metrics
  const reliabilityMetrics = {
    availability: 99.97,
    mttr: 2.3, // hours
    changeSuccessRate: 94.5,
    incidentCount: 23,
    slaAchievement: 98.7
  };

  // Real-time Application Performance
  const appPerformanceData = [
    { time: '00:00', corebanking: 45, payments: 32, mobile: 28, web: 35 },
    { time: '04:00', corebanking: 42, payments: 30, mobile: 25, web: 33 },
    { time: '08:00', corebanking: 67, payments: 55, mobile: 48, web: 52 },
    { time: '12:00', corebanking: 89, payments: 78, mobile: 72, web: 75 },
    { time: '16:00', corebanking: 95, payments: 85, mobile: 82, web: 88 },
    { time: '20:00', corebanking: 78, payments: 68, mobile: 65, web: 72 }
  ];

  // Data Center PUE Trend
  const pueData = [
    { month: 'Jan', actual: 1.42, target: 1.40, efficiency: 88.2 },
    { month: 'Feb', actual: 1.39, target: 1.40, efficiency: 89.1 },
    { month: 'Mar', actual: 1.37, target: 1.40, efficiency: 90.3 },
    { month: 'Apr', actual: 1.35, target: 1.40, efficiency: 91.7 },
    { month: 'May', actual: 1.33, target: 1.40, efficiency: 92.8 },
    { month: 'Jun', actual: 1.31, target: 1.40, efficiency: 93.6 }
  ];

  // Automation Coverage
  const automationData = [
    { process: 'Incident Management', coverage: 85, manual: 15 },
    { process: 'Change Management', coverage: 78, manual: 22 },
    { process: 'Backup Operations', coverage: 95, manual: 5 },
    { process: 'Monitoring Alerts', coverage: 92, manual: 8 },
    { process: 'User Provisioning', coverage: 73, manual: 27 },
    { process: 'Patch Management', coverage: 88, manual: 12 }
  ];

  // Resource Utilization Heatmap Data
  const resourceUtilization = [
    { resource: 'CPU', current: 73, peak: 89, avg: 65 },
    { resource: 'Memory', current: 68, peak: 84, avg: 62 },
    { resource: 'Storage', current: 82, peak: 91, avg: 75 },
    { resource: 'Network', current: 56, peak: 78, avg: 52 },
    { resource: 'Database', current: 71, peak: 87, avg: 68 }
  ];

  // Core TPS Performance
  const tpsData = [
    { time: '14:00', tps: 12450, capacity: 15000, utilization: 83 },
    { time: '14:15', tps: 13200, capacity: 15000, utilization: 88 },
    { time: '14:30', tps: 14100, capacity: 15000, utilization: 94 },
    { time: '14:45', tps: 13800, capacity: 15000, utilization: 92 },
    { time: '15:00', tps: 12900, capacity: 15000, utilization: 86 }
  ];

  // MTTR Incidents Timeline
  const mttrIncidents = [
    { id: 'INC-001', severity: 'P1', duration: 1.2, resolved: true },
    { id: 'INC-002', severity: 'P2', duration: 3.5, resolved: true },
    { id: 'INC-003', severity: 'P3', duration: 0.8, resolved: true },
    { id: 'INC-004', severity: 'P1', duration: 2.1, resolved: true },
    { id: 'INC-005', severity: 'P2', duration: 4.2, resolved: false }
  ];

  const COLORS = ['#4361EE', '#7209B7', '#4CC9F0', '#10B981', '#F59E0B'];

  const getUtilizationColor = (value: number) => {
    if (value >= 90) return 'text-tech-alert';
    if (value >= 75) return 'text-tech-warning';
    return 'text-tech-success';
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'P1': return 'bg-tech-alert';
      case 'P2': return 'bg-tech-warning';
      case 'P3': return 'bg-tech-success';
      default: return 'bg-tech-blue';
    }
  };

  return (
    <div className="p-6 space-y-6 bg-tech-navy min-h-screen">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div className="animate-fade-in-up">
          <h1 className="text-3xl font-bold text-white mb-2 glow-text">OPERATIONS & EFFICIENCY</h1>
          <p className="text-tech-cyan">Real-time System Performance & Resource Monitoring - {currentPeriodDisplay}</p>
        </div>
      </div>

      {/* System Reliability KPIs */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <Card className="glass-morphism neon-border animate-slide-in">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-tech-cyan text-sm">System Availability</p>
                <p className="text-3xl font-bold text-tech-success tech-counter">{reliabilityMetrics.availability}%</p>
                <div className="w-16 h-16 relative mt-2">
                  <svg className="w-16 h-16 transform -rotate-90">
                    <circle
                      cx="32"
                      cy="32"
                      r="28"
                      stroke="rgba(76, 201, 240, 0.2)"
                      strokeWidth="4"
                      fill="transparent"
                    />
                    <circle
                      cx="32"
                      cy="32"
                      r="28"
                      stroke="#10B981"
                      strokeWidth="4"
                      fill="transparent"
                      strokeLinecap="round"
                      strokeDasharray={`${(reliabilityMetrics.availability / 100) * 175.9} 175.9`}
                      className="pulse-glow"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Activity className="h-6 w-6 text-tech-success" />
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="glass-morphism neon-border animate-slide-in">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-tech-cyan text-sm">Mean Time to Recovery</p>
                <p className="text-3xl font-bold text-tech-blue tech-counter">{reliabilityMetrics.mttr}h</p>
                <div className="flex items-center gap-1 mt-2">
                  <Clock className="h-4 w-4 text-tech-cyan" />
                  <p className="text-xs text-tech-success">-15% vs target</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="glass-morphism neon-border animate-slide-in">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-tech-cyan text-sm">Change Success Rate</p>
                <p className="text-3xl font-bold text-tech-purple tech-counter">{reliabilityMetrics.changeSuccessRate}%</p>
                <Progress value={reliabilityMetrics.changeSuccessRate} className="h-2 mt-2" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="glass-morphism neon-border animate-slide-in">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-tech-cyan text-sm">Active Incidents</p>
                <p className="text-3xl font-bold text-tech-warning tech-counter">{reliabilityMetrics.incidentCount}</p>
                <div className="flex items-center gap-1 mt-2">
                  <AlertTriangle className="h-4 w-4 text-tech-warning" />
                  <p className="text-xs text-tech-cyan">3 P1, 8 P2, 12 P3</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="glass-morphism neon-border animate-slide-in">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-tech-cyan text-sm">SLA Achievement</p>
                <p className="text-3xl font-bold text-tech-cyan tech-counter">{reliabilityMetrics.slaAchievement}%</p>
                <div className="flex items-center gap-1 mt-2">
                  <CheckCircle className="h-4 w-4 text-tech-success" />
                  <p className="text-xs text-tech-success">Above target</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Application Performance Monitoring */}
      <Card className="glass-morphism neon-border animate-fade-in-up">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2 glow-text">
            <Gauge className="w-5 h-5 text-tech-blue" />
            APPLICATION RESPONSE TIMES (Real-time)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={appPerformanceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(76, 201, 240, 0.1)" />
                <XAxis dataKey="time" stroke="#4CC9F0" />
                <YAxis stroke="#4CC9F0" label={{ value: 'Response Time (ms)', angle: -90, position: 'insideLeft', style: { textAnchor: 'middle', fill: '#4CC9F0' } }} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'rgba(10, 12, 23, 0.9)', 
                    border: '1px solid #4CC9F0',
                    borderRadius: '8px',
                    color: '#ffffff'
                  }}
                />
                <Line type="monotone" dataKey="corebanking" stroke="#4361EE" strokeWidth={3} name="Core Banking" />
                <Line type="monotone" dataKey="payments" stroke="#7209B7" strokeWidth={3} name="Payments" />
                <Line type="monotone" dataKey="mobile" stroke="#4CC9F0" strokeWidth={3} name="Mobile App" />
                <Line type="monotone" dataKey="web" stroke="#10B981" strokeWidth={3} name="Web Portal" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Data Center PUE */}
        <Card className="glass-morphism neon-border animate-fade-in-up">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2 glow-text">
              <Server className="w-5 h-5 text-tech-purple" />
              DATA CENTER EFFICIENCY (PUE)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={pueData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(76, 201, 240, 0.1)" />
                  <XAxis dataKey="month" stroke="#4CC9F0" />
                  <YAxis yAxisId="left" stroke="#4CC9F0" />
                  <YAxis yAxisId="right" orientation="right" stroke="#7209B7" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'rgba(10, 12, 23, 0.9)', 
                      border: '1px solid #4CC9F0',
                      borderRadius: '8px',
                      color: '#ffffff'
                    }}
                  />
                  <Bar yAxisId="right" dataKey="efficiency" fill="#7209B7" fillOpacity={0.6} name="Efficiency %" />
                  <Line yAxisId="left" type="monotone" dataKey="actual" stroke="#4361EE" strokeWidth={3} name="Actual PUE" />
                  <Line yAxisId="left" type="monotone" dataKey="target" stroke="#10B981" strokeWidth={2} strokeDasharray="5 5" name="Target PUE" />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Automation Coverage */}
        <Card className="glass-morphism neon-border animate-fade-in-up">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2 glow-text">
              <Bot className="w-5 h-5 text-tech-cyan" />
              AUTOMATION COVERAGE
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {automationData.map((item, index) => (
                <div key={item.process} className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-white text-sm">{item.process}</span>
                    <span className="text-tech-cyan font-bold tech-counter">{item.coverage}%</span>
                  </div>
                  <div className="relative">
                    <Progress value={item.coverage} className="h-3" />
                    <div className="absolute top-0 right-0 h-3 bg-tech-alert/30 rounded-r" style={{ width: `${item.manual}%` }}></div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Resource Utilization & Core TPS */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Resource Utilization Heatmap */}
        <Card className="glass-morphism neon-border animate-fade-in-up">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2 glow-text">
              <Cpu className="w-5 h-5 text-tech-blue" />
              RESOURCE UTILIZATION HEATMAP
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {resourceUtilization.map((resource, index) => (
                <div key={resource.resource} className="p-4 rounded-lg glass-morphism">
                  <div className="flex justify-between items-center mb-3">
                    <span className="text-white font-medium">{resource.resource}</span>
                    <div className="flex items-center gap-2">
                      {resource.resource === 'CPU' && <Cpu className="w-4 h-4 text-tech-blue" />}
                      {resource.resource === 'Memory' && <HardDrive className="w-4 h-4 text-tech-purple" />}
                      {resource.resource === 'Storage' && <HardDrive className="w-4 h-4 text-tech-cyan" />}
                      {resource.resource === 'Network' && <Wifi className="w-4 h-4 text-tech-success" />}
                      {resource.resource === 'Database' && <Database className="w-4 h-4 text-tech-warning" />}
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="text-center p-2 rounded bg-tech-glass">
                      <div className={`text-lg font-bold tech-counter ${getUtilizationColor(resource.current)}`}>
                        {resource.current}%
                      </div>
                      <div className="text-xs text-tech-cyan">Current</div>
                    </div>
                    <div className="text-center p-2 rounded bg-tech-glass">
                      <div className={`text-lg font-bold tech-counter ${getUtilizationColor(resource.peak)}`}>
                        {resource.peak}%
                      </div>
                      <div className="text-xs text-tech-cyan">Peak</div>
                    </div>
                    <div className="text-center p-2 rounded bg-tech-glass">
                      <div className="text-lg font-bold tech-counter text-white">
                        {resource.avg}%
                      </div>
                      <div className="text-xs text-tech-cyan">Average</div>
                    </div>
                  </div>
                  <Progress value={resource.current} className="h-2 mt-3" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Core TPS Capacity */}
        <Card className="glass-morphism neon-border animate-fade-in-up">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2 glow-text">
              <Zap className="w-5 h-5 text-tech-warning" />
              CORE TPS CAPACITY (Real-time)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="mb-6">
              <div className="text-center mb-4">
                <div className="text-4xl font-bold text-tech-cyan tech-counter">
                  {tpsData[tpsData.length - 1].tps.toLocaleString()}
                </div>
                <div className="text-tech-cyan text-sm">Current TPS</div>
                <div className="text-tech-purple text-xs">
                  Capacity: {tpsData[tpsData.length - 1].capacity.toLocaleString()} TPS
                </div>
              </div>
              
              {/* Real-time TPS Chart */}
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={tpsData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(76, 201, 240, 0.1)" />
                    <XAxis dataKey="time" stroke="#4CC9F0" />
                    <YAxis stroke="#4CC9F0" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'rgba(10, 12, 23, 0.9)', 
                        border: '1px solid #4CC9F0',
                        borderRadius: '8px',
                        color: '#ffffff'
                      }}
                    />
                    <Area type="monotone" dataKey="tps" stroke="#4361EE" fill="#4361EE" fillOpacity={0.6} />
                    <Line type="monotone" dataKey="capacity" stroke="#7209B7" strokeWidth={2} strokeDasharray="5 5" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Recent Incidents MTTR */}
            <div>
              <h4 className="text-white font-medium mb-3">Recent Incidents (MTTR)</h4>
              <div className="space-y-2">
                {mttrIncidents.map((incident) => (
                  <div key={incident.id} className="flex items-center justify-between p-2 rounded-lg bg-gradient-to-r from-tech-glass to-transparent">
                    <div className="flex items-center gap-2">
                      <Badge className={`${getSeverityColor(incident.severity)} text-white text-xs`}>
                        {incident.severity}
                      </Badge>
                      <span className="text-white text-sm tech-counter">{incident.id}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-tech-cyan text-sm tech-counter">{incident.duration}h</span>
                      {incident.resolved && <CheckCircle className="w-4 h-4 text-tech-success" />}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}