import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { ComposedChart, Bar, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Treemap } from 'recharts';
import { DollarSign, TrendingUp, TrendingDown, AlertTriangle, Target } from 'lucide-react';
import { Badge } from './ui/badge';

interface FinancialOverviewTabProps {
  filters: any;
  selectedPeriod: {
    year: number;
    month: number;
    monthName: string;
  };
  currentPeriodDisplay: string;
}

export function FinancialOverviewTab({ filters, selectedPeriod, currentPeriodDisplay }: FinancialOverviewTabProps) {
  // Mock data for budget vs actual
  const budgetActualData = [
    { month: 'Jan', budget: 12000, actual: 11500, variance: -500 },
    { month: 'Feb', budget: 12500, actual: 13200, variance: 700 },
    { month: 'Mar', budget: 11800, actual: 11200, variance: -600 },
    { month: 'Apr', budget: 13000, actual: 12800, variance: -200 },
    { month: 'May', budget: 12200, actual: 12900, variance: 700 },
    { month: 'Jun', budget: 12800, actual: 12400, variance: -400 },
  ];

  // Mock data for GBGI breakdown
  const gbgiBreakdownData = [
    { name: 'CIB', ctb: 4500, rtb: 2800, amort: 1200, cap: 800, total: 9300 },
    { name: 'IWPB', ctb: 3200, rtb: 1900, amort: 900, cap: 600, total: 6600 },
    { name: 'GL', ctb: 2100, rtb: 1200, amort: 500, cap: 400, total: 4200 },
    { name: 'Others', ctb: 1800, rtb: 1000, amort: 400, cap: 300, total: 3500 },
  ];

  // Mock data for intercom charges
  const intercomSupplierData = [
    { name: 'AWS', monthly: 2500, ytd: 15000, color: '#3d8eae' },
    { name: 'Microsoft', monthly: 1800, ytd: 10800, color: '#5d9438' },
    { name: 'Oracle', monthly: 1200, ytd: 7200, color: '#ed6335' },
    { name: 'SAP', monthly: 900, ytd: 5400, color: '#c03957' },
    { name: 'Salesforce', monthly: 600, ytd: 3600, color: '#9b4822' },
  ];

  const ctbRtbData = [
    { name: 'CTB', value: 8500, percentage: 65, color: '#db0011' },
    { name: 'RTB', value: 4500, percentage: 35, color: '#767676' },
  ];

  // Mock data for top vendors
  const topVendorsData = [
    { name: 'Accenture', amount: 3200, type: 'Development' },
    { name: 'TCS', amount: 2800, type: 'Maintenance' },
    { name: 'Infosys', amount: 2400, type: 'Development' },
    { name: 'IBM', amount: 2100, type: 'Infrastructure' },
    { name: 'Wipro', amount: 1900, type: 'Testing' },
    { name: 'Cognizant', amount: 1600, type: 'Development' },
    { name: 'HCL', amount: 1400, type: 'Support' },
    { name: 'Capgemini', amount: 1200, type: 'Consulting' },
    { name: 'DXC', amount: 1000, type: 'Infrastructure' },
    { name: 'Atos', amount: 800, type: 'Operations' },
  ];

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-hsbc-grey-medium rounded-lg shadow-lg">
          <p className="font-medium">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} style={{ color: entry.color }}>
              {entry.dataKey}: ${entry.value.toLocaleString()}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Data Context Header */}
      <div className="bg-white border border-hsbc-blue-2 rounded-lg p-4">
        <div className="flex items-center gap-3">
          <div className="w-3 h-3 bg-hsbc-blue-2 rounded-full"></div>
          <h3 className="text-hsbc-blue-2 font-medium">Financial data for {currentPeriodDisplay}</h3>
        </div>
      </div>
      {/* Section 1: Tech Budget & LE */}
      <div className="space-y-4">
        <h2 className="text-hsbc-grey-darker">Tech Budget & Latest Estimate</h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Budget vs Actual Chart */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-hsbc-red" />
                  Budget vs Actual Spending (CTTB vs Operating Expense)
                </CardTitle>
                <CardDescription>Monthly trend analysis</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <ComposedChart data={budgetActualData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#ededed" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip content={<CustomTooltip />} />
                      <Bar dataKey="budget" fill="#db0011" name="Budget" />
                      <Bar dataKey="actual" fill="#347893" name="Actual" />
                      <Line dataKey="variance" stroke="#5d9438" strokeWidth={3} name="Variance" />
                    </ComposedChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Recovery Indicators */}
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">YTD Over/Under Recovery</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-red-50 border border-red-200 p-4 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-red-800">Over Budget</p>
                      <p className="text-xl font-semibold text-red-900">$2.4M</p>
                      <p className="text-xs text-red-700">8.2% variance</p>
                    </div>
                    <TrendingUp className="h-8 w-8 text-red-600" />
                  </div>
                </div>
                
                <div className="bg-green-50 border border-green-200 p-4 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-green-800">Cost Savings</p>
                      <p className="text-xl font-semibold text-green-900">$1.2M</p>
                      <p className="text-xs text-green-700">OpEx optimization</p>
                    </div>
                    <TrendingDown className="h-8 w-8 text-green-600" />
                  </div>
                </div>
                
                <div className="bg-orange-50 border border-orange-200 p-4 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-orange-800">At Risk</p>
                      <p className="text-xl font-semibold text-orange-900">$800K</p>
                      <p className="text-xs text-orange-700">Q4 forecasted</p>
                    </div>
                    <AlertTriangle className="h-8 w-8 text-orange-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
        
        {/* GBGI Breakdown */}
        <Card>
          <CardHeader>
            <CardTitle>Attribute/GBGI Breakdown</CardTitle>
            <CardDescription>CTB/RTB/Amort/CAP by GBGI segments</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={gbgiBreakdownData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="ctb" stackId="a" fill="#db0011" name="CTB" />
                  <Bar dataKey="rtb" stackId="a" fill="#347893" name="RTB" />
                  <Bar dataKey="amort" stackId="a" fill="#5d9438" name="Amort" />
                  <Bar dataKey="cap" stackId="a" fill="#ed6335" name="CAP" />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Section 2: Intercom Charges */}
      <div className="space-y-4">
        <h2 className="text-hsbc-grey-darker">Intercom Charges</h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Supplier Breakdown */}
          <Card>
            <CardHeader>
              <CardTitle>Monthly & YTD Actual vs LE by Supplier</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart data={intercomSupplierData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="monthly" fill="#db0011" name="Monthly" />
                    <Bar dataKey="ytd" fill="#347893" name="YTD" />
                  </ComposedChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
          
          {/* CTB/RTB Split */}
          <Card>
            <CardHeader>
              <CardTitle>CTB/RTB Split</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={ctbRtbData}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      dataKey="value"
                    >
                      {ctbRtbData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="mt-4 space-y-2">
                {ctbRtbData.map((item) => (
                  <div key={item.name} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                      <span className="text-sm">{item.name}</span>
                    </div>
                    <span className="text-sm font-medium">{item.percentage}%</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Section 3: Vendor Spending */}
      <div className="space-y-4">
        <h2 className="text-hsbc-grey-darker">Vendor Spending</h2>
        
        <Card>
          <CardHeader>
            <CardTitle>Top 10 Local Vendors</CardTitle>
            <CardDescription>Monthly spending breakdown by vendor</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {topVendorsData.map((vendor, index) => (
                <div key={vendor.name} className="flex items-center justify-between p-3 bg-hsbc-grey-light rounded-lg">
                  <div className="flex items-center gap-3">
                    <Badge variant="secondary" className="w-8 h-8 rounded-full flex items-center justify-center">
                      {index + 1}
                    </Badge>
                    <div>
                      <p className="font-medium">{vendor.name}</p>
                      <p className="text-sm text-hsbc-grey-dark">{vendor.type}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">${vendor.amount.toLocaleString()}K</p>
                    <div className="w-20 h-2 bg-hsbc-grey-medium rounded-full mt-1">
                      <div 
                        className="h-2 bg-hsbc-red rounded-full" 
                        style={{ width: `${(vendor.amount / topVendorsData[0].amount) * 100}%` }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}