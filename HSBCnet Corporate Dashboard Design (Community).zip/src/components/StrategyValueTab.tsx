import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { 
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell, ComposedChart
} from 'recharts';
import { 
  TrendingUp, DollarSign, Smartphone, Brain, Star, Users,
  Target, Zap, Award, ArrowUp, ArrowDown
} from 'lucide-react';

interface StrategyValueTabProps {
  filters: any;
  selectedPeriod: any;
  currentPeriodDisplay: string;
}

export function StrategyValueTab({ filters, selectedPeriod, currentPeriodDisplay }: StrategyValueTabProps) {
  
  // Tech Investment Data
  const investmentData = {
    totalInvestment: 2.4, // Billion USD
    revenuePercentage: 15.7, // % of revenue
    valueContribution: 24.7, // % business value
    roi: 340 // %
  };

  // Digital Transformation Metrics
  const digitalTrendData = [
    { month: 'Jan', online: 58.2, digital: 62.1 },
    { month: 'Feb', online: 61.5, digital: 64.3 },
    { month: 'Mar', online: 63.8, digital: 66.8 },
    { month: 'Apr', online: 66.2, digital: 68.9 },
    { month: 'May', online: 68.7, digital: 71.2 },
    { month: 'Jun', online: 71.1, digital: 73.5 }
  ];

  const digitalRevenueData = [
    { category: 'Mobile Banking', percentage: 45.2, value: 1.8 },
    { category: 'Online Lending', percentage: 28.7, value: 1.1 },
    { category: 'Digital Payments', percentage: 18.4, value: 0.7 },
    { category: 'Robo Advisory', percentage: 7.7, value: 0.3 }
  ];

  // Mobile Banking & CenAI Data
  const mobileData = [
    { month: 'Jan', users: 2.3, activity: 78.2 },
    { month: 'Feb', users: 2.4, activity: 80.1 },
    { month: 'Mar', users: 2.5, activity: 82.4 },
    { month: 'Apr', users: 2.6, activity: 84.7 },
    { month: 'May', users: 2.7, activity: 86.3 },
    { month: 'Jun', users: 2.8, activity: 88.1 }
  ];

  const cenaiData = {
    scenarios: 47,
    growth: 23, // % growth
    applications: [
      { name: 'Customer Service', usage: 85, impact: 'High' },
      { name: 'Risk Assessment', usage: 72, impact: 'High' },
      { name: 'Fraud Detection', usage: 91, impact: 'Critical' },
      { name: 'Process Automation', usage: 64, impact: 'Medium' },
      { name: 'Compliance Monitoring', usage: 58, impact: 'Medium' }
    ]
  };

  // Customer Satisfaction
  const customerMetrics = {
    nps: 67,
    satisfaction: 4.3, // out of 5
    digitalSatisfaction: 4.5
  };

  const COLORS = ['#4361EE', '#7209B7', '#4CC9F0', '#10B981', '#F59E0B'];

  return (
    <div className="p-6 space-y-6 bg-tech-navy min-h-screen">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Strategy & Value</h1>
          <p className="text-tech-cyan">Technology Investment Impact & Digital Transformation - {currentPeriodDisplay}</p>
        </div>
      </div>

      {/* Tech Investment Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <Card className="bg-tech-glass border-tech-glass-border backdrop-blur-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-tech-cyan text-sm">Total Tech Investment</p>
                <p className="text-3xl font-bold text-white">${investmentData.totalInvestment}B</p>
                <p className="text-xs text-tech-cyan">{investmentData.revenuePercentage}% of revenue</p>
              </div>
              <DollarSign className="h-12 w-12 text-tech-blue" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-tech-glass border-tech-glass-border backdrop-blur-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-tech-cyan text-sm">Business Value Contribution</p>
                <p className="text-3xl font-bold text-tech-purple">{investmentData.valueContribution}%</p>
                <div className="flex items-center gap-1 mt-2">
                  <ArrowUp className="h-3 w-3 text-tech-success" />
                  <p className="text-xs text-tech-success">+3.2% vs last quarter</p>
                </div>
              </div>
              <Target className="h-12 w-12 text-tech-purple" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-tech-glass border-tech-glass-border backdrop-blur-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-tech-cyan text-sm">Technology ROI</p>
                <p className="text-3xl font-bold text-tech-cyan">{investmentData.roi}%</p>
                <p className="text-xs text-tech-cyan">Industry leading performance</p>
              </div>
              <TrendingUp className="h-12 w-12 text-tech-cyan" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-tech-glass border-tech-glass-border backdrop-blur-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-tech-cyan text-sm">CenAI Scenarios</p>
                <p className="text-3xl font-bold text-white">{cenaiData.scenarios}</p>
                <div className="flex items-center gap-1 mt-2">
                  <ArrowUp className="h-3 w-3 text-tech-success" />
                  <p className="text-xs text-tech-success">+{cenaiData.growth}% growth</p>
                </div>
              </div>
              <Brain className="h-12 w-12 text-tech-purple" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Digital Transformation Trend */}
        <Card className="bg-tech-glass border-tech-glass-border backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Zap className="w-5 h-5 text-tech-blue" />
              Digital Transformation Progress
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={digitalTrendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(76, 201, 240, 0.1)" />
                  <XAxis dataKey="month" stroke="#4CC9F0" />
                  <YAxis stroke="#4CC9F0" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'rgba(10, 12, 23, 0.9)', 
                      border: '1px solid #4CC9F0',
                      borderRadius: '8px',
                      color: '#ffffff'
                    }}
                  />
                  <Area type="monotone" dataKey="online" stackId="1" stroke="#4361EE" fill="#4361EE" fillOpacity={0.6} />
                  <Area type="monotone" dataKey="digital" stackId="1" stroke="#7209B7" fill="#7209B7" fillOpacity={0.6} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Digital Revenue Breakdown */}
        <Card className="bg-tech-glass border-tech-glass-border backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-tech-cyan" />
              Digital Revenue by Channel
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {digitalRevenueData.map((item, index) => (
                <div key={item.category} className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-white">{item.category}</span>
                    <span className="text-tech-cyan">{item.percentage}% (${item.value}B)</span>
                  </div>
                  <Progress value={item.percentage} className="h-2" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Mobile Banking Growth */}
        <Card className="bg-tech-glass border-tech-glass-border backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Smartphone className="w-5 h-5 text-tech-purple" />
              Mobile Banking Performance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={mobileData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(76, 201, 240, 0.1)" />
                  <XAxis dataKey="month" stroke="#4CC9F0" />
                  <YAxis yAxisId="left" stroke="#4CC9F0" />
                  <YAxis yAxisId="right" orientation="right" stroke="#7209B7" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'rgba(10, 12, 23, 0.9)', 
                      border: '1px solid #4CC9F0',
                      borderRadius: '8px',
                      color: '#ffffff'
                    }}
                  />
                  <Bar yAxisId="left" dataKey="users" fill="#4361EE" fillOpacity={0.8} />
                  <Line yAxisId="right" type="monotone" dataKey="activity" stroke="#7209B7" strokeWidth={3} />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* CenAI Applications */}
        <Card className="bg-tech-glass border-tech-glass-border backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Brain className="w-5 h-5 text-tech-purple" />
              CenAI Application Performance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {cenaiData.applications.map((app, index) => (
                <div key={app.name} className="flex items-center justify-between p-3 rounded-lg bg-gradient-to-r from-tech-purple/10 to-transparent">
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[index % COLORS.length] }}></div>
                    <span className="text-white">{app.name}</span>
                  </div>
                  <div className="flex items-center gap-4">
                    <Badge variant={app.impact === 'Critical' ? 'destructive' : app.impact === 'High' ? 'default' : 'secondary'}>
                      {app.impact}
                    </Badge>
                    <span className="text-tech-cyan font-medium">{app.usage}%</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Customer Satisfaction */}
      <Card className="bg-tech-glass border-tech-glass-border backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Star className="w-5 h-5 text-tech-cyan" />
            Customer Experience & Satisfaction
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="relative w-24 h-24 mx-auto mb-4">
                <svg className="w-24 h-24 transform -rotate-90">
                  <circle
                    cx="48"
                    cy="48"
                    r="40"
                    stroke="rgba(76, 201, 240, 0.2)"
                    strokeWidth="8"
                    fill="transparent"
                  />
                  <circle
                    cx="48"
                    cy="48"
                    r="40"
                    stroke="#4CC9F0"
                    strokeWidth="8"
                    fill="transparent"
                    strokeLinecap="round"
                    strokeDasharray={`${(customerMetrics.nps / 100) * 251.2} 251.2`}
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-2xl font-bold text-white">{customerMetrics.nps}</span>
                </div>
              </div>
              <p className="text-white font-medium">Net Promoter Score</p>
              <p className="text-tech-cyan text-sm">Industry Leading</p>
            </div>
            
            <div className="text-center">
              <div className="relative w-24 h-24 mx-auto mb-4">
                <svg className="w-24 h-24 transform -rotate-90">
                  <circle
                    cx="48"
                    cy="48"
                    r="40"
                    stroke="rgba(67, 97, 238, 0.2)"
                    strokeWidth="8"
                    fill="transparent"
                  />
                  <circle
                    cx="48"
                    cy="48"
                    r="40"
                    stroke="#4361EE"
                    strokeWidth="8"
                    fill="transparent"
                    strokeLinecap="round"
                    strokeDasharray={`${(customerMetrics.satisfaction / 5) * 251.2} 251.2`}
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-2xl font-bold text-white">{customerMetrics.satisfaction}</span>
                </div>
              </div>
              <p className="text-white font-medium">Overall Satisfaction</p>
              <p className="text-tech-cyan text-sm">Out of 5.0</p>
            </div>
            
            <div className="text-center">
              <div className="relative w-24 h-24 mx-auto mb-4">
                <svg className="w-24 h-24 transform -rotate-90">
                  <circle
                    cx="48"
                    cy="48"
                    r="40"
                    stroke="rgba(114, 9, 183, 0.2)"
                    strokeWidth="8"
                    fill="transparent"
                  />
                  <circle
                    cx="48"
                    cy="48"
                    r="40"
                    stroke="#7209B7"
                    strokeWidth="8"
                    fill="transparent"
                    strokeLinecap="round"
                    strokeDasharray={`${(customerMetrics.digitalSatisfaction / 5) * 251.2} 251.2`}
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-2xl font-bold text-white">{customerMetrics.digitalSatisfaction}</span>
                </div>
              </div>
              <p className="text-white font-medium">Digital Satisfaction</p>
              <p className="text-tech-cyan text-sm">Mobile & Online</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}