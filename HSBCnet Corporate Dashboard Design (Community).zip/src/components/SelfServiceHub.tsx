import { useState } from 'react';
import { CreditCard, Key, Shield, FileText, Search, PlayCircle, ExternalLink } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { PaymentModal } from './PaymentModal';
import { PasswordResetModal } from './PasswordResetModal';
import { DocumentUploadModal } from './DocumentUploadModal';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { ScrollArea } from './ui/scroll-area';

export function SelfServiceHub() {
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showSecurityModal, setShowSecurityModal] = useState(false);
  const [showStatementModal, setShowStatementModal] = useState(false);
  const [showTutorialModal, setShowTutorialModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<string[]>([]);

  const quickHelpItems = [
    {
      icon: CreditCard,
      title: 'Payments',
      description: 'Make transfers and payments',
      action: () => setShowPaymentModal(true)
    },
    {
      icon: Key,
      title: 'Account Access',
      description: 'Login and access issues',
      action: () => setShowPasswordModal(true)
    },
    {
      icon: Shield,
      title: 'Security Device',
      description: 'Secure key management',
      action: () => setShowSecurityModal(true)
    },
    {
      icon: FileText,
      title: 'Statement Retrieval',
      description: 'Download statements',
      action: () => setShowStatementModal(true)
    }
  ];

  const knowledgeBaseArticles = [
    'How to make international payments',
    'Setting up payment limits',
    'Two-factor authentication setup',
    'Account statement formats explained',
    'Security device troubleshooting',
    'Understanding payment fees',
    'Setting up beneficiaries',
    'Mobile app login issues',
    'Bulk payment uploads',
    'Transaction disputes process'
  ];

  const handleSearch = () => {
    if (!searchQuery.trim()) return;
    
    const results = knowledgeBaseArticles.filter(article =>
      article.toLowerCase().includes(searchQuery.toLowerCase())
    );
    setSearchResults(results);
  };

  const handlePopularSearch = (term: string) => {
    setSearchQuery(term);
    const results = knowledgeBaseArticles.filter(article =>
      article.toLowerCase().includes(term.toLowerCase())
    );
    setSearchResults(results);
  };

  return (
    <div className="h-full bg-hsbc-grey-light p-4 md:p-6 space-y-4 md:space-y-6">
      {/* Quick Help Section */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Help</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 md:gap-4">
            {quickHelpItems.map((item) => (
              <button
                key={item.title}
                onClick={item.action}
                className="p-3 md:p-4 bg-white rounded-lg border border-hsbc-grey-medium hover:border-hsbc-red hover:shadow-sm transition-all duration-200 text-left group"
              >
                <div className="flex flex-col items-center space-y-2">
                  <item.icon className="h-6 w-6 md:h-8 md:w-8 text-hsbc-grey-dark group-hover:text-hsbc-red transition-colors" />
                  <div className="text-center">
                    <p className="font-medium text-xs md:text-sm text-foreground">{item.title}</p>
                    <p className="text-xs text-hsbc-grey-dark hidden sm:block">{item.description}</p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Knowledge Base Section */}
      <Card>
        <CardHeader>
          <CardTitle>Knowledge Base</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-hsbc-grey-dark" />
            <Input
              placeholder="Search help articles…"
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            />
          </div>
          <div className="mt-4 space-y-2">
            <div className="text-sm text-hsbc-grey-dark">Popular searches:</div>
            <div className="flex flex-wrap gap-1 md:gap-2">
              {['Payment limits', 'Two-factor auth', 'Account statements'].map((term) => (
                <Button
                  key={term}
                  variant="outline"
                  size="sm"
                  onClick={() => handlePopularSearch(term)}
                  className="text-xs border-hsbc-grey-medium hover:border-hsbc-red hover:text-hsbc-red px-2 md:px-3"
                >
                  {term}
                </Button>
              ))}
            </div>
            {searchResults.length > 0 && (
              <div className="mt-4 space-y-2">
                <div className="text-sm font-medium">Search Results:</div>
                <div className="space-y-1">
                  {searchResults.slice(0, 5).map((article, index) => (
                    <button
                      key={index}
                      className="w-full text-left text-sm text-hsbc-grey-dark hover:text-hsbc-red p-2 hover:bg-white rounded transition-colors"
                      onClick={() => alert(`Opening article: ${article}`)}
                    >
                      {article}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Training & Tutorials Section */}
      <Card>
        <CardHeader>
          <CardTitle>Training & Tutorials</CardTitle>
        </CardHeader>
        <CardContent>
          <div 
            className="bg-white rounded-lg border border-hsbc-grey-medium p-3 md:p-4 hover:border-hsbc-red hover:shadow-sm transition-all duration-200 cursor-pointer group"
            onClick={() => setShowTutorialModal(true)}
          >
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 md:w-12 md:h-12 bg-hsbc-grey-light rounded-lg flex items-center justify-center group-hover:bg-hsbc-red/10 transition-colors">
                <PlayCircle className="h-5 w-5 md:h-6 md:w-6 text-hsbc-grey-dark group-hover:text-hsbc-red transition-colors" />
              </div>
              <div className="flex-1">
                <h4 className="font-medium text-sm md:text-base text-foreground">HSBCnet Onboarding</h4>
                <p className="text-xs md:text-sm text-hsbc-grey-dark">
                  Video guides and tutorials for new users
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Modals */}
      <PaymentModal isOpen={showPaymentModal} onClose={() => setShowPaymentModal(false)} />
      <PasswordResetModal isOpen={showPasswordModal} onClose={() => setShowPasswordModal(false)} />
      <DocumentUploadModal isOpen={showUploadModal} onClose={() => setShowUploadModal(false)} />

      {/* Security Device Modal */}
      <Dialog open={showSecurityModal} onOpenChange={setShowSecurityModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <Shield className="h-5 w-5 text-hsbc-red" />
              <span>Security Device Help</span>
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p>Common security device issues and solutions:</p>
            <div className="space-y-3">
              <div className="p-3 bg-hsbc-grey-light rounded">
                <h4 className="font-medium mb-1">Device Not Working</h4>
                <p className="text-sm text-hsbc-grey-dark">Check battery level and replace if needed</p>
              </div>
              <div className="p-3 bg-hsbc-grey-light rounded">
                <h4 className="font-medium mb-1">Lost or Stolen Device</h4>
                <p className="text-sm text-hsbc-grey-dark">Contact your Relationship Manager immediately</p>
              </div>
              <div className="p-3 bg-hsbc-grey-light rounded">
                <h4 className="font-medium mb-1">Request Replacement</h4>
                <p className="text-sm text-hsbc-grey-dark">Order a new device through your RM or online</p>
              </div>
            </div>
            <div className="flex space-x-2">
              <Button className="flex-1 bg-hsbc-red hover:bg-hsbc-red/90">
                Contact Support
              </Button>
              <Button variant="outline" onClick={() => setShowSecurityModal(false)}>
                Close
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Statement Retrieval Modal */}
      <Dialog open={showStatementModal} onOpenChange={setShowStatementModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <FileText className="h-5 w-5 text-hsbc-red" />
              <span>Download Statements</span>
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p>Access your account statements:</p>
            <div className="space-y-3">
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => alert('Opening current month statements...')}
              >
                <FileText className="h-4 w-4 mr-2" />
                Current Month Statements
              </Button>
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => alert('Opening historical statements...')}
              >
                <FileText className="h-4 w-4 mr-2" />
                Historical Statements (7 years)
              </Button>
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => alert('Opening MT940 format...')}
              >
                <FileText className="h-4 w-4 mr-2" />
                MT940/MT942 Format
              </Button>
            </div>
            <Button variant="outline" onClick={() => setShowStatementModal(false)} className="w-full">
              Close
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Tutorial Modal */}
      <Dialog open={showTutorialModal} onOpenChange={setShowTutorialModal}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <PlayCircle className="h-5 w-5 text-hsbc-red" />
              <span>HSBCnet Training & Tutorials</span>
            </DialogTitle>
          </DialogHeader>
          <ScrollArea className="max-h-96">
            <div className="space-y-4">
              <p>Available training resources:</p>
              <div className="space-y-3">
                {[
                  'Getting Started with HSBCnet',
                  'Making Your First Payment',
                  'Setting Up Beneficiaries',
                  'Understanding Transaction Limits',
                  'Security Best Practices',
                  'Mobile App Overview',
                  'Bulk Payment Processing',
                  'Statement Management',
                  'Troubleshooting Common Issues'
                ].map((tutorial, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-hsbc-grey-light rounded hover:bg-white transition-colors">
                    <div className="flex items-center space-x-3">
                      <PlayCircle className="h-4 w-4 text-hsbc-red" />
                      <span className="text-sm">{tutorial}</span>
                    </div>
                    <Button 
                      size="sm" 
                      variant="ghost"
                      onClick={() => alert(`Playing: ${tutorial}`)}
                    >
                      <ExternalLink className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          </ScrollArea>
          <Button variant="outline" onClick={() => setShowTutorialModal(false)} className="w-full mt-4">
            Close
          </Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}