import { useState } from 'react';
import { Search, CheckCircle, Clock, XCircle, AlertCircle } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Label } from './ui/label';
import { Badge } from './ui/badge';

interface PaymentStatusModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface PaymentRecord {
  id: string;
  reference: string;
  amount: number;
  currency: string;
  beneficiary: string;
  date: string;
  status: 'completed' | 'pending' | 'failed' | 'processing';
}

export function PaymentStatusModal({ isOpen, onClose }: PaymentStatusModalProps) {
  const [searchRef, setSearchRef] = useState('');
  const [searchResults, setSearchResults] = useState<PaymentRecord[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const mockPayments: PaymentRecord[] = [
    {
      id: '1',
      reference: 'PAY12345678',
      amount: 1500.00,
      currency: 'GBP',
      beneficiary: 'ABC Suppliers Ltd',
      date: '2024-01-15',
      status: 'completed'
    },
    {
      id: '2', 
      reference: 'PAY87654321',
      amount: 750.50,
      currency: 'GBP',
      beneficiary: 'XYZ Services',
      date: '2024-01-14',
      status: 'processing'
    },
    {
      id: '3',
      reference: 'PAY11223344',
      amount: 2250.75,
      currency: 'GBP',
      beneficiary: 'Global Tech Solutions',
      date: '2024-01-13',
      status: 'pending'
    }
  ];

  const handleSearch = () => {
    if (!searchRef.trim()) return;

    setIsSearching(true);
    
    setTimeout(() => {
      const results = mockPayments.filter(payment => 
        payment.reference.toLowerCase().includes(searchRef.toLowerCase()) ||
        payment.beneficiary.toLowerCase().includes(searchRef.toLowerCase())
      );
      setSearchResults(results);
      setIsSearching(false);
    }, 1000);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'processing':
        return <Clock className="h-4 w-4 text-blue-500" />;
      case 'pending':
        return <AlertCircle className="h-4 w-4 text-yellow-500" />;
      case 'failed':
        return <XCircle className="h-4 w-4 text-red-500" />;
      default:
        return null;
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
      completed: 'default',
      processing: 'secondary', 
      pending: 'outline',
      failed: 'destructive'
    };

    return (
      <Badge variant={variants[status]} className="capitalize">
        {status}
      </Badge>
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl mx-4 md:mx-auto max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Search className="h-5 w-5 text-hsbc-red" />
            <span>Payment Status</span>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div>
            <Label>Payment Reference or Beneficiary Name</Label>
            <div className="flex space-x-2">
              <Input
                value={searchRef}
                onChange={(e) => setSearchRef(e.target.value)}
                placeholder="Enter payment reference (e.g., PAY12345678)"
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              />
              <Button 
                onClick={handleSearch}
                className="bg-hsbc-red hover:bg-hsbc-red/90"
                disabled={isSearching || !searchRef.trim()}
              >
                {isSearching ? 'Searching...' : 'Search'}
              </Button>
            </div>
          </div>

          {searchResults.length > 0 && (
            <div className="space-y-4">
              <h3 className="font-medium">Search Results</h3>
              {searchResults.map((payment) => (
                <div key={payment.id} className="border rounded-lg p-4 space-y-2">
                  <div className="flex justify-between items-start">
                    <div className="space-y-1">
                      <div className="flex items-center space-x-2">
                        <span className="font-medium">{payment.reference}</span>
                        {getStatusIcon(payment.status)}
                        {getStatusBadge(payment.status)}
                      </div>
                      <p className="text-sm text-hsbc-grey-dark">
                        To: {payment.beneficiary}
                      </p>
                      <p className="text-sm text-hsbc-grey-dark">
                        Date: {new Date(payment.date).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">
                        {payment.currency} {payment.amount.toFixed(2)}
                      </p>
                    </div>
                  </div>
                  
                  {payment.status === 'processing' && (
                    <div className="bg-blue-50 border border-blue-200 rounded p-2">
                      <p className="text-sm text-blue-800">
                        Payment is being processed. Expected completion: Next business day.
                      </p>
                    </div>
                  )}
                  
                  {payment.status === 'pending' && (
                    <div className="bg-yellow-50 border border-yellow-200 rounded p-2">
                      <p className="text-sm text-yellow-800">
                        Payment requires authorization. Please check your secure messages.
                      </p>
                    </div>
                  )}
                  
                  {payment.status === 'completed' && (
                    <div className="bg-green-50 border border-green-200 rounded p-2">
                      <p className="text-sm text-green-800">
                        Payment completed successfully on {new Date(payment.date).toLocaleDateString()}.
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {searchRef && searchResults.length === 0 && !isSearching && (
            <div className="text-center py-8">
              <AlertCircle className="h-12 w-12 text-hsbc-grey-dark mx-auto mb-4" />
              <p className="text-foreground">No payments found</p>
              <p className="text-sm text-hsbc-grey-dark">
                Please check your reference number and try again.
              </p>
            </div>
          )}

          <div className="flex justify-end pt-4">
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}