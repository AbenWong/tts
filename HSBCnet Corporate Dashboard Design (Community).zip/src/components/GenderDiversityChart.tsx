import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { UserCheck, Users, TrendingUp, Target } from 'lucide-react';
import { Badge } from './ui/badge';

interface GenderDiversityChartProps {
  filters: {
    businessUnit: string;
    region: string;
    timePeriod: string;
  };
}

export function GenderDiversityChart({ filters }: GenderDiversityChartProps) {
  // Mock data that would typically come from an API based on filters
  const getGenderData = () => {
    // Base data that changes based on filters
    const baseData = {
      male: 8540,
      female: 6220,
      nonBinary: 350,
      notSpecified: 310
    };
    
    // Simulate filter-based variations
    const multiplier = filters.businessUnit === 'all' ? 1 : 0.3;
    const regionMultiplier = filters.region === 'all' ? 1 : 0.4;
    
    const male = Math.round(baseData.male * multiplier * regionMultiplier);
    const female = Math.round(baseData.female * multiplier * regionMultiplier);
    const nonBinary = Math.round(baseData.nonBinary * multiplier * regionMultiplier);
    const notSpecified = Math.round(baseData.notSpecified * multiplier * regionMultiplier);
    
    return { male, female, nonBinary, notSpecified };
  };

  const data = getGenderData();
  const totalPermanentStaff = data.male + data.female + data.nonBinary + data.notSpecified;
  
  const chartData = [
    {
      name: 'Male',
      value: data.male,
      percentage: Math.round((data.male / totalPermanentStaff) * 100),
      color: '#0078bf'
    },
    {
      name: 'Female',
      value: data.female,
      percentage: Math.round((data.female / totalPermanentStaff) * 100),
      color: '#e26f98'
    },
    {
      name: 'Non-Binary',
      value: data.nonBinary,
      percentage: Math.round((data.nonBinary / totalPermanentStaff) * 100),
      color: '#9b59b6'
    },
    {
      name: 'Not Specified',
      value: data.notSpecified,
      percentage: Math.round((data.notSpecified / totalPermanentStaff) * 100),
      color: '#95a5a6'
    }
  ];

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white p-3 border border-hsbc-grey-medium rounded-lg shadow-lg">
          <p className="font-medium">{data.name}</p>
          <p className="text-hsbc-red">
            {data.value.toLocaleString()} employees ({data.percentage}%)
          </p>
        </div>
      );
    }
    return null;
  };

  const CustomLegend = () => {
    return (
      <div className="grid grid-cols-2 gap-2 mt-4">
        {chartData.map((entry) => (
          <div key={entry.name} className="flex items-center gap-2">
            <div 
              className="w-3 h-3 rounded-full" 
              style={{ backgroundColor: entry.color }}
            />
            <span className="text-sm text-hsbc-grey-dark">{entry.name}</span>
            <span className="text-sm font-medium text-hsbc-grey-dark">
              {entry.percentage}%
            </span>
          </div>
        ))}
      </div>
    );
  };

  const femalePercentage = Math.round((data.female / totalPermanentStaff) * 100);
  const diversityTarget = 45; // Example target
  const isOnTarget = femalePercentage >= diversityTarget;

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-hsbc-grey-dark">
          <UserCheck className="h-5 w-5 text-hsbc-red" />
          Perm Staff Gender Breakdown
        </CardTitle>
        <CardDescription>
          Gender distribution within permanent employees
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Chart */}
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          
          {/* Custom Legend */}
          <CustomLegend />
          
          {/* Key Metrics */}
          <div className="space-y-4">
            {/* Total Permanent Staff */}
            <div className="bg-hsbc-grey-light p-3 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-hsbc-grey-dark">Total Permanent Staff</p>
                  <p className="text-lg font-semibold text-hsbc-grey-dark">
                    {totalPermanentStaff.toLocaleString()}
                  </p>
                </div>
                <Users className="h-6 w-6 text-hsbc-red" />
              </div>
            </div>
            
            {/* Gender Breakdown */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-blue-50 border border-blue-200 p-3 rounded-lg">
                <p className="text-sm text-blue-800">Male</p>
                <p className="text-lg font-semibold text-blue-900">
                  {data.male.toLocaleString()}
                </p>
                <p className="text-xs text-blue-700">
                  {Math.round((data.male / totalPermanentStaff) * 100)}%
                </p>
              </div>
              
              <div className="bg-pink-50 border border-pink-200 p-3 rounded-lg">
                <p className="text-sm text-pink-800">Female</p>
                <p className="text-lg font-semibold text-pink-900">
                  {data.female.toLocaleString()}
                </p>
                <p className="text-xs text-pink-700">
                  {femalePercentage}%
                </p>
              </div>
            </div>
            
            {/* Diversity Target */}
            <div className={`p-3 rounded-lg border ${isOnTarget ? 'bg-green-50 border-green-200' : 'bg-orange-50 border-orange-200'}`}>
              <div className="flex items-center gap-2 mb-2">
                <Target className={`h-4 w-4 ${isOnTarget ? 'text-green-600' : 'text-orange-600'}`} />
                <span className={`text-sm font-medium ${isOnTarget ? 'text-green-800' : 'text-orange-800'}`}>
                  Diversity Target
                </span>
                <Badge variant={isOnTarget ? 'default' : 'secondary'} className={isOnTarget ? 'bg-green-600' : 'bg-orange-500'}>
                  {isOnTarget ? 'On Track' : 'Below Target'}
                </Badge>
              </div>
              <p className={`text-sm ${isOnTarget ? 'text-green-700' : 'text-orange-700'}`}>
                Female representation: {femalePercentage}% (Target: {diversityTarget}%)
              </p>
            </div>
            
            {/* Trend */}
            <div className="bg-green-50 border border-green-200 p-3 rounded-lg">
              <div className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-green-600" />
                <span className="text-sm text-green-800">
                  +1.2% female representation vs last quarter
                </span>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}