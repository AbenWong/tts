import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell, ComposedChart, Area, AreaChart
} from 'recharts';
import { 
  DollarSign, Target, TrendingDown, Shield, Cpu, Zap,
  ArrowUp, ArrowDown, AlertCircle, CheckCircle
} from 'lucide-react';

interface FinanceBudgetTabProps {
  filters: any;
  selectedPeriod: any;
  currentPeriodDisplay: string;
}

export function FinanceBudgetTab({ filters, selectedPeriod, currentPeriodDisplay }: FinanceBudgetTabProps) {
  
  // Budget Performance Data
  const budgetData = [
    { category: 'Infrastructure', budget: 450, actual: 442, variance: -8 },
    { category: 'Applications', budget: 320, actual: 335, variance: 15 },
    { category: 'Cybersecurity', budget: 180, actual: 175, variance: -5 },
    { category: 'Innovation', budget: 220, actual: 210, variance: -10 },
    { category: 'Cloud Services', budget: 150, actual: 145, variance: -5 },
    { category: 'Data & Analytics', budget: 130, actual: 140, variance: 10 }
  ];

  // Investment Allocation
  const allocationData = [
    { name: 'Infrastructure', value: 35.2, amount: 442 },
    { name: 'CTB (Change the Bank)', value: 28.7, amount: 360 },
    { name: 'Cybersecurity', value: 18.4, amount: 230 },
    { name: 'Innovation', value: 17.7, amount: 222 }
  ];

  // Network Costs Trend
  const networkCostData = [
    { month: 'Jan', cost: 45.2, target: 48.0 },
    { month: 'Feb', cost: 44.8, target: 47.5 },
    { month: 'Mar', cost: 43.9, target: 47.0 },
    { month: 'Apr', cost: 42.1, target: 46.5 },
    { month: 'May', cost: 41.3, target: 46.0 },
    { month: 'Jun', cost: 40.7, target: 45.5 }
  ];

  // Cost Efficiency Metrics
  const costEfficiencyData = {
    savingsTarget: 125.5, // Million USD
    savingsAchieved: 156.7, // Million USD
    unitTransactionCost: 0.23, // USD
    peerAverage: 0.31, // USD
    operationalSpendingRatio: 67.4 // %
  };

  // Operational Spending Waterfall
  const waterfallData = [
    { category: 'Starting Budget', value: 1250, cumulative: 1250 },
    { category: 'Personnel', value: -420, cumulative: 830 },
    { category: 'Infrastructure', value: -280, cumulative: 550 },
    { category: 'Software Licenses', value: -150, cumulative: 400 },
    { category: 'Cloud Services', value: -95, cumulative: 305 },
    { category: 'Training', value: -35, cumulative: 270 },
    { category: 'Remaining Budget', value: 0, cumulative: 270 }
  ];

  const COLORS = ['#4361EE', '#7209B7', '#4CC9F0', '#10B981', '#F59E0B'];

  const getSavingsPerformanceColor = () => {
    const percentage = (costEfficiencyData.savingsAchieved / costEfficiencyData.savingsTarget) * 100;
    if (percentage >= 100) return 'text-tech-success';
    if (percentage >= 80) return 'text-tech-warning';
    return 'text-tech-alert';
  };

  return (
    <div className="p-6 space-y-6 bg-tech-navy min-h-screen">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Finance & Budget</h1>
          <p className="text-tech-cyan">IT Budget Performance & Cost Management - {currentPeriodDisplay}</p>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <Card className="bg-tech-glass border-tech-glass-border backdrop-blur-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-tech-cyan text-sm">Budget Adherence</p>
                <p className="text-3xl font-bold text-white">98.2%</p>
                <div className="flex items-center gap-1 mt-2">
                  <CheckCircle className="h-3 w-3 text-tech-success" />
                  <p className="text-xs text-tech-success">Within tolerance</p>
                </div>
              </div>
              <Target className="h-12 w-12 text-tech-blue" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-tech-glass border-tech-glass-border backdrop-blur-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-tech-cyan text-sm">Cost Savings Achieved</p>
                <p className="text-3xl font-bold text-tech-success">${costEfficiencyData.savingsAchieved}M</p>
                <p className={`text-xs ${getSavingsPerformanceColor()}`}>
                  Target: ${costEfficiencyData.savingsTarget}M
                </p>
              </div>
              <TrendingDown className="h-12 w-12 text-tech-success" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-tech-glass border-tech-glass-border backdrop-blur-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-tech-cyan text-sm">Unit Transaction Cost</p>
                <p className="text-3xl font-bold text-tech-cyan">${costEfficiencyData.unitTransactionCost}</p>
                <p className="text-xs text-tech-success">vs Peer: ${costEfficiencyData.peerAverage}</p>
              </div>
              <DollarSign className="h-12 w-12 text-tech-cyan" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-tech-glass border-tech-glass-border backdrop-blur-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-tech-cyan text-sm">Operational Spending</p>
                <p className="text-3xl font-bold text-white">{costEfficiencyData.operationalSpendingRatio}%</p>
                <p className="text-xs text-tech-cyan">of total IT budget</p>
              </div>
              <Cpu className="h-12 w-12 text-tech-purple" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Budget Performance vs Actual */}
      <Card className="bg-tech-glass border-tech-glass-border backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Target className="w-5 h-5 text-tech-blue" />
            Budget vs Actual Performance
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-96">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={budgetData} layout="horizontal">
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(76, 201, 240, 0.1)" />
                <XAxis type="number" stroke="#4CC9F0" />
                <YAxis type="category" dataKey="category" stroke="#4CC9F0" width={120} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'rgba(10, 12, 23, 0.9)', 
                    border: '1px solid #4CC9F0',
                    borderRadius: '8px',
                    color: '#ffffff'
                  }}
                />
                <Bar dataKey="budget" fill="rgba(67, 97, 238, 0.6)" name="Budget" />
                <Bar dataKey="actual" fill="#4361EE" name="Actual" />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Investment Allocation */}
        <Card className="bg-tech-glass border-tech-glass-border backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Shield className="w-5 h-5 text-tech-purple" />
              Investment Allocation Breakdown
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80 flex items-center">
              <div className="w-1/2">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={allocationData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={120}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {allocationData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'rgba(10, 12, 23, 0.9)', 
                        border: '1px solid #4CC9F0',
                        borderRadius: '8px',
                        color: '#ffffff'
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="w-1/2 space-y-3">
                {allocationData.map((item, index) => (
                  <div key={item.name} className="flex items-center gap-3">
                    <div 
                      className="w-4 h-4 rounded-full" 
                      style={{ backgroundColor: COLORS[index % COLORS.length] }}
                    ></div>
                    <div className="flex-1">
                      <p className="text-white text-sm">{item.name}</p>
                      <p className="text-tech-cyan text-xs">{item.value}% (${item.amount}M)</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Network Costs Trend */}
        <Card className="bg-tech-glass border-tech-glass-border backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Zap className="w-5 h-5 text-tech-cyan" />
              Network-Related Costs Trend
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={networkCostData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(76, 201, 240, 0.1)" />
                  <XAxis dataKey="month" stroke="#4CC9F0" />
                  <YAxis stroke="#4CC9F0" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'rgba(10, 12, 23, 0.9)', 
                      border: '1px solid #4CC9F0',
                      borderRadius: '8px',
                      color: '#ffffff'
                    }}
                  />
                  <Line type="monotone" dataKey="cost" stroke="#4361EE" strokeWidth={3} name="Actual Cost" />
                  <Line type="monotone" dataKey="target" stroke="#7209B7" strokeWidth={2} strokeDasharray="5 5" name="Target" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Cost Savings Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-tech-glass border-tech-glass-border backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <TrendingDown className="w-5 h-5 text-tech-success" />
              Cost Savings Target vs Achieved
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <div className="flex justify-between mb-3">
                <span className="text-tech-cyan">Annual Target</span>
                <span className="text-white font-bold">${costEfficiencyData.savingsTarget}M</span>
              </div>
              <Progress value={100} className="h-3 bg-gray-700" />
            </div>
            <div>
              <div className="flex justify-between mb-3">
                <span className="text-tech-cyan">Achieved (YTD)</span>
                <span className="text-tech-success font-bold">${costEfficiencyData.savingsAchieved}M</span>
              </div>
              <Progress 
                value={(costEfficiencyData.savingsAchieved / costEfficiencyData.savingsTarget) * 100} 
                className="h-3" 
              />
              <p className="text-xs text-tech-success mt-2">
                125% of annual target achieved
              </p>
            </div>
            <div className="bg-gradient-to-r from-tech-success/20 to-transparent p-4 rounded-lg border-l-4 border-tech-success">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-tech-success" />
                <p className="text-white font-medium">Target Exceeded</p>
              </div>
              <p className="text-tech-cyan text-sm mt-1">
                Cost optimization initiatives delivering ahead of schedule
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Operational Spending Waterfall */}
        <Card className="bg-tech-glass border-tech-glass-border backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-tech-blue" />
              Operational Spending Breakdown
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {waterfallData.map((item, index) => (
                <div key={item.category} className="flex items-center justify-between p-3 rounded-lg bg-gradient-to-r from-tech-blue/10 to-transparent">
                  <span className="text-white">{item.category}</span>
                  <div className="flex items-center gap-2">
                    {item.value < 0 && <ArrowDown className="w-4 h-4 text-tech-alert" />}
                    {item.value > 0 && <ArrowUp className="w-4 h-4 text-tech-success" />}
                    <span className={`font-bold ${item.value < 0 ? 'text-tech-alert' : item.value > 0 ? 'text-tech-success' : 'text-white'}`}>
                      {item.value !== 0 ? `${item.value > 0 ? '+' : ''}${item.value}M` : `${item.cumulative}M`}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}