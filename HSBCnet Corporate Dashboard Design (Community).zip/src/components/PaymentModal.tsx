import { useState } from 'react';
import { X, CreditCard, Building2 } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function PaymentModal({ isOpen, onClose }: PaymentModalProps) {
  const [paymentType, setPaymentType] = useState<string>('');
  const [formData, setFormData] = useState({
    fromAccount: '',
    toAccount: '',
    amount: '',
    reference: '',
    beneficiaryName: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate payment processing
    alert('Payment initiated successfully! Reference: PAY' + Math.random().toString().substr(2, 8));
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md mx-4 md:mx-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <CreditCard className="h-5 w-5 text-hsbc-red" />
            <span>Make a Payment</span>
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label>Payment Type</Label>
            <Select value={paymentType} onValueChange={setPaymentType}>
              <SelectTrigger>
                <SelectValue placeholder="Select payment type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="internal">Internal Transfer</SelectItem>
                <SelectItem value="domestic">Domestic Payment</SelectItem>
                <SelectItem value="international">International Transfer</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>From Account</Label>
            <Select value={formData.fromAccount} onValueChange={(value) => setFormData({...formData, fromAccount: value})}>
              <SelectTrigger>
                <SelectValue placeholder="Select account" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="123456789">Current Account ****6789</SelectItem>
                <SelectItem value="987654321">Business Account ****4321</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Beneficiary Name</Label>
            <Input
              value={formData.beneficiaryName}
              onChange={(e) => setFormData({...formData, beneficiaryName: e.target.value})}
              placeholder="Enter beneficiary name"
            />
          </div>

          <div>
            <Label>To Account Number</Label>
            <Input
              value={formData.toAccount}
              onChange={(e) => setFormData({...formData, toAccount: e.target.value})}
              placeholder="Enter account number"
            />
          </div>

          <div>
            <Label>Amount (GBP)</Label>
            <Input
              type="number"
              value={formData.amount}
              onChange={(e) => setFormData({...formData, amount: e.target.value})}
              placeholder="0.00"
              step="0.01"
            />
          </div>

          <div>
            <Label>Payment Reference</Label>
            <Input
              value={formData.reference}
              onChange={(e) => setFormData({...formData, reference: e.target.value})}
              placeholder="Payment reference"
            />
          </div>

          <div className="flex space-x-2 pt-4">
            <Button 
              type="submit" 
              className="flex-1 bg-hsbc-red hover:bg-hsbc-red/90"
              disabled={!paymentType || !formData.fromAccount || !formData.amount}
            >
              Initiate Payment
            </Button>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}