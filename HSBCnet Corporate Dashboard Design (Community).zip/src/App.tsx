import { useState, useEffect } from "react";
import { LinearSidebar } from "./components/LinearSidebar";
import { LinearEarthDashboard } from "./components/LinearEarthDashboard";
import { ChinaDashboard } from "./components/ChinaDashboard";
import { LinearStrategyTab } from "./components/LinearStrategyTab";
import { FinanceBudgetTab } from "./components/FinanceBudgetTab";
import { OperationsEfficiencyTab } from "./components/OperationsEfficiencyTab";
import { RiskSecurityTab } from "./components/RiskSecurityTab";

export default function App() {
  const [activeTab, setActiveTab] = useState("earth-dashboard");
  const [globalFilters, setGlobalFilters] = useState({
    businessUnit: "all",
    region: "all",
    costCenter: "all",
  });

  // Year-Month selection as primary time filter
  const [selectedPeriod, setSelectedPeriod] = useState({
    year: 2025,
    month: 7, // July
    monthName: "July",
  });

  const formatPeriodDisplay = () => {
    const months = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
    ];
    return `${months[selectedPeriod.month - 1]} ${selectedPeriod.year}`;
  };

  // Scroll to top when tab changes
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [activeTab]);

  return (
    <div className="min-h-screen bg-linear-deep-blue flex">
      {/* Sidebar Navigation */}
      <LinearSidebar
        activeTab={activeTab}
        onTabChange={setActiveTab}
      />

      {/* Main Content Area */}
      <div className="flex-1 ml-64">
        {/* Time Filter Bar */}
        <div className="bg-linear-sidebar border-b border-linear-border px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <span className="text-gray-400 linear-body text-sm">
                Reporting Period:
              </span>
              <span className="text-white linear-header font-medium">
                {formatPeriodDisplay()}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-linear-positive rounded-full animate-pulse"></div>
              <span className="text-gray-400 text-sm linear-body">
                Live Data
              </span>
            </div>
          </div>
        </div>

        {/* Dashboard Content */}
        <div className="min-h-screen">
          {activeTab === "earth-dashboard" && (
            <LinearEarthDashboard
              filters={globalFilters}
              selectedPeriod={selectedPeriod}
              currentPeriodDisplay={formatPeriodDisplay()}
            />
          )}

          {activeTab === "china-dashboard" && (
            <ChinaDashboard
              filters={globalFilters}
              selectedPeriod={selectedPeriod}
              currentPeriodDisplay={formatPeriodDisplay()}
            />
          )}

          {activeTab === "strategy-value" && (
            <div className="p-8 bg-linear-deep-blue">
              <LinearStrategyTab
                filters={globalFilters}
                selectedPeriod={selectedPeriod}
                currentPeriodDisplay={formatPeriodDisplay()}
              />
            </div>
          )}

          {activeTab === "finance-budget" && (
            <div className="p-8 bg-linear-deep-blue">
              <FinanceBudgetTab
                filters={globalFilters}
                selectedPeriod={selectedPeriod}
                currentPeriodDisplay={formatPeriodDisplay()}
              />
            </div>
          )}

          {activeTab === "operations-efficiency" && (
            <div className="p-8 bg-linear-deep-blue">
              <OperationsEfficiencyTab
                filters={globalFilters}
                selectedPeriod={selectedPeriod}
                currentPeriodDisplay={formatPeriodDisplay()}
              />
            </div>
          )}

          {activeTab === "risk-security" && (
            <div className="p-8 bg-linear-deep-blue">
              <RiskSecurityTab
                filters={globalFilters}
                selectedPeriod={selectedPeriod}
                currentPeriodDisplay={formatPeriodDisplay()}
              />
            </div>
          )}

          {activeTab === "talent-innovation" && (
            <div className="p-8 bg-linear-deep-blue">
              <div className="linear-card p-8">
                <h1 className="linear-header text-linear-text-primary text-3xl font-semibold mb-4">
                  Talent & Innovation
                </h1>
                <p className="text-linear-text-secondary linear-body">
                  Detailed analytics coming soon...
                </p>
              </div>
            </div>
          )}

          {activeTab === "portfolio-programs" && (
            <div className="p-8 bg-linear-deep-blue">
              <div className="linear-card p-8">
                <h1 className="linear-header text-linear-text-primary text-3xl font-semibold mb-4">
                  Portfolio & Programs
                </h1>
                <p className="text-linear-text-secondary linear-body">
                  Detailed analytics coming soon...
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}