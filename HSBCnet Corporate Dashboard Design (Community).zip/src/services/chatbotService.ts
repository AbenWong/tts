interface ChatResponse {
  content: string;
  actions?: string[];
  type?: 'info' | 'success' | 'warning' | 'error';
}

export class HSBCChatbotService {
  private static responses: Record<string, ChatResponse> = {
    // Greetings
    'hello': {
      content: "Hello! I'm your HSBCnet AI Assistant. I can help you with payments, account access, security devices, statements, and more. How can I assist you today?"
    },
    'hi': {
      content: "Hi there! I'm here to help with your HSBCnet banking needs. What would you like to do today?"
    },
    
    // Payments
    'make a payment': {
      content: "I'll help you make a payment. You can transfer funds between your HSBC accounts, make domestic payments, or send international transfers. Would you like me to open the payment form for you?",
      actions: ['Open Payment Form']
    },
    'payment': {
      content: "For payments, I can help you with:\n• Internal transfers between your accounts\n• Domestic UK payments\n• International wire transfers\n• Bulk payment uploads\n\nWhat type of payment would you like to make?"
    },
    'transfer money': {
      content: "I can help you transfer money. You have several options:\n• Between your HSBC accounts (immediate)\n• To other UK accounts (faster payments)\n• International transfers (SWIFT)\n\nWhich would you prefer?"
    },
    
    // Account Access
    'reset password': {
      content: "I can help you reset your HSBCnet password. This process involves:\n1. Verifying your identity\n2. Sending a security code to your registered devices\n3. Setting up your new password\n\nShall I start the password reset process?",
      actions: ['Start Password Reset']
    },
    'login problem': {
      content: "I understand you're having trouble logging in. Common issues include:\n• Forgotten password\n• Locked account\n• Security device problems\n• Browser compatibility\n\nWhat specific issue are you experiencing?"
    },
    'account locked': {
      content: "If your account is locked, this is usually due to multiple incorrect login attempts. I can help you:\n• Reset your password\n• Contact your Relationship Manager\n• Verify your identity\n\nWould you like me to start the account recovery process?",
      type: 'warning'
    },
    
    // Security Device
    'security device': {
      content: "I can help with security device issues:\n• Device not working or damaged\n• Lost or stolen device\n• Requesting a replacement\n• Battery replacement\n\nWhat issue are you experiencing with your security device?"
    },
    'secure key': {
      content: "Your Secure Key is essential for authorizing transactions. If you're having issues:\n• Check the battery (replace if low)\n• Ensure you're using the correct PIN\n• Contact us if it's damaged or lost\n\nDo you need help with any of these?"
    },
    
    // Statements
    'statement retrieval': {
      content: "I can help you download account statements. You can access:\n• Current month statements\n• Historical statements (up to 7 years)\n• MT940/MT942 formats for integration\n• Custom date ranges\n\nWhat statements do you need?"
    },
    'download statement': {
      content: "To download statements:\n1. Select your account\n2. Choose the date range\n3. Pick your preferred format (PDF, CSV, MT940)\n4. Download immediately\n\nWould you like me to guide you through this process?"
    },
    
    // Document Upload
    'upload document': {
      content: "I can help you upload documents to your HSBCnet portal. Supported documents include:\n• Trade documents\n• KYC documentation\n• Supporting payment documents\n• Compliance certificates\n\nWhat type of document would you like to upload?",
      actions: ['Open Upload Form']
    },
    
    // Payment Status
    'payment status': {
      content: "I can help you check the status of your payments. You can track:\n• Recent payments and their status\n• International transfer progress\n• Failed payment reasons\n• Settlement confirmations\n\nDo you have a specific payment reference to check?",
      actions: ['Check Payment Status']
    },
    
    // General Banking
    'account balance': {
      content: "To check your account balance, please log into your HSBCnet portal and navigate to Account Summary. For real-time balances, use the mobile app or call our 24/7 phone banking service."
    },
    'transaction history': {
      content: "You can view your transaction history by:\n1. Logging into HSBCnet\n2. Selecting your account\n3. Choosing 'Transaction History'\n4. Setting your preferred date range\n\nYou can also download this data in various formats."
    },
    
    // Help and Support
    'help': {
      content: "I'm here to help! I can assist with:\n• Making payments and transfers\n• Account access issues\n• Security device problems\n• Statement downloads\n• Document uploads\n• General banking queries\n\nYou can also escalate to a live agent if needed."
    },
    'contact support': {
      content: "You can contact HSBC support through:\n• This chat (escalate to live agent)\n• Phone: Business Banking helpline\n• Your Relationship Manager\n• Visit a branch\n• HSBCnet Support Centre\n\nWould you like me to escalate this chat to a live agent?",
      actions: ['Escalate to Agent']
    },
    
    // Default responses
    'default_account': {
      content: "I can help with account-related queries including balance checks, transaction history, statements, and account settings. What specifically would you like to know about your account?"
    },
    'default_payment': {
      content: "For payment assistance, I can help you make transfers, check payment status, set up beneficiaries, and resolve payment issues. What payment task can I help you with?"
    },
    'default_security': {
      content: "I take security seriously. I can help with password resets, security device issues, suspicious activity reports, and account security settings. How can I secure your banking today?"
    }
  };

  static getResponse(userInput: string): ChatResponse {
    const input = userInput.toLowerCase().trim();
    
    // Direct matches first
    if (this.responses[input]) {
      return this.responses[input];
    }
    
    // Keyword matching
    if (input.includes('payment') || input.includes('pay') || input.includes('transfer')) {
      return this.responses['payment'];
    }
    
    if (input.includes('password') && input.includes('reset')) {
      return this.responses['reset password'];
    }
    
    if (input.includes('login') || input.includes('access') || input.includes('locked')) {
      return this.responses['login problem'];
    }
    
    if (input.includes('security') && input.includes('device')) {
      return this.responses['security device'];
    }
    
    if (input.includes('statement') || input.includes('download')) {
      return this.responses['statement retrieval'];
    }
    
    if (input.includes('upload') || input.includes('document')) {
      return this.responses['upload document'];
    }
    
    if (input.includes('status') && (input.includes('payment') || input.includes('transfer'))) {
      return this.responses['payment status'];
    }
    
    if (input.includes('balance')) {
      return this.responses['account balance'];
    }
    
    if (input.includes('transaction') || input.includes('history')) {
      return this.responses['transaction history'];
    }
    
    if (input.includes('help') || input.includes('support')) {
      return this.responses['help'];
    }
    
    if (input.includes('hello') || input.includes('hi')) {
      return this.responses['hello'];
    }
    
    // Category-based fallbacks
    if (input.includes('account')) {
      return this.responses['default_account'];
    }
    
    if (input.includes('pay') || input.includes('money') || input.includes('transfer')) {
      return this.responses['default_payment'];
    }
    
    if (input.includes('security') || input.includes('safe') || input.includes('secure')) {
      return this.responses['default_security'];
    }
    
    // Default fallback
    return {
      content: "I understand you need help with HSBCnet. I can assist with payments, account access, security devices, statements, and more. Could you please be more specific about what you'd like to do? You can also use the quick action buttons below or escalate to a live agent.",
      actions: ['Make a Payment', 'Reset Password', 'Upload Document', 'Payment Status']
    };
  }
  
  static getQuickActionResponse(action: string): ChatResponse {
    const actionMap: Record<string, string> = {
      'Make a Payment': 'make a payment',
      'Reset Password': 'reset password', 
      'Upload Document': 'upload document',
      'Payment Status': 'payment status'
    };
    
    return this.getResponse(actionMap[action] || action);
  }
}