import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "./ui/sheet";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { AlertTriangle, AlertCircle, X } from "lucide-react";

interface RiskItem {
  id: string;
  title: string;
  severity: 'high' | 'medium' | 'low';
  status: 'open' | 'in-progress' | 'resolved';
  description: string;
  impact: string;
  mitigation: string;
  assignee: string;
  dueDate: string;
}

interface RiskDetailDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  riskItem: RiskItem | null;
}

export function RiskDetailDrawer({ isOpen, onClose, riskItem }: RiskDetailDrawerProps) {
  if (!riskItem) return null;

  const getSeverityIcon = (severity: string) => {
    if (severity === 'high') return <AlertCircle className="h-4 w-4 text-red-500" />;
    if (severity === 'medium') return <AlertTriangle className="h-4 w-4 text-orange-500" />;
    return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
  };

  const getSeverityColor = (severity: string) => {
    if (severity === 'high') return 'bg-red-500 text-white';
    if (severity === 'medium') return 'bg-orange-500 text-white';
    return 'bg-yellow-500 text-white';
  };

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent className="w-[400px] sm:w-[540px]">
        <SheetHeader>
          <div className="flex items-center justify-between">
            <SheetTitle className="flex items-center gap-2">
              {getSeverityIcon(riskItem.severity)}
              Risk Details
            </SheetTitle>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
          <SheetDescription>
            Detailed information about the selected risk item
          </SheetDescription>
        </SheetHeader>

        <div className="mt-6 space-y-6">
          {/* Risk Title and Severity */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <h3 className="text-lg font-semibold">{riskItem.title}</h3>
              <Badge className={getSeverityColor(riskItem.severity)}>
                {riskItem.severity.toUpperCase()}
              </Badge>
            </div>
            <Badge variant="outline" className="mb-4">
              {riskItem.status.replace('-', ' ').toUpperCase()}
            </Badge>
          </div>

          {/* Description */}
          <div>
            <h4 className="font-medium mb-2">Description</h4>
            <p className="text-sm text-muted-foreground">{riskItem.description}</p>
          </div>

          {/* Impact */}
          <div>
            <h4 className="font-medium mb-2">Potential Impact</h4>
            <p className="text-sm text-muted-foreground">{riskItem.impact}</p>
          </div>

          {/* Mitigation */}
          <div>
            <h4 className="font-medium mb-2">Mitigation Strategy</h4>
            <p className="text-sm text-muted-foreground">{riskItem.mitigation}</p>
          </div>

          {/* Details */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="font-medium mb-1">Assigned to</h4>
              <p className="text-sm text-muted-foreground">{riskItem.assignee}</p>
            </div>
            <div>
              <h4 className="font-medium mb-1">Due Date</h4>
              <p className="text-sm text-muted-foreground">{riskItem.dueDate}</p>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-2 pt-4 border-t">
            <Button size="sm" className="flex-1">
              Update Status
            </Button>
            <Button variant="outline" size="sm" className="flex-1">
              Add Comment
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}