import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Users } from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip } from 'recharts';

const personnelData = [
  { name: 'Backend Developers', value: 35, color: '#36CFC9' },
  { name: 'Frontend Engineers', value: 25, color: '#165DFF' },
  { name: 'DevOps Engineers', value: 15, color: '#52C41A' },
  { name: 'Data Scientists', value: 12, color: '#FAAD14' },
  { name: 'Security Specialists', value: 13, color: '#FF4D4F' },
];

const turnoverData = [
  { month: 'Jan', rate: 3.2 },
  { month: 'Feb', rate: 2.8 },
  { month: 'Mar', rate: 4.1 },
  { month: 'Apr', rate: 3.6 },
  { month: 'May', rate: 5.2 },
  { month: 'Jun', rate: 4.8 },
];

const totalTechPersonnel = 847;
const techRatio = 68;
const trainingCoverage = 85;

export function TalentInnovationModule() {
  const getUserIcons = (coverage: number) => {
    const totalIcons = 10;
    const filledIcons = Math.floor(coverage / 10);
    
    return Array.from({ length: totalIcons }, (_, index) => (
      <Users 
        key={index} 
        className={`h-3 w-3 ${index < filledIcons ? 'text-fintech-cyan' : 'text-muted'}`} 
      />
    ));
  };

  return (
    <Card className="h-[350px] hover:shadow-lg transition-all duration-300 hover:-translate-y-0.5">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg text-fintech-cyan">Talent & Innovation</CardTitle>
      </CardHeader>
      <CardContent className="p-6 pt-0">
        <div className="flex gap-6 h-full">
          {/* Left 40% - Personnel Structure */}
          <div className="w-[40%]">
            <p className="text-sm font-medium mb-3 text-fintech-cyan">Tech Personnel Structure</p>
            <div className="relative h-32 mb-4">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={personnelData}
                    cx="50%"
                    cy="50%"
                    innerRadius={35}
                    outerRadius={55}
                    dataKey="value"
                  >
                    {personnelData.map((entry, index) => (
                      <Cell key={index} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(value: number) => [`${value}%`, 'Share']}
                    labelStyle={{ color: 'var(--foreground)' }}
                    contentStyle={{ 
                      backgroundColor: 'var(--card)', 
                      border: '1px solid var(--border)',
                      borderRadius: '6px'
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-xl font-bold text-foreground">{totalTechPersonnel}</span>
                <span className="text-xs text-muted-foreground">Total</span>
              </div>
            </div>
            
            {/* Personnel ratio */}
            <div className="bg-gradient-to-r from-cyan-50 to-cyan-100 dark:from-cyan-900/20 dark:to-cyan-800/20 rounded-lg p-3">
              <p className="text-xs text-muted-foreground mb-1">Tech Personnel Ratio</p>
              <span className="text-2xl font-bold text-fintech-cyan">{techRatio}%</span>
              <p className="text-xs text-muted-foreground">of total workforce</p>
            </div>
          </div>

          {/* Right 60% - Trend Indicators */}
          <div className="flex-1 space-y-4">
            {/* Key Talent Turnover Rate */}
            <div>
              <p className="text-sm font-medium mb-3 text-fintech-cyan">Key Talent Turnover Rate</p>
              <div className="h-20">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={turnoverData}>
                    <XAxis 
                      dataKey="month" 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fontSize: 10 }}
                    />
                    <YAxis hide />
                    <Tooltip 
                      formatter={(value: number) => [`${value}%`, 'Turnover Rate']}
                      labelStyle={{ color: 'var(--foreground)' }}
                      contentStyle={{ 
                        backgroundColor: 'var(--card)', 
                        border: '1px solid var(--border)',
                        borderRadius: '6px'
                      }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="rate" 
                      stroke="#36CFC9" 
                      strokeWidth={2}
                      dot={(props: any) => {
                        const { cx, cy, payload } = props;
                        const isHighRisk = payload.rate > 5;
                        return (
                          <circle 
                            cx={cx} 
                            cy={cy} 
                            r={3} 
                            fill={isHighRisk ? "#FF4D4F" : "#36CFC9"} 
                          />
                        );
                      }}
                    />
                    {/* Warning line at 5% */}
                    <Line 
                      type="monotone" 
                      dataKey={() => 5} 
                      stroke="#FF4D4F" 
                      strokeWidth={1}
                      strokeDasharray="3 3"
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Warning threshold: 5%</span>
                <span className="text-red-500">May & Jun exceeded</span>
              </div>
            </div>

            {/* Training Coverage */}
            <div>
              <p className="text-sm font-medium mb-3 text-fintech-cyan">Training Coverage</p>
              <div className="relative">
                {/* Progress Ring */}
                <div className="relative w-20 h-20 mx-auto mb-3">
                  <svg className="w-20 h-20 transform -rotate-90" viewBox="0 0 80 80">
                    <circle 
                      cx="40" 
                      cy="40" 
                      r="34" 
                      stroke="currentColor" 
                      strokeWidth="6" 
                      fill="none" 
                      className="text-muted/20" 
                    />
                    <circle 
                      cx="40" 
                      cy="40" 
                      r="34" 
                      stroke="#36CFC9" 
                      strokeWidth="6" 
                      fill="none"
                      strokeDasharray={`${trainingCoverage * 213.6 / 100} 213.6`}
                      className="transition-all duration-500"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-lg font-bold text-fintech-cyan">{trainingCoverage}%</span>
                  </div>
                </div>
                
                {/* User Icons */}
                <div className="flex justify-center">
                  <div className="grid grid-cols-5 gap-1">
                    {getUserIcons(trainingCoverage)}
                  </div>
                </div>
                <p className="text-xs text-center text-muted-foreground mt-2">
                  1 icon = 10% coverage
                </p>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}