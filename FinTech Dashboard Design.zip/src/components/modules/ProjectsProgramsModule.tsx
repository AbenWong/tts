import { Card, CardContent } from "../ui/card";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip } from 'recharts';

const deliveryData = {
  onTime: 87,
  total: 124,
  percentage: 87
};

const innovationProjectsData = [
  { quarter: 'Q1', total: 45, innovation: 18, percentage: 40 },
  { quarter: 'Q2', total: 52, innovation: 24, percentage: 46 },
  { quarter: 'Q3', total: 48, innovation: 22, percentage: 46 },
  { quarter: 'Q4', total: 41, innovation: 19, percentage: 46 },
];

export function ProjectsProgramsModule() {
  const generateScaleMarks = () => {
    const marks = [];
    for (let i = 0; i < 20; i++) {
      const angle = (i * 18) - 90; // Start from top, 18 degrees apart
      const isMainMark = i % 5 === 0;
      const radius = isMainMark ? 65 : 62;
      const x1 = 75 + Math.cos(angle * Math.PI / 180) * radius;
      const y1 = 75 + Math.sin(angle * Math.PI / 180) * radius;
      const x2 = 75 + Math.cos(angle * Math.PI / 180) * 68;
      const y2 = 75 + Math.sin(angle * Math.PI / 180) * 68;
      
      marks.push(
        <line
          key={i}
          x1={x1}
          y1={y1}
          x2={x2}
          y2={y2}
          stroke={isMainMark ? "#165DFF" : "#E5E6EB"}
          strokeWidth={isMainMark ? 2 : 1}
        />
      );
    }
    return marks;
  };

  return (
    <Card className="col-span-full h-[200px] hover:shadow-lg transition-all duration-300 hover:-translate-y-0.5">
      <CardContent className="p-6 h-full">
        <div className="flex h-full gap-8">
          {/* Left 50% - On-Time Delivery Rate */}
          <div className="flex-1 flex flex-col items-center">
            <h3 className="text-lg font-semibold mb-4 text-foreground">On-Time Project Delivery Rate</h3>
            <div className="relative flex-1 flex items-center justify-center">
              {/* Large Donut Chart with Decorative Scales */}
              <div className="relative">
                <svg width="150" height="150" viewBox="0 0 150 150">
                  {/* Decorative scale marks around the edge */}
                  {generateScaleMarks()}
                  
                  {/* Background circle */}
                  <circle
                    cx="75"
                    cy="75"
                    r="55"
                    stroke="#E5E6EB"
                    strokeWidth="12"
                    fill="none"
                    className="opacity-20"
                  />
                  
                  {/* Progress circle */}
                  <circle
                    cx="75"
                    cy="75"
                    r="55"
                    stroke="#165DFF"
                    strokeWidth="12"
                    fill="none"
                    strokeDasharray={`${deliveryData.percentage * 345.6 / 100} 345.6`}
                    strokeDashoffset="0"
                    transform="rotate(-90 75 75)"
                    className="transition-all duration-1000 ease-out"
                  />
                </svg>
                
                {/* Center content */}
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-3xl font-bold text-primary">{deliveryData.percentage}%</span>
                  <span className="text-sm text-muted-foreground">On-Time</span>
                  <span className="text-xs text-muted-foreground mt-1">
                    {deliveryData.onTime}/{deliveryData.total} projects
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Right 50% - Innovation Project Ratio */}
          <div className="flex-1 flex flex-col">
            <h3 className="text-lg font-semibold mb-4 text-foreground">Innovation Project Ratio</h3>
            <div className="flex-1">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={innovationProjectsData}>
                  <XAxis 
                    dataKey="quarter" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fontSize: 12 }}
                  />
                  <YAxis 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fontSize: 10 }}
                  />
                  <Tooltip 
                    formatter={(value: number, name: string) => {
                      if (name === 'innovation') return [`${value} projects`, 'Innovation Projects'];
                      return [`${value} projects`, 'Total Projects'];
                    }}
                    labelStyle={{ color: 'var(--foreground)' }}
                    contentStyle={{ 
                      backgroundColor: 'var(--card)', 
                      border: '1px solid var(--border)',
                      borderRadius: '6px'
                    }}
                  />
                  
                  {/* Total projects bar */}
                  <Bar 
                    dataKey="total" 
                    fill="#E5E6EB" 
                    radius={[4, 4, 0, 0]}
                    name="total"
                  />
                  
                  {/* Innovation projects bar (stacked on top) */}
                  <Bar 
                    dataKey="innovation" 
                    fill="#36CFC9" 
                    radius={[4, 4, 0, 0]}
                    name="innovation"
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
            
            {/* Legend and Stats */}
            <div className="flex justify-between items-center mt-4 pt-4 border-t border-border">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-fintech-cyan rounded"></div>
                  <span className="text-xs text-muted-foreground">Innovation Projects</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-muted rounded"></div>
                  <span className="text-xs text-muted-foreground">Total Projects</span>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium text-foreground">Avg Innovation Ratio: 45%</p>
                <p className="text-xs text-muted-foreground">Target: 40%</p>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}