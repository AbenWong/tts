import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { CheckCircle } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, PieChart, Pie, Cell, Tooltip } from 'recharts';

const budgetData = [
  { category: 'Infrastructure', budget: 850, spent: 720, ratio: 84.7 },
  { category: 'Security', budget: 450, spent: 425, ratio: 94.4 },
  { category: 'Innovation', budget: 380, spent: 410, ratio: 107.9 },
  { category: 'Operations', budget: 290, spent: 265, ratio: 91.4 },
];

const costComparisonData = [
  { metric: 'Transaction Cost', us: 0.12, industry: 0.18, better: true },
  { metric: 'Processing Cost', us: 0.08, industry: 0.15, better: true },
  { metric: 'Maintenance Cost', us: 0.25, industry: 0.22, better: false },
];

const investmentBreakdown = [
  { name: 'Cloud Infrastructure', value: 35, color: '#165DFF' },
  { name: 'Cybersecurity', value: 28, color: '#FF7D00' },
  { name: 'AI/ML', value: 20, color: '#36CFC9' },
  { name: 'Mobile Platform', value: 17, color: '#52C41A' },
];

export function FinanceBudgetModule() {
  return (
    <Card className="h-[380px] hover:shadow-lg transition-all duration-300 hover:-translate-y-0.5">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg">Finance & Budget</CardTitle>
      </CardHeader>
      <CardContent className="p-6 pt-0">
        {/* Budget Achievement Cards */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          {budgetData.map((item, index) => (
            <div key={index} className="bg-muted/30 rounded-lg p-3">
              <p className="text-xs text-muted-foreground mb-2">{item.category}</p>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">${item.spent}K</span>
                <span className={`text-xs ${item.ratio > 100 ? 'text-red-500' : 'text-green-600'}`}>
                  {item.ratio}%
                </span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div 
                  className={`h-2 rounded-full transition-all duration-500 ${
                    item.ratio > 100 ? 'bg-red-500' : 'bg-primary'
                  }`}
                  style={{ width: `${Math.min(item.ratio, 100)}%` }}
                />
              </div>
            </div>
          ))}
        </div>

        {/* Cost Comparison */}
        <div className="mb-6">
          <p className="text-sm font-medium mb-3">Unit Transaction Cost vs Industry</p>
          <div className="space-y-2">
            {costComparisonData.map((item, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">{item.metric}</span>
                  {item.better && <CheckCircle className="h-3 w-3 text-green-600" />}
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-medium">${item.us}</span>
                  <span className="text-xs text-muted-foreground">vs ${item.industry}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Investment Ratio Chart */}
        <div>
          <p className="text-sm font-medium mb-3">Investment Distribution</p>
          <div className="h-24 flex items-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={investmentBreakdown}
                  cx="50%"
                  cy="50%"
                  innerRadius={25}
                  outerRadius={35}
                  dataKey="value"
                >
                  {investmentBreakdown.map((entry, index) => (
                    <Cell key={index} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  formatter={(value: number) => [`${value}%`, 'Share']}
                  labelStyle={{ color: 'var(--foreground)' }}
                  contentStyle={{ 
                    backgroundColor: 'var(--card)', 
                    border: '1px solid var(--border)',
                    borderRadius: '6px'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="ml-4 space-y-1">
              {investmentBreakdown.map((item, index) => (
                <div key={index} className="flex items-center gap-2">
                  <div 
                    className="w-2 h-2 rounded-full" 
                    style={{ backgroundColor: item.color }}
                  />
                  <span className="text-xs text-muted-foreground">{item.name}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}