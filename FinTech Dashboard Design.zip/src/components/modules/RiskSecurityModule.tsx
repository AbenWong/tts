import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Badge } from "../ui/badge";
import { AlertTriangle, AlertCircle } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip } from 'recharts';
import { RiskDetailDrawer } from "../RiskDetailDrawer";

const kriData = [
  { name: 'Operational Risk', status: 'amber', count: 3 },
  { name: 'Credit Risk', status: 'green', count: 1 },
  { name: 'Cyber Risk', status: 'red', count: 2 },
  { name: 'Compliance Risk', status: 'amber', count: 4 },
];

const complianceItems = [
  { item: 'GDPR Compliance', progress: 85, overdue: false, dueDate: '2024-03-15' },
  { item: 'SOX Controls', progress: 92, overdue: false, dueDate: '2024-02-28' },
  { item: 'PCI DSS Review', progress: 45, overdue: true, dueDate: '2024-01-30' },
  { item: 'Risk Assessment', progress: 78, overdue: false, dueDate: '2024-04-10' },
];

const vulnerabilityData = [
  { severity: 'High', count: 8, fixTime: 2.5 },
  { severity: 'Medium', count: 15, fixTime: 5.2 },
  { severity: 'Low', count: 23, fixTime: 8.1 },
];

const sampleRiskItem = {
  id: "cyber-001",
  title: "Potential DDoS Attack Vector",
  severity: "high" as const,
  status: "in-progress" as const,
  description: "Our monitoring systems have detected unusual traffic patterns that could indicate reconnaissance for a potential DDoS attack.",
  impact: "Could result in service downtime affecting up to 2.5M customers, with estimated revenue loss of $500K per hour.",
  mitigation: "Implemented enhanced traffic filtering, increased CDN capacity, and activated emergency response protocols.",
  assignee: "Security Team Alpha",
  dueDate: "2024-02-15"
};

export function RiskSecurityModule() {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [selectedRisk, setSelectedRisk] = useState(sampleRiskItem);

  const handleRiskClick = () => {
    setSelectedRisk(sampleRiskItem);
    setIsDrawerOpen(true);
  };
  return (
    <Card className="h-[350px] hover:shadow-lg transition-all duration-300 hover:-translate-y-0.5">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg">Risk & Security</CardTitle>
      </CardHeader>
      <CardContent className="p-6 pt-0 space-y-4">
        {/* KRI Status */}
        <div>
          <p className="text-sm font-medium mb-3">Key Risk Indicators</p>
          <div className="grid grid-cols-2 gap-2">
            {kriData.map((kri, index) => (
              <div 
                key={index} 
                className="flex items-center justify-between bg-muted/30 rounded-lg p-2 cursor-pointer hover:bg-muted/50 transition-colors"
                onClick={kri.status === 'red' ? handleRiskClick : undefined}
              >
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">{kri.name}</span>
                  {kri.status === 'red' && <AlertCircle className="h-3 w-3 text-red-500" />}
                  {kri.status === 'amber' && <AlertTriangle className="h-3 w-3 text-orange-500" />}
                </div>
                <Badge 
                  variant={kri.status === 'red' ? 'destructive' : kri.status === 'amber' ? 'secondary' : 'default'}
                  className={`text-xs h-5 ${
                    kri.status === 'red' ? 'bg-red-500 text-white' : 
                    kri.status === 'amber' ? 'bg-orange-500 text-white' : 
                    'bg-green-500 text-white'
                  }`}
                >
                  {kri.count}
                </Badge>
              </div>
            ))}
          </div>
        </div>

        {/* Compliance Rectification */}
        <div>
          <p className="text-sm font-medium mb-3">Compliance Rectification Progress</p>
          <div className="space-y-2">
            {complianceItems.map((item, index) => (
              <div key={index} className="space-y-1">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {item.overdue && <div className="w-1 h-4 bg-red-500 rounded-full" />}
                    <span className="text-xs text-muted-foreground">{item.item}</span>
                  </div>
                  <span className={`text-xs font-medium ${
                    item.overdue ? 'text-red-500' : 'text-foreground'
                  }`}>
                    {item.progress}%
                  </span>
                </div>
                <div className="w-full bg-muted rounded-full h-1.5">
                  <div 
                    className={`h-1.5 rounded-full transition-all duration-500 ${
                      item.overdue ? 'bg-red-500' : 'bg-primary'
                    }`}
                    style={{ width: `${item.progress}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Vulnerability Fix Time */}
        <div>
          <p className="text-sm font-medium mb-3">Vulnerability Fix Time (Days)</p>
          <div className="h-16">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={vulnerabilityData} layout="horizontal">
                <XAxis type="number" hide />
                <YAxis type="category" dataKey="severity" width={50} tick={{ fontSize: 10 }} />
                <Tooltip 
                  formatter={(value: number) => [`${value} days`, 'Avg Fix Time']}
                  labelStyle={{ color: 'var(--foreground)' }}
                  contentStyle={{ 
                    backgroundColor: 'var(--card)', 
                    border: '1px solid var(--border)',
                    borderRadius: '6px'
                  }}
                />
                <Bar 
                  dataKey="fixTime" 
                  fill={(data: any) => data.severity === 'High' ? '#FF4D4F' : data.severity === 'Medium' ? '#FAAD14' : '#52C41A'}
                  radius={[0, 2, 2, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-between text-xs text-muted-foreground mt-1">
            <span>High Priority: Pin to top</span>
            <span>Total: {vulnerabilityData.reduce((acc, item) => acc + item.count, 0)} vulnerabilities</span>
          </div>
        </div>

        {/* Risk Detail Drawer */}
        <RiskDetailDrawer
          isOpen={isDrawerOpen}
          onClose={() => setIsDrawerOpen(false)}
          riskItem={selectedRisk}
        />
      </CardContent>
    </Card>
  );
}