import { Button } from "./ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "./ui/dropdown-menu";
import { Sun, Moon, User, Settings, LogOut } from "lucide-react";

interface TopNavigationProps {
  isDark: boolean;
  onThemeToggle: () => void;
  dateFilter: string;
  onDateFilterChange: (value: string) => void;
}

export function TopNavigation({ isDark, onThemeToggle, dateFilter, onDateFilterChange }: TopNavigationProps) {
  return (
    <div className="h-[60px] bg-card border-b border-border flex items-center justify-between px-6 transition-colors duration-300">
      {/* Left side - Logo and Product Name */}
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
          <span className="text-primary-foreground font-bold text-sm">FT</span>
        </div>
        <span className="text-lg font-semibold text-foreground">FinTech Dashboard</span>
      </div>

      {/* Right side - Controls */}
      <div className="flex items-center gap-4">
        {/* Date Filter */}
        <Select value={dateFilter} onValueChange={onDateFilterChange}>
          <SelectTrigger className="w-32 relative">
            <SelectValue />
            <div className={`absolute bottom-0 left-0 h-0.5 bg-primary transition-all duration-200 ${
              dateFilter === 'today' ? 'w-1/3' : 
              dateFilter === 'week' ? 'w-1/3 translate-x-full' : 
              'w-1/3 translate-x-[200%]'
            }`} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="today">Today</SelectItem>
            <SelectItem value="week">This Week</SelectItem>
            <SelectItem value="month">This Month</SelectItem>
          </SelectContent>
        </Select>

        {/* Theme Toggle */}
        <Button
          variant="ghost"
          size="icon"
          onClick={onThemeToggle}
          className="transition-transform duration-150 hover:scale-95 active:scale-95"
        >
          {isDark ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
        </Button>

        {/* User Avatar with Dropdown */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="relative h-8 w-8 rounded-full">
              <Avatar className="h-8 w-8">
                <AvatarFallback className="bg-primary text-primary-foreground">
                  <User className="h-4 w-4" />
                </AvatarFallback>
              </Avatar>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-56" align="end" forceMount>
            <DropdownMenuItem>
              <Settings className="mr-2 h-4 w-4" />
              <span>Settings</span>
            </DropdownMenuItem>
            <DropdownMenuItem>
              <LogOut className="mr-2 h-4 w-4" />
              <span>Log out</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
}