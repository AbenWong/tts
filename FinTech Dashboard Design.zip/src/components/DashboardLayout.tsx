import { useState, useEffect } from "react";
import { TopNavigation } from "./TopNavigation";
import { DashboardSidebar } from "./DashboardSidebar";
import { StrategyValueModule } from "./modules/StrategyValueModule";
import { FinanceBudgetModule } from "./modules/FinanceBudgetModule";
import { OperationsEfficiencyModule } from "./modules/OperationsEfficiencyModule";
import { RiskSecurityModule } from "./modules/RiskSecurityModule";
import { TalentInnovationModule } from "./modules/TalentInnovationModule";
import { ProjectsProgramsModule } from "./modules/ProjectsProgramsModule";
import { cn } from "./ui/utils";

export function DashboardLayout() {
  const [isDark, setIsDark] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('theme') === 'dark' || 
             (!localStorage.getItem('theme') && window.matchMedia('(prefers-color-scheme: dark)').matches);
    }
    return false;
  });
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [dateFilter, setDateFilter] = useState("month");
  const [isMobile, setIsMobile] = useState(false);

  // Check for mobile on mount and resize
  useEffect(() => {
    const checkMobile = () => {
      const mobile = window.innerWidth <= 1023;
      setIsMobile(mobile);
      if (mobile) {
        setIsSidebarCollapsed(true);
      }
    };

    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Apply theme on mount
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, []);

  // Theme toggle
  const toggleTheme = () => {
    const newTheme = !isDark;
    setIsDark(newTheme);
    
    if (newTheme) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  };

  // Sidebar toggle
  const toggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };

  return (
    <div className={cn("min-h-screen bg-background transition-colors duration-300", isDark && "dark")}>
      <div className="flex h-screen overflow-hidden">
        {/* Sidebar */}
        <DashboardSidebar 
          isCollapsed={isSidebarCollapsed}
          onToggleCollapse={toggleSidebar}
        />

        {/* Main Content */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Top Navigation */}
          <TopNavigation
            isDark={isDark}
            onThemeToggle={toggleTheme}
            dateFilter={dateFilter}
            onDateFilterChange={setDateFilter}
          />

          {/* Dashboard Content */}
          <main className={cn(
            "flex-1 overflow-auto transition-all duration-300 ease-out",
            "max-w-[1920px] mx-auto w-full"
          )}>
            <div className="p-6 space-y-6 animate-fade-in-up">
              {/* Strategy & Value Module - Full Width */}
              <div className="w-full">
                <StrategyValueModule />
              </div>

              {/* Main Grid - Responsive Layout */}
              <div className="grid gap-6 transition-all duration-300 lg:grid-cols-2 xl:grid-cols-3">
                {/* Finance & Budget */}
                <div className="col-span-1">
                  <FinanceBudgetModule />
                </div>

                {/* Operations & Efficiency */}
                <div className="col-span-1">
                  <OperationsEfficiencyModule />
                </div>

                {/* Risk & Security */}
                <div className="col-span-1">
                  <RiskSecurityModule />
                </div>

                {/* Talent & Innovation */}
                <div className="col-span-1">
                  <TalentInnovationModule />
                </div>
              </div>

              {/* Projects & Programs Module - Full Width */}
              <div className="w-full">
                <ProjectsProgramsModule />
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}