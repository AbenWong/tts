import { DashboardLayout } from "./components/DashboardLayout";

export default function App() {
  return <DashboardLayout />;
}