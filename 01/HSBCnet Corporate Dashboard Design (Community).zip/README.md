
  # HSBCnet Corporate Dashboard Design (Community)

  This is a code bundle for HSBCnet Corporate Dashboard Design (Community). The original project is available at https://www.figma.com/design/o97A4oWddpQSBeuixzuOuZ/HSBCnet-Corporate-Dashboard-Design--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  