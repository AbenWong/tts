import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Progress } from './ui/progress';
import { CheckCircle, AlertTriangle, XCircle, Clock, DollarSign, Calendar, Target, Download, Share } from 'lucide-react';
import { Button } from './ui/button';

interface PortfolioProjectsTabProps {
  filters: any;
  selectedPeriod: {
    year: number;
    month: number;
    monthName: string;
  };
  currentPeriodDisplay: string;
}

export function PortfolioProjectsTab({ filters, selectedPeriod, currentPeriodDisplay }: PortfolioProjectsTabProps) {
  // Mock project data
  const projectsData = [
    {
      id: 1,
      name: 'Digital Banking Platform',
      strategic: 'High',
      status: 'Green',
      budgetActual: { budget: 15000, actual: 14200 },
      timeline: 'On Track',
      completion: 78,
      startDate: '2024-01-15',
      endDate: '2024-12-30',
      risks: 'Low',
      team: 'Digital Platform',
      category: 'Strategic'
    },
    {
      id: 2,
      name: 'Cloud Migration Phase 2',
      strategic: 'High',
      status: 'Yellow',
      budgetActual: { budget: 12000, actual: 12800 },
      timeline: 'At Risk',
      completion: 65,
      startDate: '2024-02-01',
      endDate: '2024-11-15',
      risks: 'Medium',
      team: 'Cloud Infrastructure',
      category: 'Infrastructure'
    },
    {
      id: 3,
      name: 'Data Analytics Hub',
      strategic: 'Medium',
      status: 'Green',
      budgetActual: { budget: 8500, actual: 7900 },
      timeline: 'On Track',
      completion: 82,
      startDate: '2024-01-08',
      endDate: '2024-10-30',
      risks: 'Low',
      team: 'Data Analytics',
      category: 'Analytics'
    },
    {
      id: 4,
      name: 'Security Enhancement',
      strategic: 'High',
      status: 'Red',
      budgetActual: { budget: 6000, actual: 6800 },
      timeline: 'Delayed',
      completion: 45,
      startDate: '2024-03-01',
      endDate: '2024-12-15',
      risks: 'High',
      team: 'Security',
      category: 'Security'
    },
    {
      id: 5,
      name: 'Mobile App Redesign',
      strategic: 'Medium',
      status: 'Green',
      budgetActual: { budget: 4500, actual: 4100 },
      timeline: 'On Track',
      completion: 90,
      startDate: '2024-01-22',
      endDate: '2024-08-30',
      risks: 'Low',
      team: 'Applications',
      category: 'Frontend'
    },
    {
      id: 6,
      name: 'DevOps Automation',
      strategic: 'Low',
      status: 'Yellow',
      budgetActual: { budget: 3200, actual: 3600 },
      timeline: 'At Risk',
      completion: 55,
      startDate: '2024-02-15',
      endDate: '2024-09-30',
      risks: 'Medium',
      team: 'DevOps',
      category: 'Operations'
    },
    {
      id: 7,
      name: 'API Gateway Implementation',
      strategic: 'Medium',
      status: 'Green',
      budgetActual: { budget: 5500, actual: 5200 },
      timeline: 'On Track',
      completion: 72,
      startDate: '2024-01-30',
      endDate: '2024-11-30',
      risks: 'Low',
      team: 'Applications',
      category: 'Infrastructure'
    },
    {
      id: 8,
      name: 'Regulatory Compliance Update',
      strategic: 'High',
      status: 'Yellow',
      budgetActual: { budget: 7200, actual: 7800 },
      timeline: 'At Risk',
      completion: 60,
      startDate: '2024-03-15',
      endDate: '2024-12-31',
      risks: 'Medium',
      team: 'Applications',
      category: 'Regulatory'
    }
  ];

  // Summary statistics
  const projectSummary = {
    total: projectsData.length,
    strategic: projectsData.filter(p => p.strategic === 'High').length,
    onTrack: projectsData.filter(p => p.status === 'Green').length,
    atRisk: projectsData.filter(p => p.status === 'Yellow').length,
    delayed: projectsData.filter(p => p.status === 'Red').length,
    totalBudget: projectsData.reduce((sum, p) => sum + p.budgetActual.budget, 0),
    totalActual: projectsData.reduce((sum, p) => sum + p.budgetActual.actual, 0),
    avgCompletion: Math.round(projectsData.reduce((sum, p) => sum + p.completion, 0) / projectsData.length)
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Green': return 'bg-green-100 text-green-800';
      case 'Yellow': return 'bg-yellow-100 text-yellow-800';
      case 'Red': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Green': return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'Yellow': return <AlertTriangle className="h-4 w-4 text-yellow-600" />;
      case 'Red': return <XCircle className="h-4 w-4 text-red-600" />;
      default: return null;
    }
  };

  const getStrategicColor = (priority: string) => {
    switch (priority) {
      case 'High': return 'bg-red-100 text-red-800';
      case 'Medium': return 'bg-orange-100 text-orange-800';
      case 'Low': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTimelineColor = (timeline: string) => {
    switch (timeline) {
      case 'On Track': return 'text-green-600';
      case 'At Risk': return 'text-yellow-600';
      case 'Delayed': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const getBudgetVariance = (budget: number, actual: number) => {
    const variance = actual - budget;
    const percentage = ((variance / budget) * 100).toFixed(1);
    return {
      variance,
      percentage: percentage,
      isOverBudget: variance > 0
    };
  };

  // Calculate timeline progress
  const getTimelineProgress = (startDate: string, endDate: string) => {
    const start = new Date(startDate);
    const end = new Date(endDate);
    const now = new Date();
    const total = end.getTime() - start.getTime();
    const elapsed = now.getTime() - start.getTime();
    return Math.min(Math.max((elapsed / total) * 100, 0), 100);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Data Context Header */}
      <div className="bg-white border border-hsbc-pink-2 rounded-lg p-4">
        <div className="flex items-center gap-3">
          <div className="w-3 h-3 bg-hsbc-pink-2 rounded-full"></div>
          <h3 className="text-hsbc-pink-2 font-medium">Project status as of {currentPeriodDisplay}</h3>
        </div>
      </div>
      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-hsbc-grey-dark">Total Projects</p>
                <p className="text-2xl font-semibold text-hsbc-grey-darker">{projectSummary.total}</p>
              </div>
              <Target className="h-8 w-8 text-hsbc-red" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-hsbc-grey-dark">Strategic</p>
                <p className="text-2xl font-semibold text-hsbc-red">{projectSummary.strategic}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-hsbc-red" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-hsbc-grey-dark">On Track</p>
                <p className="text-2xl font-semibold text-green-600">{projectSummary.onTrack}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-hsbc-grey-dark">At Risk</p>
                <p className="text-2xl font-semibold text-yellow-600">{projectSummary.atRisk}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-hsbc-grey-dark">Total Budget</p>
                <p className="text-lg font-semibold text-hsbc-grey-darker">${(projectSummary.totalBudget / 1000).toFixed(0)}K</p>
              </div>
              <DollarSign className="h-8 w-8 text-hsbc-red" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-hsbc-grey-dark">Avg Complete</p>
                <p className="text-2xl font-semibold text-hsbc-grey-darker">{projectSummary.avgCompletion}%</p>
              </div>
              <Clock className="h-8 w-8 text-hsbc-red" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Export Controls */}
      <div className="flex justify-between items-center">
        <h2 className="text-hsbc-grey-darker">Monthly Key Project Tracker</h2>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Export PDF
          </Button>
          <Button variant="outline" size="sm">
            <Share className="h-4 w-4 mr-2" />
            Export Data
          </Button>
        </div>
      </div>

      {/* Project Table */}
      <Card>
        <CardHeader>
          <CardTitle>Project Portfolio Overview</CardTitle>
          <CardDescription>Complete project tracking with budget, timeline, and completion metrics</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Project Name</TableHead>
                <TableHead>Strategic Priority</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Budget vs Actual</TableHead>
                <TableHead>Timeline Health</TableHead>
                <TableHead>% Complete</TableHead>
                <TableHead>Team</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Risks</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {projectsData.map((project) => {
                const budgetVariance = getBudgetVariance(project.budgetActual.budget, project.budgetActual.actual);
                const timelineProgress = getTimelineProgress(project.startDate, project.endDate);
                
                return (
                  <TableRow key={project.id}>
                    <TableCell className="font-medium">{project.name}</TableCell>
                    <TableCell>
                      <Badge className={getStrategicColor(project.strategic)}>
                        {project.strategic}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {getStatusIcon(project.status)}
                        <Badge className={getStatusColor(project.status)}>
                          {project.status}
                        </Badge>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="text-sm">
                          ${project.budgetActual.budget}K / ${project.budgetActual.actual}K
                        </div>
                        <div className={`text-xs ${budgetVariance.isOverBudget ? 'text-red-600' : 'text-green-600'}`}>
                          {budgetVariance.isOverBudget ? '+' : ''}{budgetVariance.percentage}%
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className={`text-sm ${getTimelineColor(project.timeline)}`}>
                          {project.timeline}
                        </div>
                        <Progress value={timelineProgress} className="w-16 h-2" />
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="text-sm font-medium">{project.completion}%</div>
                        <Progress value={project.completion} className="w-16 h-2" />
                      </div>
                    </TableCell>
                    <TableCell className="text-sm">{project.team}</TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="text-xs">
                        {project.category}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge 
                        className={
                          project.risks === 'High' ? 'bg-red-100 text-red-800' :
                          project.risks === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-green-100 text-green-800'
                        }
                      >
                        {project.risks}
                      </Badge>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Timeline Visualization */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-hsbc-red" />
            Project Timeline Overview
          </CardTitle>
          <CardDescription>Gantt-style view of project timelines and progress</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {projectsData.map((project) => {
              const timelineProgress = getTimelineProgress(project.startDate, project.endDate);
              const startDate = new Date(project.startDate).toLocaleDateString('en-GB', { 
                day: '2-digit', 
                month: 'short' 
              });
              const endDate = new Date(project.endDate).toLocaleDateString('en-GB', { 
                day: '2-digit', 
                month: 'short' 
              });
              
              return (
                <div key={project.id} className="border border-hsbc-grey-medium rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <h4 className="font-medium text-sm">{project.name}</h4>
                      {getStatusIcon(project.status)}
                    </div>
                    <div className="text-xs text-hsbc-grey-dark">
                      {startDate} - {endDate}
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <div className="flex-1">
                      <div className="relative">
                        <Progress value={timelineProgress} className="w-full h-3" />
                        <div 
                          className="absolute top-0 h-3 bg-hsbc-red rounded-full opacity-70"
                          style={{ width: `${project.completion}%` }}
                        />
                      </div>
                      <div className="flex justify-between text-xs text-hsbc-grey-dark mt-1">
                        <span>Timeline: {Math.round(timelineProgress)}%</span>
                        <span>Work: {project.completion}%</span>
                      </div>
                    </div>
                    
                    <div className="text-right">
                      <div className="text-sm font-medium">${project.budgetActual.actual}K</div>
                      <div className="text-xs text-hsbc-grey-dark">of ${project.budgetActual.budget}K</div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}