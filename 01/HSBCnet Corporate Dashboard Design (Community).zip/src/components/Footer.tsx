export function Footer() {
  return (
    <footer className="bg-white border-t border-hsbc-grey-medium px-4 md:px-6 py-3 md:py-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
        {/* Quick Links */}
        <div className="flex items-center space-x-2 md:space-x-4 text-xs md:text-sm">
          <a 
            href="#" 
            className="text-hsbc-grey-dark hover:text-hsbc-red transition-colors"
          >
            Terms
          </a>
          <span className="text-hsbc-grey-medium">|</span>
          <a 
            href="#" 
            className="text-hsbc-grey-dark hover:text-hsbc-red transition-colors"
          >
            Privacy
          </a>
          <span className="text-hsbc-grey-medium">|</span>
          <a 
            href="#" 
            className="text-hsbc-grey-dark hover:text-hsbc-red transition-colors"
          >
            <span className="hidden sm:inline">HSBCnet </span>Support
          </a>
        </div>

        {/* Disclaimer */}
        <div className="text-xs md:text-sm text-hsbc-grey-dark">
          <span className="hidden sm:inline">For detailed analytics, </span>contact your Relationship Manager<span className="hidden sm:inline">.</span>
        </div>
      </div>
    </footer>
  );
}