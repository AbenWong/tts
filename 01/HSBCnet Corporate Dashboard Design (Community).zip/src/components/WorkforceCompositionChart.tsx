import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { Users, UserCheck, UserX, TrendingUp } from 'lucide-react';

interface WorkforceCompositionChartProps {
  filters: {
    businessUnit: string;
    region: string;
    timePeriod: string;
  };
}

export function WorkforceCompositionChart({ filters }: WorkforceCompositionChartProps) {
  // Mock data that would typically come from an API based on filters
  const getWorkforceData = () => {
    // Base data that changes based on filters
    const baseData = {
      permanent: 15420,
      nonPermanent: 4580,
    };
    
    // Simulate filter-based variations
    const multiplier = filters.businessUnit === 'all' ? 1 : 0.3;
    const regionMultiplier = filters.region === 'all' ? 1 : 0.4;
    
    const permanent = Math.round(baseData.permanent * multiplier * regionMultiplier);
    const nonPermanent = Math.round(baseData.nonPermanent * multiplier * regionMultiplier);
    
    return { permanent, nonPermanent };
  };

  const data = getWorkforceData();
  const totalEmployees = data.permanent + data.nonPermanent;
  const permPercentage = Math.round((data.permanent / totalEmployees) * 100);
  const nonPermPercentage = Math.round((data.nonPermanent / totalEmployees) * 100);

  const chartData = [
    {
      name: 'Permanent Staff',
      value: data.permanent,
      percentage: permPercentage,
      color: '#db0011'
    },
    {
      name: 'Non-Permanent Staff',
      value: data.nonPermanent,
      percentage: nonPermPercentage,
      color: '#6c7378'
    }
  ];

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white p-3 border border-hsbc-grey-medium rounded-lg shadow-lg">
          <p className="font-medium">{data.name}</p>
          <p className="text-hsbc-red">
            {data.value.toLocaleString()} employees ({data.percentage}%)
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-hsbc-grey-dark">
          <Users className="h-5 w-5 text-hsbc-red" />
          Workforce Composition
        </CardTitle>
        <CardDescription>
          Distribution of permanent vs non-permanent employees
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Chart */}
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={120}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          
          {/* Key Metrics */}
          <div className="space-y-4">
            {/* Total Employees */}
            <div className="bg-hsbc-grey-light p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-hsbc-grey-dark">Total Employees</p>
                  <p className="text-2xl font-semibold text-hsbc-grey-dark">{totalEmployees.toLocaleString()}</p>
                </div>
                <Users className="h-8 w-8 text-hsbc-red" />
              </div>
            </div>
            
            {/* Permanent Staff */}
            <div className="bg-white border border-hsbc-grey-medium p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-hsbc-grey-dark">Permanent Staff</p>
                  <p className="text-xl font-semibold text-hsbc-red">{data.permanent.toLocaleString()}</p>
                  <p className="text-sm text-hsbc-grey-dark">{permPercentage}% of total</p>
                </div>
                <UserCheck className="h-8 w-8 text-hsbc-red" />
              </div>
            </div>
            
            {/* Non-Permanent Staff */}
            <div className="bg-white border border-hsbc-grey-medium p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-hsbc-grey-dark">Non-Permanent Staff</p>
                  <p className="text-xl font-semibold" style={{ color: '#6c7378' }}>{data.nonPermanent.toLocaleString()}</p>
                  <p className="text-sm text-hsbc-grey-dark">{nonPermPercentage}% of total</p>
                </div>
                <UserX className="h-8 w-8" style={{ color: '#6c7378' }} />
              </div>
            </div>
            
            {/* Trend Indicator */}
            <div className="bg-green-50 border border-green-200 p-3 rounded-lg">
              <div className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-green-600" />
                <span className="text-sm text-green-800">
                  2.3% increase in permanent staff vs last quarter
                </span>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}