import { useState } from 'react';
import { User, Settings, LogOut, CreditCard } from 'lucide-react';
import { Button } from './ui/button';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Separator } from './ui/separator';

interface TopNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export function TopNavigation({ activeTab, onTabChange }: TopNavigationProps) {
  const tabs = [
    { id: 'financial', label: 'Financial Overview', shortLabel: 'Financial' },
    { id: 'workforce', label: 'Workforce Analytics', shortLabel: 'Workforce' },
    { id: 'outsourcing', label: 'Outsourcing Management', shortLabel: 'Outsourcing' },
    { id: 'portfolio', label: 'Portfolio & Projects', shortLabel: 'Portfolio' }
  ];

  return (
    <nav className="bg-white border-b border-hsbc-grey-medium">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Left side - Logo and title */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center">
              <div className="w-8 h-8 bg-hsbc-red rounded flex items-center justify-center">
                <span className="text-white text-sm">H</span>
              </div>
            </div>
            <div>
              <h1 className="text-lg md:text-xl text-foreground hidden sm:block">CIO-Dashboard</h1>
              <h1 className="text-base text-foreground sm:hidden">CIO-Dashboard</h1>
            </div>
          </div>

          {/* Center - Tab Navigation (Desktop) */}
          <div className="hidden lg:flex items-center space-x-1">
            {tabs.map((tab) => (
              <Button
                key={tab.id}
                variant="ghost"
                onClick={() => onTabChange(tab.id)}
                className={`px-4 py-2 text-sm transition-colors rounded-none h-16 ${
                  activeTab === tab.id
                    ? 'text-hsbc-red border-b-2 border-hsbc-red bg-transparent'
                    : 'text-hsbc-grey-dark hover:text-hsbc-red hover:bg-hsbc-grey-light'
                }`}
              >
                {tab.label}
              </Button>
            ))}
          </div>

          {/* Right side - Mobile Tab Menu + Profile */}
          <div className="flex items-center space-x-2">
            {/* Mobile Tab Navigation */}
            <div className="lg:hidden">
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" size="sm" className="text-sm">
                    {tabs.find(tab => tab.id === activeTab)?.shortLabel || 'Menu'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-56 p-2" align="center">
                  <div className="space-y-1">
                    {tabs.map((tab) => (
                      <Button
                        key={tab.id}
                        variant="ghost"
                        onClick={() => onTabChange(tab.id)}
                        className={`w-full justify-start text-sm ${
                          activeTab === tab.id ? 'bg-hsbc-grey-light text-hsbc-red' : ''
                        }`}
                      >
                        {tab.label}
                      </Button>
                    ))}
                  </div>
                </PopoverContent>
              </Popover>
            </div>
        
            {/* Profile Menu */}
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="ghost" size="icon">
                  <User className="h-4 w-4 md:h-5 md:w-5 text-hsbc-grey-dark" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-56 md:w-64 p-0" align="end">
                <div className="p-4">
                  <div className="mb-4">
                    <h3 className="font-medium">John Smith</h3>
                    <p className="text-sm text-hsbc-grey-dark">ABC Corporation Ltd</p>
                    <p className="text-xs text-hsbc-grey-dark">Customer ID: 12345678</p>
                  </div>
                  <Separator className="my-3" />
                  <div className="space-y-1">
                    <Button variant="ghost" className="w-full justify-start" size="sm">
                      <User className="h-4 w-4 mr-2" />
                      Profile Settings
                    </Button>
                    <Button variant="ghost" className="w-full justify-start" size="sm">
                      <CreditCard className="h-4 w-4 mr-2" />
                      Account Summary
                    </Button>
                    <Button variant="ghost" className="w-full justify-start" size="sm">
                      <Settings className="h-4 w-4 mr-2" />
                      Preferences
                    </Button>
                    <Separator className="my-2" />
                    <Button variant="ghost" className="w-full justify-start text-hsbc-red" size="sm">
                      <LogOut className="h-4 w-4 mr-2" />
                      Sign Out
                    </Button>
                  </div>
                </div>
              </PopoverContent>
            </Popover>
          </div>
        </div>
      </div>
    </nav>
  );
}