import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, LineChart, Line, Treemap } from 'recharts';
import { Users, UserCheck, UserX, TrendingUp, MapPin, Calendar, Target, UserMinus } from 'lucide-react';
import { Badge } from './ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';

interface WorkforceAnalyticsTabProps {
  filters: any;
  selectedPeriod: {
    year: number;
    month: number;
    monthName: string;
  };
  currentPeriodDisplay: string;
}

export function WorkforceAnalyticsTab({ filters, selectedPeriod, currentPeriodDisplay }: WorkforceAnalyticsTabProps) {
  // Mock headcount data
  const headcountData = {
    permanent: 138,
    nonPermTech: 195,
    nonPermCMC: 68,
    total: 401,
    turnover: 2
  };

  const permRatio = Math.round((headcountData.permanent / headcountData.total) * 100);
  const nonPermRatio = 100 - permRatio;
  const turnoverRate = ((headcountData.turnover / headcountData.total) * 100).toFixed(1);

  // Workforce composition for donut chart
  const workforceComposition = [
    { name: 'Permanent', value: headcountData.permanent, color: '#db0011' },
    { name: 'Non-Perm Tech', value: headcountData.nonPermTech, color: '#347893' },
    { name: 'Non-Perm CMC', value: headcountData.nonPermCMC, color: '#5d9438' }
  ];

  // Global Career Band distribution
  const gcbBandData = [
    { band: 'MD', count: 1 },
    { band: 'GCB 3', count: 5 },
    { band: 'GCB 4', count: 38 },
    { band: 'GCB 5', count: 64 },
    { band: 'GCB 6', count: 27 },
    { band: 'GCB 7', count: 3 }
  ];

  // Service period data
  const servicePeriodData = [
    { period: '<1', count: 8 },
    { period: '1-4', count: 63 },
    { period: '5-9', count: 56 },
    { period: '10-14', count: 3 },
    { period: '15-19', count: 6 },
    { period: '>=20', count: 2 }
  ];

  // Gender ratio of perm employees (horizontal bar chart)
  const genderData = [
    { name: 'Male', value: 95, percentage: 68.8, color: '#347893' },
    { name: 'Female', value: 43, percentage: 31.2, color: '#c03957' }
  ];



  // Location distribution
  const locationData = [
    { name: 'Shanghai', total: 321 },
    { name: 'Guangzhou', total: 56 },
    { name: 'Xi\'an', total: 8 },
    { name: 'Beijing', total: 4 },
    { name: 'Shenzhen', total: 3 },
    { name: 'Chengdu', total: 2 }
  ];

  // Team breakdown data
  const teamData = [
    { team: 'Digital Platform', permHC: 25, permRatio: 45, nonPermHC: 30, nonPermRatio: 55, gcbBand: '65% GCB 4-6', servicePeriod: '4.2 years', attrition: '2.1%', location: 'Hong Kong' },
    { team: 'Data Analytics', permHC: 18, permRatio: 40, nonPermHC: 27, nonPermRatio: 60, gcbBand: '70% GCB 7-9', servicePeriod: '6.1 years', attrition: '1.8%', location: 'London' },
    { team: 'Cloud Infrastructure', permHC: 22, permRatio: 35, nonPermHC: 41, nonPermRatio: 65, gcbBand: '55% GCB 4-6', servicePeriod: '3.8 years', attrition: '2.8%', location: 'Singapore' },
    { team: 'Security', permHC: 15, permRatio: 50, nonPermHC: 15, nonPermRatio: 50, gcbBand: '80% GCB 7-9', servicePeriod: '7.5 years', attrition: '1.2%', location: 'Mumbai' },
    { team: 'Applications', permHC: 28, permRatio: 38, nonPermHC: 46, nonPermRatio: 62, gcbBand: '60% GCB 4-6', servicePeriod: '4.9 years', attrition: '2.5%', location: 'Multi' },
    { team: 'DevOps', permHC: 12, permRatio: 30, nonPermHC: 28, nonPermRatio: 70, gcbBand: '45% GCB 4-6', servicePeriod: '3.2 years', attrition: '3.1%', location: 'Hong Kong' },
    { team: 'Testing', permHC: 18, permRatio: 42, nonPermHC: 25, nonPermRatio: 58, gcbBand: '50% GCB 4-6', servicePeriod: '5.1 years', attrition: '2.2%', location: 'Mumbai' }
  ];

  // Open roles data
  const openRolesData = [
    { team: 'Digital Platform', permOpen: 3, nonPermOpen: 5, status: 'On Track' },
    { team: 'Data Analytics', permOpen: 2, nonPermOpen: 4, status: 'Delayed' },
    { team: 'Cloud Infrastructure', permOpen: 4, nonPermOpen: 8, status: 'At Risk' },
    { team: 'Security', permOpen: 1, nonPermOpen: 2, status: 'On Track' },
    { team: 'Applications', permOpen: 5, nonPermOpen: 7, status: 'On Track' },
    { team: 'DevOps', permOpen: 2, nonPermOpen: 6, status: 'Delayed' }
  ];

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white p-3 border border-hsbc-grey-medium rounded-lg shadow-lg">
          <p className="font-medium">{data.name}</p>
          <p className="text-hsbc-red">
            {data.value} employees ({data.percentage}%)
          </p>
        </div>
      );
    }
    return null;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'On Track': return 'bg-green-100 text-green-800';
      case 'Delayed': return 'bg-orange-100 text-orange-800';
      case 'At Risk': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Data Context Header */}
      <div className="bg-white border border-hsbc-green-3 rounded-lg p-4">
        <div className="flex items-center gap-3">
          <div className="w-3 h-3 bg-hsbc-green-3 rounded-full"></div>
          <h3 className="text-hsbc-green-3 font-medium">Workforce data for {currentPeriodDisplay}</h3>
        </div>
      </div>
      {/* Section 1: Headcount Overview */}
      <div className="space-y-4">
        <h2 className="text-hsbc-grey-darker">Headcount Overview</h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* KPI Cards */}
          <div className="space-y-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-hsbc-grey-dark">Total HC</p>
                    <p className="text-2xl font-semibold text-hsbc-grey-darker">{headcountData.total}</p>
                    <p className="text-xs text-hsbc-grey-dark">MTOM: Month to Month comparison</p>
                  </div>
                  <Users className="h-8 w-8 text-hsbc-red" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-hsbc-grey-dark">Perm Ratio</p>
                    <div className="flex items-baseline gap-2">
                      <p className="text-xl font-semibold text-hsbc-red">{permRatio}%</p>
                      <p className="text-xl text-hsbc-grey-dark">{headcountData.permanent} staff</p>
                    </div>
                    <p className="text-xs text-hsbc-grey-dark">MTOM: Month to Month comparison</p>
                  </div>
                  <UserCheck className="h-8 w-8 text-hsbc-red" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-hsbc-grey-dark">Non-Perm Ratio</p>
                    <div className="flex items-baseline gap-2">
                      <p className="text-xl font-semibold text-hsbc-blue-2">{nonPermRatio}%</p>
                      <p className="text-xl text-hsbc-grey-dark">{headcountData.nonPermTech + headcountData.nonPermCMC} staff</p>
                    </div>
                    <p className="text-xs text-hsbc-grey-dark">MTOM: Month to Month comparison</p>
                  </div>
                  <UserX className="h-8 w-8 text-hsbc-blue-2" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-hsbc-grey-dark">Turnover Rate</p>
                    <div className="flex items-baseline gap-2">
                      <p className="text-xl font-semibold text-hsbc-orange-3">{turnoverRate}%</p>
                      <p className="text-xl text-hsbc-grey-dark">{headcountData.turnover} staff</p>
                    </div>
                    <p className="text-xs text-hsbc-grey-dark">MTOM: Month to Month comparison</p>
                  </div>
                  <UserMinus className="h-8 w-8 text-hsbc-orange-3" />
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Workforce Composition */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Workforce Composition</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={workforceComposition}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      dataKey="value"
                    >
                      {workforceComposition.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="grid grid-cols-3 gap-2 mt-4">
                {workforceComposition.map((item) => (
                  <div key={item.name} className="text-center">
                    <div className="flex items-center justify-center gap-1 mb-1">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                      <span className="text-xs">{item.name}</span>
                    </div>
                    <p className="text-sm font-medium">{item.value}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
          
          {/* Gender Ratio of Perm employees */}
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Gender Ratio of Perm employees</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {genderData.map((item) => (
                  <div key={item.name} className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="font-medium">{item.name}</span>
                      <span className="text-hsbc-grey-dark">{item.value} ({item.percentage}%)</span>
                    </div>
                    <div className="relative h-8 bg-hsbc-grey-light rounded-lg overflow-hidden">
                      <div 
                        className="h-full rounded-lg transition-all duration-300"
                        style={{ 
                          width: `${item.percentage}%`, 
                          backgroundColor: item.color 
                        }}
                      />
                      <div className="absolute inset-0 flex items-center justify-end pr-2">
                        <span className="text-xs text-white font-medium">
                          {item.value}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* GCB Band & Service Period */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Global Career Band</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={gcbBandData} layout="horizontal">
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" />
                    <YAxis type="category" dataKey="band" width={80} />
                    <Tooltip />
                    <Bar dataKey="count" fill="#db0011" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Service Period Tenure</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={servicePeriodData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="period" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="count" fill="#347893" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>
        

      </div>

      {/* Section 2: Location & Team Breakdown */}
      <div className="space-y-4">
        <h2 className="text-hsbc-grey-darker">Location & Team Breakdown</h2>
        
        {/* Location Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5 text-hsbc-red" />
              Location Distribution
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
              {locationData.map((location) => (
                <div key={location.name} className="bg-hsbc-grey-light p-4 rounded-lg text-center">
                  <h4 className="font-medium text-hsbc-grey-darker">{location.name}</h4>
                  <p className="text-2xl font-semibold text-hsbc-red mt-2">{location.total}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        
        {/* Team View Table */}
        <Card>
          <CardHeader>
            <CardTitle>Team View</CardTitle>
            <CardDescription>Detailed breakdown by team</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Team</TableHead>
                  <TableHead>Perm HC</TableHead>
                  <TableHead>Perm %</TableHead>
                  <TableHead>Non-Perm HC</TableHead>
                  <TableHead>Non-Perm %</TableHead>
                  <TableHead>GCB Band</TableHead>
                  <TableHead>Avg Service</TableHead>
                  <TableHead>Attrition</TableHead>
                  <TableHead>Location</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {teamData.map((team) => (
                  <TableRow key={team.team}>
                    <TableCell className="font-medium">{team.team}</TableCell>
                    <TableCell>{team.permHC}</TableCell>
                    <TableCell>{team.permRatio}%</TableCell>
                    <TableCell>{team.nonPermHC}</TableCell>
                    <TableCell>{team.nonPermRatio}%</TableCell>
                    <TableCell className="text-xs">{team.gcbBand}</TableCell>
                    <TableCell>{team.servicePeriod}</TableCell>
                    <TableCell>{team.attrition}</TableCell>
                    <TableCell>{team.location}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {/* Section 3: HC Forecast & Open Roles */}
      <div className="space-y-4">
        <h2 className="text-hsbc-grey-darker">HC Forecast & Open Roles</h2>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5 text-hsbc-red" />
              Open Roles Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Team</TableHead>
                  <TableHead>Perm Open</TableHead>
                  <TableHead>Non-Perm Open</TableHead>
                  <TableHead>Total Open</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {openRolesData.map((role) => (
                  <TableRow key={role.team}>
                    <TableCell className="font-medium">{role.team}</TableCell>
                    <TableCell>{role.permOpen}</TableCell>
                    <TableCell>{role.nonPermOpen}</TableCell>
                    <TableCell>{role.permOpen + role.nonPermOpen}</TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(role.status)}>
                        {role.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}