import { useState, useEffect } from 'react';
import { TopNavigation } from './components/TopNavigation';
import { GlobalFilterPanel } from './components/GlobalFilterPanel';
import { Footer } from './components/Footer';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { FinancialOverviewTab } from './components/FinancialOverviewTab';
import { WorkforceAnalyticsTab } from './components/WorkforceAnalyticsTab';
import { OutsourcingManagementTab } from './components/OutsourcingManagementTab';
import { PortfolioProjectsTab } from './components/PortfolioProjectsTab';

export default function App() {
  const [activeTab, setActiveTab] = useState('financial');
  const [globalFilters, setGlobalFilters] = useState({
    businessUnit: 'all',
    region: 'all',
    costCenter: 'all'
  });

  // Year-Month selection as primary time filter
  const [selectedPeriod, setSelectedPeriod] = useState({
    year: 2025,
    month: 7, // July
    monthName: 'July'
  });

  const formatPeriodDisplay = () => {
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 
                   'July', 'August', 'September', 'October', 'November', 'December'];
    return `${months[selectedPeriod.month - 1]} ${selectedPeriod.year}`;
  };

  // Scroll to top when tab changes
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [activeTab]);

  return (
    <div className="min-h-screen bg-hsbc-grey-light flex flex-col">
      {/* Top Navigation */}
      <TopNavigation 
        activeTab={activeTab}
        onTabChange={setActiveTab}
      />
      
      {/* Global Filter Panel */}
      <GlobalFilterPanel 
        filters={globalFilters}
        onFiltersChange={setGlobalFilters}
        selectedPeriod={selectedPeriod}
        onPeriodChange={setSelectedPeriod}
        currentPeriodDisplay={formatPeriodDisplay()}
      />
      
      {/* Main Dashboard Content */}
      <div className="flex-1">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full">
          {/* Tab Content */}
          <div className="flex-1 bg-hsbc-grey-light">
            <TabsContent value="financial" className="mt-0 h-full">
              <FinancialOverviewTab 
                filters={globalFilters} 
                selectedPeriod={selectedPeriod}
                currentPeriodDisplay={formatPeriodDisplay()}
              />
            </TabsContent>
            
            <TabsContent value="workforce" className="mt-0 h-full">
              <WorkforceAnalyticsTab 
                filters={globalFilters} 
                selectedPeriod={selectedPeriod}
                currentPeriodDisplay={formatPeriodDisplay()}
              />
            </TabsContent>
            
            <TabsContent value="outsourcing" className="mt-0 h-full">
              <OutsourcingManagementTab 
                filters={globalFilters} 
                selectedPeriod={selectedPeriod}
                currentPeriodDisplay={formatPeriodDisplay()}
              />
            </TabsContent>
            
            <TabsContent value="portfolio" className="mt-0 h-full">
              <PortfolioProjectsTab 
                filters={globalFilters} 
                selectedPeriod={selectedPeriod}
                currentPeriodDisplay={formatPeriodDisplay()}
              />
            </TabsContent>
          </div>
        </Tabs>
      </div>
      
      {/* Footer */}
      <Footer />
    </div>
  );
}