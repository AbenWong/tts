
  # ERP System for SMEs (Community)

  This is a code bundle for ERP System for SMEs (Community). The original project is available at https://www.figma.com/design/iUz7uchE6VedA9V4qaVwOM/ERP-System-for-SMEs--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  