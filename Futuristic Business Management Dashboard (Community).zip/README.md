
  # Futuristic Business Management Dashboard (Community)

  This is a code bundle for Futuristic Business Management Dashboard (Community). The original project is available at https://www.figma.com/design/LXszXLllEk4qcirgyIAuEX/Futuristic-Business-Management-Dashboard--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  