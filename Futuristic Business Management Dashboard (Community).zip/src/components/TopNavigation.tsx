import React from 'react';
import { Search, Bell, Moon, Sun, Globe, Settings, User, MapPin, Clock, HardDrive } from 'lucide-react';
import { Button } from './ui/button';
import companyLogo from 'figma:asset/8183a3510547518ded712961641d78e961eddcca.png';

interface TopNavigationProps {
  isDarkMode: boolean;
  onThemeToggle: () => void;
  currentLanguage: string;
  onLanguageChange: (lang: string) => void;
}

export function TopNavigation({ 
  isDarkMode, 
  onThemeToggle, 
  currentLanguage, 
  onLanguageChange 
}: TopNavigationProps) {
  const isRTL = currentLanguage === 'ar';
  
  // Current Saudi time
  const saudiTime = new Date().toLocaleString('en-US', {
    timeZone: 'Asia/Riyadh',
    hour: '2-digit',
    minute: '2-digit',
    hour12: true
  });

  return (
    <header className="h-16 border-b border-slate-700/30 backdrop-blur-xl bg-gradient-to-r from-gray-900/80 via-slate-900/70 to-gray-900/80">
      <div className="h-full px-6 flex items-center justify-between">
        {/* Company branding and Search */}
        <div className="flex items-center space-x-6 flex-1 max-w-2xl">
          <div className="flex items-center space-x-3">
            <img 
              src={companyLogo} 
              alt="AMANAT AL-KALIMA" 
              className="w-8 h-8 object-contain rounded-lg"
            />
            <div className="hidden md:block">
              <h2 className="text-amber-400 text-sm font-medium">
                {currentLanguage === 'en' ? 'AMANAT AL-KALIMA' : 'أمانات الكلمة'}
              </h2>
            </div>
          </div>
          
          <div className="flex-1 max-w-lg">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder={currentLanguage === 'en' ? 'Search invoices, customers, inventory...' : 'البحث في الفواتير والعملاء والمخزون...'}
                className="w-full pl-10 pr-4 py-2 bg-slate-800/50 border border-slate-700/50 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-amber-500/50 focus:border-amber-500/30 transition-all duration-300"
                dir={isRTL ? 'rtl' : 'ltr'}
              />
              <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                <span className="px-2 py-1 text-xs bg-amber-500/20 text-amber-400 rounded-md border border-amber-500/30">⌘K</span>
              </div>
            </div>
          </div>
        </div>

        {/* System info and Actions */}
        <div className="flex items-center space-x-6">
          {/* Offline system status */}
          <div className="hidden lg:flex items-center space-x-4 px-4 py-2 rounded-lg bg-slate-800/50 border border-slate-700/30">
            <div className="flex items-center space-x-2">
              <HardDrive className="w-4 h-4 text-slate-400" />
              <span className="text-slate-300 text-sm font-medium">
                {currentLanguage === 'en' ? 'Local' : 'محلي'}
              </span>
            </div>
            <div className="w-px h-4 bg-slate-600"></div>
            <div className="flex items-center space-x-2">
              <MapPin className="w-4 h-4 text-amber-400" />
              <span className="text-amber-400 text-sm font-medium">
                {currentLanguage === 'en' ? 'Riyadh' : 'الرياض'}
              </span>
            </div>
            <div className="w-px h-4 bg-slate-600"></div>
            <div className="flex items-center space-x-2">
              <Clock className="w-4 h-4 text-gray-400" />
              <span className="text-gray-300 text-sm">{saudiTime}</span>
            </div>
          </div>

          {/* Language Switcher */}
          <div className="relative">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onLanguageChange(currentLanguage === 'en' ? 'ar' : 'en')}
              className="text-gray-400 hover:text-amber-400 hover:bg-amber-500/10 transition-all duration-300"
            >
              <Globe className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">
                {currentLanguage === 'en' ? 'العربية' : 'English'}
              </span>
            </Button>
          </div>

          {/* Theme Toggle */}
          <Button
            variant="ghost"
            size="sm"
            onClick={onThemeToggle}
            className="text-gray-400 hover:text-amber-400 hover:bg-amber-500/10 transition-all duration-300"
          >
            {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </Button>

          {/* Notifications */}
          <div className="relative">
            <Button variant="ghost" size="sm" className="text-gray-400 hover:text-amber-400 hover:bg-amber-500/10 transition-all duration-300">
              <Bell className="w-4 h-4" />
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-gradient-to-r from-amber-500 to-orange-500 rounded-full flex items-center justify-center">
                <span className="w-1.5 h-1.5 bg-white rounded-full"></span>
              </span>
            </Button>
          </div>

          {/* Settings */}
          <Button variant="ghost" size="sm" className="text-gray-400 hover:text-amber-400 hover:bg-amber-500/10 transition-all duration-300">
            <Settings className="w-4 h-4" />
          </Button>

          {/* Enhanced User Profile */}
          <div className="flex items-center space-x-3 pl-4 border-l border-slate-700/50">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-slate-600 to-slate-700 flex items-center justify-center shadow-lg">
              <User className="w-5 h-5 text-white" />
            </div>
            <div className="hidden md:block">
              <p className="text-white text-sm font-medium">
                {currentLanguage === 'en' ? 'Local Admin' : 'المدير المحلي'}
              </p>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <span className="text-green-400 text-xs">
                  {currentLanguage === 'en' ? 'System Ready' : 'النظام جاهز'}
                </span>
                <span className="text-gray-400 text-xs">•</span>
                <span className="text-amber-400 text-xs">
                  {currentLanguage === 'en' ? 'Offline' : 'غير متصل'}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}