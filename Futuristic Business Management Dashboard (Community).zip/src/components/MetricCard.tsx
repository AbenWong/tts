import React from 'react';
import { LucideIcon, TrendingUp, TrendingDown } from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: string;
  change: string;
  trend: 'up' | 'down';
  icon: LucideIcon;
  color: string;
}

export function MetricCard({ title, value, change, trend, icon: Icon, color }: MetricCardProps) {
  // Format Saudi currency values with riyal symbol
  const formatSaudiValue = (val: string) => {
    if (val.includes('﷼')) {
      const parts = val.split(' ');
      const number = parts[0];
      const currency = parts[1];
      return {
        number: number,
        currency: currency
      };
    }
    return {
      number: val,
      currency: null
    };
  };

  const { number, currency } = formatSaudiValue(value);

  return (
    <div className="group relative overflow-hidden">
      {/* Enhanced glassmorphism card */}
      <div className="relative p-6 rounded-2xl backdrop-blur-xl bg-gradient-to-br from-white/10 via-white/5 to-transparent dark:from-black/40 dark:via-black/20 dark:to-transparent border border-white/20 dark:border-white/10 hover:border-amber-500/30 transition-all duration-500 hover:transform hover:scale-105 hover:shadow-2xl hover:shadow-amber-500/10">
        {/* Gradient overlay */}
        <div className={`absolute inset-0 bg-gradient-to-br ${color} opacity-0 group-hover:opacity-10 transition-opacity duration-500 rounded-2xl`}></div>
        
        {/* Saudi-themed floating particles */}
        <div className="absolute top-2 right-2 w-1 h-1 bg-amber-400/30 rounded-full animate-ping opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
        <div className="absolute bottom-4 left-4 w-0.5 h-0.5 bg-emerald-400/40 rounded-full animate-pulse opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-100"></div>
        <div className="absolute top-1/2 right-4 w-0.5 h-0.5 bg-blue-400/30 rounded-full animate-bounce opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-200"></div>
        
        <div className="relative z-10">
          {/* Enhanced Header */}
          <div className="flex items-center justify-between mb-4">
            <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center shadow-xl group-hover:shadow-2xl transition-all duration-300`}>
              <Icon className="w-7 h-7 text-white group-hover:scale-110 transition-transform duration-300" />
            </div>
            <div className={`flex items-center space-x-1 px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-300 ${
              trend === 'up' 
                ? 'text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 group-hover:bg-emerald-500/20' 
                : 'text-red-400 bg-red-500/10 border border-red-500/20 group-hover:bg-red-500/20'
            }`}>
              {trend === 'up' ? (
                <TrendingUp className="w-3 h-3" />
              ) : (
                <TrendingDown className="w-3 h-3" />
              )}
              <span>{change}</span>
            </div>
          </div>

          {/* Enhanced Content */}
          <div className="space-y-2">
            <div className="flex items-end space-x-2">
              <h3 className="text-2xl font-bold text-white group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:from-white group-hover:via-amber-200 group-hover:to-white group-hover:bg-clip-text transition-all duration-500">
                {number}
              </h3>
              {currency && (
                <span className="text-amber-400 text-lg font-bold mb-1 group-hover:text-amber-300 transition-colors duration-300">
                  {currency}
                </span>
              )}
            </div>
            <p className="text-gray-400 text-sm font-medium group-hover:text-gray-300 transition-colors duration-300">
              {title}
            </p>
          </div>

          {/* Enhanced Progress bar with Saudi colors */}
          <div className="mt-6 h-2 bg-white/10 rounded-full overflow-hidden">
            <div 
              className={`h-full rounded-full transition-all duration-1000 ease-out transform origin-left ${
                trend === 'up' 
                  ? 'bg-gradient-to-r from-emerald-500 via-amber-400 to-emerald-500' 
                  : 'bg-gradient-to-r from-red-500 via-orange-400 to-red-500'
              }`}
              style={{ 
                width: trend === 'up' ? '78%' : '45%',
                animationDelay: '500ms'
              }}
            ></div>
          </div>

          {/* Saudi accent line */}
          <div className="mt-4 flex space-x-1">
            <div className="flex-1 h-px bg-gradient-to-r from-emerald-500 to-transparent opacity-0 group-hover:opacity-60 transition-opacity duration-500"></div>
            <div className="w-4 h-px bg-amber-400 opacity-0 group-hover:opacity-100 transition-opacity duration-500 delay-100"></div>
            <div className="flex-1 h-px bg-gradient-to-l from-emerald-500 to-transparent opacity-0 group-hover:opacity-60 transition-opacity duration-500 delay-200"></div>
          </div>
        </div>

        {/* Enhanced glow effect */}
        <div className={`absolute inset-0 bg-gradient-to-br ${color} opacity-0 group-hover:opacity-15 blur-2xl transition-opacity duration-500 rounded-2xl`}></div>
        
        {/* Saudi flag inspired corner accent */}
        <div className="absolute top-0 right-0 w-8 h-8 overflow-hidden">
          <div className="absolute top-0 right-0 w-6 h-6 bg-gradient-to-br from-emerald-500/20 to-transparent transform rotate-45 translate-x-3 -translate-y-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
        </div>
      </div>
    </div>
  );
}