import React from 'react';
import { MetricCard } from './MetricCard';
import { ChartCard } from './ChartCard';
import { RecentActivity } from './RecentActivity';
import { QuickActions } from './QuickActions';
import companyLogo from 'figma:asset/8183a3510547518ded712961641d78e961eddcca.png';
import { 
  TrendingUp, 
  Coins, 
  Package, 
  Users, 
  FileText, 
  AlertTriangle,
  Zap,
  Target,
  Building2,
  Crown,
  Sparkles,
  ArrowUpRight
} from 'lucide-react';

interface DashboardProps {
  currentLanguage: string;
}

export function Dashboard({ currentLanguage }: DashboardProps) {
  const metrics = [
    {
      title: { en: 'Total Revenue', ar: 'إجمالي الإيرادات' },
      value: '2,847,593 ﷼',
      change: '+12.5%',
      trend: 'up' as const,
      icon: Coins,
      color: 'from-emerald-500 to-teal-600'
    },
    {
      title: { en: 'Active Projects', ar: 'المشاريع النشطة' },
      value: '847',
      change: '+8.2%',
      trend: 'up' as const,
      icon: Target,
      color: 'from-blue-500 to-cyan-600'
    },
    {
      title: { en: 'Metal Inventory Value', ar: 'قيمة مخزون المعادن' },
      value: '1,235,784 ﷼',
      change: '-3.1%',
      trend: 'down' as const,
      icon: Package,
      color: 'from-purple-500 to-indigo-600'
    },
    {
      title: { en: 'Total Customers', ar: 'إجمالي العملاء' },
      value: '1,274',
      change: '+5.7%',
      trend: 'up' as const,
      icon: Users,
      color: 'from-orange-500 to-red-600'
    },
    {
      title: { en: 'ZATCA Invoices', ar: 'فواتير زاتكا' },
      value: '23',
      change: '+2',
      trend: 'up' as const,
      icon: FileText,
      color: 'from-yellow-500 to-orange-600'
    },
    {
      title: { en: 'System Alerts', ar: 'تنبيهات النظام' },
      value: '7',
      change: '-4',
      trend: 'down' as const,
      icon: AlertTriangle,
      color: 'from-red-500 to-pink-600'
    }
  ];

  return (
    <div className="relative">
      {/* Enhanced container with better spacing */}
      <div className="p-8 space-y-8 max-w-[1600px] mx-auto">
        {/* Sophisticated Welcome Section */}
        <div className="relative mb-12">
          {/* Background decoration */}
          <div className="absolute -top-4 -left-4 w-32 h-32 bg-gradient-to-br from-amber-500/10 to-transparent rounded-full blur-2xl"></div>
          <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-gradient-to-br from-blue-500/10 to-transparent rounded-full blur-xl"></div>
          
          <div className="relative glass-card rounded-3xl p-8 border border-white/10">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-8">
                <div className="relative group">
                  <div className="absolute inset-0 bg-gradient-to-br from-amber-500/20 to-orange-500/10 rounded-3xl blur-lg group-hover:blur-xl transition-all duration-500"></div>
                  <img 
                    src={companyLogo} 
                    alt="AMANAT AL-KALIMA COMPANY" 
                    className="relative w-20 h-20 object-contain rounded-2xl shadow-2xl group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-br from-amber-500/10 to-transparent rounded-2xl"></div>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center space-x-4">
                    <div className="relative">
                      <h1 className="text-4xl font-bold bg-gradient-to-r from-white via-gray-100 to-white bg-clip-text text-transparent">
                        {currentLanguage === 'en' ? 'Welcome back, Admin' : 'مرحباً بعودتك، المدير'}
                      </h1>
                      <div className="absolute -top-2 -right-2 animate-twinkle">
                        <Sparkles className="w-5 h-5 text-amber-400" />
                      </div>
                    </div>
                    <Crown className="w-7 h-7 text-amber-400 animate-pulse" />
                  </div>
                  
                  <p className="text-xl text-gray-300 leading-relaxed">
                    {currentLanguage === 'en' 
                      ? 'AMANAT AL-KALIMA Business Operations Dashboard' 
                      : 'لوحة تحكم عمليات شركة أمانات الكلمة'}
                  </p>
                  
                  <div className="flex items-center space-x-6 pt-2">
                    <div className="flex items-center space-x-3 px-4 py-2 rounded-full bg-gradient-to-r from-green-500/20 to-emerald-500/10 border border-green-500/30">
                      <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse shadow-lg shadow-green-400/50"></div>
                      <span className="text-green-300 font-medium">
                        {currentLanguage === 'en' ? 'All Systems Operational' : 'جميع الأنظمة تعمل'}
                      </span>
                    </div>
                    
                    <div className="flex items-center space-x-2 text-amber-300">
                      <Building2 className="w-4 h-4" />
                      <span className="font-medium">
                        {currentLanguage === 'en' ? 'Riyadh, Saudi Arabia' : 'الرياض، المملكة العربية السعودية'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Enhanced Market Info Card */}
              <div className="glass-card rounded-2xl p-6 border border-white/10 min-w-[280px]">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-white flex items-center space-x-2">
                    <TrendingUp className="w-5 h-5 text-emerald-400" />
                    <span>{currentLanguage === 'en' ? 'Live Market' : 'السوق المباشر'}</span>
                  </h3>
                  <ArrowUpRight className="w-4 h-4 text-gray-400" />
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 rounded-lg bg-gradient-to-r from-emerald-500/10 to-transparent border border-emerald-500/20">
                    <span className="text-gray-300 text-sm">Steel</span>
                    <div className="flex items-center space-x-2">
                      <span className="text-emerald-400 text-xs font-medium">↗ +2.5%</span>
                      <span className="text-white font-semibold">2,450 ﷼/ton</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 rounded-lg bg-gradient-to-r from-red-500/10 to-transparent border border-red-500/20">
                    <span className="text-gray-300 text-sm">Aluminum</span>
                    <div className="flex items-center space-x-2">
                      <span className="text-red-400 text-xs font-medium">↘ -1.2%</span>
                      <span className="text-white font-semibold">8,750 ﷼/ton</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 rounded-lg bg-gradient-to-r from-blue-500/10 to-transparent border border-blue-500/20">
                    <span className="text-gray-300 text-sm">Copper</span>
                    <div className="flex items-center space-x-2">
                      <span className="text-blue-400 text-xs font-medium">→ 0.0%</span>
                      <span className="text-white font-semibold">31,200 ﷼/ton</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Enhanced Metrics Grid with staggered animation */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-6">
          {metrics.map((metric, index) => (
            <div
              key={index}
              className="animate-fade-in-up"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <MetricCard
                title={metric.title[currentLanguage as keyof typeof metric.title]}
                value={metric.value}
                change={metric.change}
                trend={metric.trend}
                icon={metric.icon}
                color={metric.color}
              />
            </div>
          ))}
        </div>

        {/* Enhanced Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Charts Section with improved spacing */}
          <div className="lg:col-span-2 space-y-8">
            <div className="animate-fade-in-up" style={{ animationDelay: '700ms' }}>
              <ChartCard 
                title={currentLanguage === 'en' ? 'Revenue Analytics (﷼)' : 'تحليل الإيرادات (ريال سعودي)'}
                currentLanguage={currentLanguage}
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="animate-fade-in-up" style={{ animationDelay: '800ms' }}>
                <ChartCard 
                  title={currentLanguage === 'en' ? 'Project Progress' : 'تقدم المشاريع'}
                  currentLanguage={currentLanguage}
                  type="donut"
                />
              </div>
              <div className="animate-fade-in-up" style={{ animationDelay: '900ms' }}>
                <ChartCard 
                  title={currentLanguage === 'en' ? 'Metal Inventory' : 'مخزون المعادن'}
                  currentLanguage={currentLanguage}
                  type="bar"
                />
              </div>
            </div>
          </div>

          {/* Enhanced Side Panel */}
          <div className="space-y-8">
            <div className="animate-fade-in-up" style={{ animationDelay: '1000ms' }}>
              <QuickActions currentLanguage={currentLanguage} />
            </div>
            <div className="animate-fade-in-up" style={{ animationDelay: '1100ms' }}>
              <RecentActivity currentLanguage={currentLanguage} />
            </div>
          </div>
        </div>

        {/* Enhanced Business Status Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-12">
          {/* ZATCA Compliance */}
          <div className="animate-fade-in-up" style={{ animationDelay: '1200ms' }}>
            <div className="glass-card rounded-2xl p-8 border border-green-500/20 hover:border-green-500/40 transition-all duration-500 group">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-6">
                  <div className="relative">
                    <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-green-500/20 to-emerald-500/10 flex items-center justify-center group-hover:scale-110 transition-transform duration-500">
                      <FileText className="w-8 h-8 text-green-400" />
                    </div>
                    <div className="absolute -top-1 -right-1 w-6 h-6 bg-green-500/20 rounded-full flex items-center justify-center border border-green-500/30">
                      <span className="text-green-400 text-xs">✓</span>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <h3 className="text-xl font-semibold text-white group-hover:text-green-300 transition-colors duration-300">
                      {currentLanguage === 'en' ? 'ZATCA E-Invoicing' : 'الفوترة الإلكترونية زاتكا'}
                    </h3>
                    <p className="text-green-400 font-medium">
                      {currentLanguage === 'en' ? 'Fully compliant & operational' : 'متوافق تماماً ومشغل'}
                    </p>
                    <p className="text-gray-400">
                      {currentLanguage === 'en' ? 'XML, QR, PDF/A-3 certified' : 'XML، QR، PDF/A-3 معتمد'}
                    </p>
                  </div>
                </div>
                
                <div className="text-center">
                  <div className="w-20 h-20 rounded-full bg-gradient-to-br from-green-500/20 to-emerald-500/10 flex items-center justify-center border-2 border-green-500/30 group-hover:border-green-500/50 transition-all duration-500 mb-3">
                    <span className="text-green-400 text-2xl font-bold">✓</span>
                  </div>
                  <span className="text-green-400 text-sm font-medium">
                    {currentLanguage === 'en' ? 'Certified' : 'معتمد'}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Saudi Business Registry */}
          <div className="animate-fade-in-up" style={{ animationDelay: '1300ms' }}>
            <div className="glass-card rounded-2xl p-8 border border-amber-500/20 hover:border-amber-500/40 transition-all duration-500 group">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-6">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500/20 to-orange-500/10 flex items-center justify-center group-hover:scale-110 transition-transform duration-500">
                    <Building2 className="w-8 h-8 text-amber-400" />
                  </div>
                  
                  <div className="space-y-2">
                    <h3 className="text-xl font-semibold text-white group-hover:text-amber-300 transition-colors duration-300">
                      {currentLanguage === 'en' ? 'Saudi Business Registry' : 'السجل التجاري السعودي'}
                    </h3>
                    <p className="text-amber-400 font-medium">
                      {currentLanguage === 'en' ? 'License: 1010xxxxx' : 'الرخصة: 1010xxxxx'}
                    </p>
                    <p className="text-gray-400">
                      {currentLanguage === 'en' ? 'VAT: 300xxxxx400003' : 'ضريبة القيمة المضافة: 300xxxxx400003'}
                    </p>
                  </div>
                </div>
                
                <div className="text-center">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-500/20 to-orange-500/10 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-500">
                    <span className="text-2xl">🇸🇦</span>
                  </div>
                  <span className="text-amber-400 text-sm font-medium">
                    {currentLanguage === 'en' ? 'KSA' : 'السعودية'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Enhanced Saudi Market Insights */}
        <div className="animate-fade-in-up" style={{ animationDelay: '1400ms' }}>
          <div className="glass-card rounded-2xl p-8 border border-blue-500/20 hover:border-blue-500/40 transition-all duration-500 group">
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500/20 to-purple-500/10 flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-blue-400" />
                </div>
                <h3 className="text-2xl font-semibold text-white group-hover:text-blue-300 transition-colors duration-300">
                  {currentLanguage === 'en' ? 'Saudi Metal Market Insights' : 'رؤى السوق السعودي للمعادن'}
                </h3>
              </div>
              <Zap className="w-6 h-6 text-blue-400 animate-pulse" />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center p-6 rounded-xl glass-card border border-white/10 hover:border-emerald-500/30 transition-all duration-300 group/card">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-br from-emerald-500/20 to-teal-500/10 flex items-center justify-center group-hover/card:scale-110 transition-transform duration-300">
                  <TrendingUp className="w-8 h-8 text-emerald-400" />
                </div>
                <div className="text-white font-semibold mb-1">
                  {currentLanguage === 'en' ? 'Market Growth' : 'نمو السوق'}
                </div>
                <div className="text-emerald-400 text-3xl font-bold mb-2">+15.3%</div>
                <div className="text-gray-400 text-sm">
                  {currentLanguage === 'en' ? 'YoY 2024' : 'سنوياً 2024'}
                </div>
              </div>
              
              <div className="text-center p-6 rounded-xl glass-card border border-white/10 hover:border-blue-500/30 transition-all duration-300 group/card">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-br from-blue-500/20 to-cyan-500/10 flex items-center justify-center group-hover/card:scale-110 transition-transform duration-300">
                  <Target className="w-8 h-8 text-blue-400" />
                </div>
                <div className="text-white font-semibold mb-1">
                  {currentLanguage === 'en' ? 'Vision 2030 Impact' : 'تأثير رؤية 2030'}
                </div>
                <div className="text-blue-400 text-3xl font-bold mb-2">High</div>
                <div className="text-gray-400 text-sm">
                  {currentLanguage === 'en' ? 'Infrastructure' : 'البنية التحتية'}
                </div>
              </div>
              
              <div className="text-center p-6 rounded-xl glass-card border border-white/10 hover:border-purple-500/30 transition-all duration-300 group/card">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-br from-purple-500/20 to-pink-500/10 flex items-center justify-center group-hover/card:scale-110 transition-transform duration-300">
                  <Building2 className="w-8 h-8 text-purple-400" />
                </div>
                <div className="text-white font-semibold mb-1">
                  {currentLanguage === 'en' ? 'NEOM Projects' : 'مشاريع نيوم'}
                </div>
                <div className="text-purple-400 text-3xl font-bold mb-2">850M</div>
                <div className="text-gray-400 text-sm">
                  {currentLanguage === 'en' ? '﷼ Opportunity' : 'فرصة بالريال'}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}