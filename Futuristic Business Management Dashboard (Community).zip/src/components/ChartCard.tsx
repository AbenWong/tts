import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { MoreHorizontal, TrendingUp } from 'lucide-react';

interface ChartCardProps {
  title: string;
  currentLanguage: string;
  type?: 'line' | 'bar' | 'donut';
}

const revenueData = [
  { name: 'Jan', value: 2400, growth: 12 },
  { name: 'Feb', value: 1398, growth: -8 },
  { name: 'Mar', value: 9800, growth: 24 },
  { name: 'Apr', value: 3908, growth: 16 },
  { name: 'May', value: 4800, growth: 18 },
  { name: 'Jun', value: 3800, growth: 8 },
  { name: 'Jul', value: 4300, growth: 22 },
];

const projectData = [
  { name: 'Completed', value: 45, color: '#10b981' },
  { name: 'In Progress', value: 35, color: '#3b82f6' },
  { name: 'Pending', value: 20, color: '#f59e0b' },
];

const inventoryData = [
  { name: 'Steel', value: 4000 },
  { name: 'Aluminum', value: 3000 },
  { name: 'Copper', value: 2000 },
  { name: 'Iron', value: 2780 },
  { name: 'Other', value: 1890 },
];

export function ChartCard({ title, currentLanguage, type = 'line' }: ChartCardProps) {
  const renderChart = () => {
    switch (type) {
      case 'bar':
        return (
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={inventoryData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
              <XAxis 
                dataKey="name" 
                axisLine={false}
                tickLine={false}
                tick={{ fill: '#9ca3af', fontSize: 12 }}
              />
              <YAxis 
                axisLine={false}
                tickLine={false}
                tick={{ fill: '#9ca3af', fontSize: 12 }}
              />
              <Bar 
                dataKey="value" 
                fill="url(#barGradient)"
                radius={[4, 4, 0, 0]}
              />
              <defs>
                <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#3b82f6" />
                  <stop offset="100%" stopColor="#1d4ed8" />
                </linearGradient>
              </defs>
            </BarChart>
          </ResponsiveContainer>
        );
      
      case 'donut':
        return (
          <div className="relative">
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={projectData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {projectData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <div className="text-2xl font-bold text-white">85%</div>
                <div className="text-sm text-gray-400">
                  {currentLanguage === 'en' ? 'Complete' : 'مكتمل'}
                </div>
              </div>
            </div>
          </div>
        );
      
      default:
        return (
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={revenueData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
              <XAxis 
                dataKey="name" 
                axisLine={false}
                tickLine={false}
                tick={{ fill: '#9ca3af', fontSize: 12 }}
              />
              <YAxis 
                axisLine={false}
                tickLine={false}
                tick={{ fill: '#9ca3af', fontSize: 12 }}
              />
              <Line 
                type="monotone" 
                dataKey="value" 
                stroke="url(#lineGradient)"
                strokeWidth={3}
                dot={{ fill: '#3b82f6', strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6, fill: '#3b82f6' }}
              />
              <defs>
                <linearGradient id="lineGradient" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#3b82f6" />
                  <stop offset="100%" stopColor="#8b5cf6" />
                </linearGradient>
              </defs>
            </LineChart>
          </ResponsiveContainer>
        );
    }
  };

  return (
    <div className="relative overflow-hidden">
      <div className="p-6 rounded-2xl backdrop-blur-xl bg-white/5 dark:bg-black/20 border border-white/10 dark:border-white/5 hover:border-white/20 dark:hover:border-white/10 transition-all duration-300">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-semibold text-white mb-1">{title}</h3>
            <div className="flex items-center space-x-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              <span className="text-emerald-400 text-sm font-medium">+12.5%</span>
              <span className="text-gray-400 text-sm">
                {currentLanguage === 'en' ? 'vs last month' : 'مقارنة بالشهر الماضي'}
              </span>
            </div>
          </div>
          <button className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors">
            <MoreHorizontal className="w-4 h-4 text-gray-400" />
          </button>
        </div>

        {/* Chart */}
        <div className="relative">
          {renderChart()}
          
          {/* Glow effect */}
          <div className="absolute inset-0 bg-gradient-to-t from-blue-500/5 to-transparent pointer-events-none rounded-lg"></div>
        </div>

        {/* Legend for donut chart */}
        {type === 'donut' && (
          <div className="mt-4 flex flex-wrap gap-4">
            {projectData.map((item, index) => (
              <div key={index} className="flex items-center space-x-2">
                <div 
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: item.color }}
                ></div>
                <span className="text-gray-400 text-sm">{item.name}</span>
                <span className="text-white text-sm font-medium">{item.value}%</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}