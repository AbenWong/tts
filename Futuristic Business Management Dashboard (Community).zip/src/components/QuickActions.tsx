import React from 'react';
import { Plus, FileText, Package, Users, Coins, Upload, Download, Zap, Receipt, Building2 } from 'lucide-react';

interface QuickActionsProps {
  currentLanguage: string;
}

export function QuickActions({ currentLanguage }: QuickActionsProps) {
  const actions = [
    {
      icon: FileText,
      label: { en: 'ZATCA Invoice', ar: 'فاتورة زاتكا' },
      color: 'from-blue-500 to-cyan-600',
      description: { en: 'Create compliant XML invoice', ar: 'إنشاء فاتورة XML متوافقة' }
    },
    {
      icon: Package,
      label: { en: 'Metal Inventory', ar: 'مخزون المعادن' },
      color: 'from-purple-500 to-indigo-600',
      description: { en: 'Track scrap materials', ar: 'تتبع المواد المستعملة' }
    },
    {
      icon: Users,
      label: { en: 'Saudi Customer', ar: 'عميل سعودي' },
      color: 'from-emerald-500 to-teal-600',
      description: { en: 'Register with VAT number', ar: 'تسجيل برقم ضريبي' }
    },
    {
      icon: Coins,
      label: { en: 'Riyal Payment', ar: 'دفعة بالريال' },
      color: 'from-orange-500 to-red-600',
      description: { en: 'Process ﷼ transactions', ar: 'معالجة معاملات الريال' }
    },
    {
      icon: Building2,
      label: { en: 'Supplier Portal', ar: 'بوابة الموردين' },
      color: 'from-amber-500 to-yellow-600',
      description: { en: 'Manage Saudi suppliers', ar: 'إدارة الموردين السعوديين' }
    },
    {
      icon: Receipt,
      label: { en: 'VAT Report', ar: 'تقرير ضريبة القيمة المضافة' },
      color: 'from-pink-500 to-rose-600',
      description: { en: 'Generate tax reports', ar: 'إنتاج التقارير الضريبية' }
    }
  ];

  return (
    <div className="p-6 rounded-2xl backdrop-blur-xl bg-gradient-to-b from-white/10 via-white/5 to-transparent dark:from-black/40 dark:via-black/20 dark:to-transparent border border-white/10 dark:border-white/5 hover:border-amber-500/20 transition-all duration-300">
      {/* Enhanced Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center shadow-lg">
            <Zap className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white">
              {currentLanguage === 'en' ? 'Quick Actions' : 'الإجراءات السريعة'}
            </h3>
            <p className="text-amber-400 text-xs">
              {currentLanguage === 'en' ? 'Saudi Business Operations' : 'العمليات التجارية السعودية'}
            </p>
          </div>
        </div>
        <Plus className="w-4 h-4 text-amber-400" />
      </div>

      {/* Enhanced Actions Grid */}
      <div className="space-y-3">
        {actions.map((action, index) => {
          const Icon = action.icon;
          return (
            <button
              key={index}
              className="w-full group relative overflow-hidden rounded-xl bg-white/5 hover:bg-gradient-to-r hover:from-white/10 hover:to-amber-500/5 border border-white/10 hover:border-amber-500/30 transition-all duration-500 p-4"
            >
              {/* Enhanced gradient overlay */}
              <div className={`absolute inset-0 bg-gradient-to-r ${action.color} opacity-0 group-hover:opacity-15 transition-opacity duration-500`}></div>
              
              {/* Content */}
              <div className="relative z-10 flex items-center space-x-4">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${action.color} flex items-center justify-center shadow-xl group-hover:scale-110 group-hover:shadow-2xl transition-all duration-500`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1 text-left">
                  <h4 className="text-white font-medium group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:from-white group-hover:via-amber-200 group-hover:to-white group-hover:bg-clip-text transition-all duration-500">
                    {action.label[currentLanguage as keyof typeof action.label]}
                  </h4>
                  <p className="text-gray-400 text-sm group-hover:text-amber-300/80 transition-colors duration-300">
                    {action.description[currentLanguage as keyof typeof action.description]}
                  </p>
                </div>
                <div className="opacity-0 group-hover:opacity-100 transition-all duration-500 transform group-hover:scale-110">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-r from-amber-500/20 to-orange-500/20 border border-amber-500/30 flex items-center justify-center">
                    <Plus className="w-4 h-4 text-amber-400" />
                  </div>
                </div>
              </div>

              {/* Enhanced shine effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000 skew-x-12"></div>
            </button>
          );
        })}
      </div>

      {/* Enhanced Bottom CTA */}
      <div className="mt-6 pt-4 border-t border-gradient-to-r from-transparent via-amber-500/20 to-transparent">
        <button className="w-full p-4 rounded-xl bg-gradient-to-r from-amber-500/20 via-orange-500/10 to-amber-500/20 border border-amber-500/30 hover:border-amber-500/50 text-white font-medium transition-all duration-500 hover:scale-105 hover:shadow-lg hover:shadow-amber-500/20 group">
          <div className="flex items-center justify-center space-x-2">
            <span className="group-hover:text-amber-300 transition-colors duration-300">
              {currentLanguage === 'en' ? 'View All Saudi Business Tools' : 'عرض جميع أدوات الأعمال السعودية'}
            </span>
            <div className="w-4 h-4 rounded-full bg-amber-500/30 flex items-center justify-center group-hover:bg-amber-500/50 transition-colors duration-300">
              <Plus className="w-2 h-2 text-amber-400" />
            </div>
          </div>
        </button>
      </div>
    </div>
  );
}