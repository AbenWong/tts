import React from 'react';
import { 
  LayoutDashboard, 
  FileText, 
  Package, 
  Users, 
  CreditCard, 
  FolderOpen, 
  UserCheck, 
  TrendingUp, 
  Calculator, 
  Settings,
  ChevronLeft,
  Building2,
  Receipt,
  Warehouse,
  HandCoins,
  HardDrive
} from 'lucide-react';
import companyLogo from 'figma:asset/8183a3510547518ded712961641d78e961eddcca.png';

interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
  currentLanguage: string;
}

const navigation = [
  { 
    key: 'dashboard', 
    icon: LayoutDashboard, 
    label: { en: 'Dashboard', ar: 'لوحة التحكم' },
    active: true 
  },
  { 
    key: 'invoices', 
    icon: FileText, 
    label: { en: 'ZATCA Invoices', ar: 'فواتير زاتكا' },
    badge: '12' 
  },
  { 
    key: 'inventory', 
    icon: Package, 
    label: { en: 'Metal Inventory', ar: 'مخزون المعادن' } 
  },
  { 
    key: 'customers', 
    icon: Users, 
    label: { en: 'Customers', ar: 'العملاء' } 
  },
  { 
    key: 'suppliers', 
    icon: Building2, 
    label: { en: 'Suppliers', ar: 'الموردون' } 
  },
  { 
    key: 'payments', 
    icon: CreditCard, 
    label: { en: 'Payments', ar: 'المدفوعات' } 
  },
  { 
    key: 'projects', 
    icon: FolderOpen, 
    label: { en: 'Projects', ar: 'المشاريع' } 
  },
  { 
    key: 'procurement', 
    icon: Warehouse, 
    label: { en: 'Procurement', ar: 'المشتريات' } 
  },
  { 
    key: 'employees', 
    icon: UserCheck, 
    label: { en: 'Employees', ar: 'الموظفون' } 
  },
  { 
    key: 'loans', 
    icon: HandCoins, 
    label: { en: 'Loans', ar: 'القروض' } 
  },
  { 
    key: 'reports', 
    icon: TrendingUp, 
    label: { en: 'Reports', ar: 'التقارير' } 
  },
  { 
    key: 'vat', 
    icon: Receipt, 
    label: { en: 'VAT & ZATCA', ar: 'ضريبة القيمة المضافة' } 
  },
  { 
    key: 'accounting', 
    icon: Calculator, 
    label: { en: 'Accounting', ar: 'المحاسبة' } 
  },
  { 
    key: 'settings', 
    icon: Settings, 
    label: { en: 'Settings', ar: 'الإعدادات' } 
  },
];

export function Sidebar({ collapsed, onToggle, currentLanguage }: SidebarProps) {
  const isRTL = currentLanguage === 'ar';

  return (
    <div className={`fixed left-0 top-0 h-full z-30 transition-all duration-300 ${
      collapsed ? 'w-16' : 'w-80'
    }`}>
      {/* Premium dark sidebar */}
      <div className="h-full backdrop-blur-xl bg-gradient-to-b from-gray-900/90 via-slate-900/80 to-gray-900/90 border-r border-slate-700/30">
        {/* Company Header */}
        <div className="p-4 border-b border-slate-700/30">
          <div className="flex items-center justify-between">
            {!collapsed && (
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <img 
                    src={companyLogo} 
                    alt="AMANAT AL-KALIMA COMPANY" 
                    className="w-12 h-12 object-contain rounded-xl shadow-lg"
                  />
                  <div className="absolute inset-0 bg-gradient-to-br from-amber-500/20 to-transparent rounded-xl"></div>
                </div>
                <div className={`${isRTL ? 'text-right' : 'text-left'}`}>
                  <h1 className="text-white font-medium text-sm leading-tight">
                    {currentLanguage === 'en' ? 'AMANAT AL-KALIMA' : 'أمانات الكلمة'}
                  </h1>
                  <h2 className="text-amber-400 text-xs font-medium">
                    {currentLanguage === 'en' ? 'COMPANY' : 'الشركة'}
                  </h2>
                  <p className="text-gray-400 text-xs mt-1">
                    {currentLanguage === 'en' ? 'Scrap Metal Trading' : 'تجارة المعادن المستعملة'}
                  </p>
                </div>
              </div>
            )}
            {collapsed && (
              <div className="flex justify-center w-full">
                <img 
                  src={companyLogo} 
                  alt="AMANAT AL-KALIMA" 
                  className="w-8 h-8 object-contain rounded-lg"
                />
              </div>
            )}
            <button
              onClick={onToggle}
              className="p-2 rounded-lg bg-slate-800/50 hover:bg-amber-500/20 transition-all duration-300 hover:scale-110"
            >
              <ChevronLeft 
                className={`w-4 h-4 text-amber-400 transition-transform ${
                  collapsed ? 'rotate-180' : ''
                }`} 
              />
            </button>
          </div>
        </div>

        {/* Enhanced Navigation */}
        <nav className="p-4 space-y-2">
          {navigation.map((item) => {
            const Icon = item.icon;
            return (
              <div key={item.key} className="relative group">
                <button
                  className={`w-full flex items-center ${isRTL ? 'flex-row-reverse space-x-reverse' : ''} space-x-3 px-3 py-3 rounded-xl transition-all duration-300 ${
                    item.active
                      ? 'bg-gradient-to-r from-amber-500/20 via-amber-400/10 to-transparent text-white border border-amber-500/30 shadow-lg shadow-amber-500/10'
                      : 'text-gray-400 hover:text-white hover:bg-gradient-to-r hover:from-slate-800/50 hover:to-transparent hover:border-slate-600/30 border border-transparent'
                  }`}
                >
                  <Icon className="w-5 h-5 flex-shrink-0" />
                  {!collapsed && (
                    <>
                      <span className={`flex-1 ${isRTL ? 'text-right font-medium' : 'text-left'}`}>
                        {item.label[currentLanguage as keyof typeof item.label]}
                      </span>
                      {item.badge && (
                        <span className="px-2 py-1 text-xs bg-amber-500/20 text-amber-300 rounded-full border border-amber-500/30">
                          {item.badge}
                        </span>
                      )}
                    </>
                  )}
                </button>

                {/* Enhanced tooltip for collapsed state */}
                {collapsed && (
                  <div className="absolute left-full ml-2 top-1/2 transform -translate-y-1/2 px-3 py-2 bg-gray-900/90 backdrop-blur-sm text-white text-sm rounded-lg opacity-0 group-hover:opacity-100 transition-all duration-300 whitespace-nowrap z-50 border border-amber-500/20">
                    {item.label[currentLanguage as keyof typeof item.label]}
                    <div className="absolute left-0 top-1/2 transform -translate-y-1/2 -translate-x-1 w-2 h-2 bg-gray-900 rotate-45 border-l border-b border-amber-500/20"></div>
                  </div>
                )}
              </div>
            );
          })}
        </nav>

        {/* Enhanced bottom section - Offline System Status */}
        {!collapsed && (
          <div className="absolute bottom-4 left-4 right-4">
            <div className="p-4 rounded-xl bg-gradient-to-r from-slate-800/50 to-gray-800/30 border border-slate-700/30 backdrop-blur-sm">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-slate-600 to-slate-700 flex items-center justify-center shadow-lg">
                  <HardDrive className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1">
                  <p className="text-white text-sm font-medium">
                    {currentLanguage === 'en' ? 'Local System' : 'النظام المحلي'}
                  </p>
                  <p className="text-slate-400 text-xs">
                    {currentLanguage === 'en' ? 'Offline Mode' : 'وضع عدم الاتصال'}
                  </p>
                </div>
              </div>
              <div className="mt-3 flex items-center justify-between text-xs">
                <span className="text-gray-400">
                  {currentLanguage === 'en' ? 'ZATCA Ready' : 'جاهز لزاتكا'}
                </span>
                <div className="flex items-center space-x-1">
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                  <span className="text-green-400">
                    {currentLanguage === 'en' ? 'Online' : 'متصل'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}