import React from 'react';
import { FileText, Package, Users, Coins, AlertCircle, Clock, CheckCircle, Building2 } from 'lucide-react';

interface RecentActivityProps {
  currentLanguage: string;
}

export function RecentActivity({ currentLanguage }: RecentActivityProps) {
  const activities = [
    {
      id: 1,
      icon: FileText,
      type: 'zatca',
      title: { en: 'ZATCA Invoice #INV-2024-001 created', ar: 'تم إنشاء فاتورة زاتكا #INV-2024-001' },
      description: { en: 'XML + QR generated, 15,750 ﷼', ar: 'تم إنتاج XML + QR، 15,750 ريال سعودي' },
      time: '5 min ago',
      status: 'success',
      color: 'from-blue-500 to-cyan-600'
    },
    {
      id: 2,
      icon: Package,
      type: 'inventory',
      title: { en: 'Steel scrap inventory updated', ar: 'تم تحديث مخزون خردة الصلب' },
      description: { en: '2.5 tons added, worth 12,250 ﷼', ar: 'تم إضافة 2.5 طن، بقيمة 12,250 ريال' },
      time: '12 min ago',
      status: 'info',
      color: 'from-purple-500 to-indigo-600'
    },
    {
      id: 3,
      icon: Building2,
      type: 'customer',
      title: { en: 'New Saudi customer registered', ar: 'تم تسجيل عميل سعودي جديد' },
      description: { en: 'Riyadh Steel Trading - VAT: 300123456700003', ar: 'الرياض لتجارة الصلب - ضريبة: 300123456700003' },
      time: '25 min ago',
      status: 'success',
      color: 'from-emerald-500 to-teal-600'
    },
    {
      id: 4,
      icon: Coins,
      type: 'payment',
      title: { en: 'Riyal payment received', ar: 'تم استلام دفعة بالريال السعودي' },
      description: { en: '45,000 ﷼ from Al-Khobar Metals', ar: '45,000 ريال من معادن الخبر' },
      time: '1 hour ago',
      status: 'success',
      color: 'from-amber-500 to-orange-600'
    },
    {
      id: 5,
      icon: AlertCircle,
      type: 'alert',
      title: { en: 'Aluminum inventory low', ar: 'انخفاض مخزون الألومنيوم' },
      description: { en: 'Below 500kg threshold, reorder needed', ar: 'أقل من 500 كيلو، مطلوب إعادة طلب' },
      time: '2 hours ago',
      status: 'warning',
      color: 'from-yellow-500 to-orange-600'
    }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="w-3 h-3 text-emerald-400" />;
      case 'warning':
        return <AlertCircle className="w-3 h-3 text-yellow-400" />;
      default:
        return <Clock className="w-3 h-3 text-blue-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success':
        return 'bg-emerald-500/10 border-emerald-500/20';
      case 'warning':
        return 'bg-yellow-500/10 border-yellow-500/20';
      default:
        return 'bg-blue-500/10 border-blue-500/20';
    }
  };

  return (
    <div className="p-6 rounded-2xl backdrop-blur-xl bg-gradient-to-b from-white/10 via-white/5 to-transparent dark:from-black/40 dark:via-black/20 dark:to-transparent border border-white/10 dark:border-white/5 hover:border-amber-500/20 transition-all duration-300">
      {/* Enhanced Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-lg">
            <Clock className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white">
              {currentLanguage === 'en' ? 'Recent Activity' : 'النشاط الأخير'}
            </h3>
            <p className="text-emerald-400 text-xs">
              {currentLanguage === 'en' ? 'Live Business Updates' : 'تحديثات العمل المباشرة'}
            </p>
          </div>
        </div>
        <button className="text-emerald-400 hover:text-emerald-300 text-sm font-medium transition-colors hover:bg-emerald-500/10 px-3 py-1 rounded-lg">
          {currentLanguage === 'en' ? 'View All' : 'عرض الكل'}
        </button>
      </div>

      {/* Enhanced Activities List */}
      <div className="space-y-4">
        {activities.map((activity, index) => {
          const Icon = activity.icon;
          return (
            <div key={activity.id} className="group relative">
              {/* Enhanced timeline line */}
              {index < activities.length - 1 && (
                <div className="absolute left-7 top-16 w-px h-8 bg-gradient-to-b from-amber-500/30 via-emerald-500/20 to-transparent"></div>
              )}
              
              <div className="flex items-start space-x-4 p-4 rounded-xl bg-gradient-to-r from-white/5 to-transparent hover:from-white/10 hover:to-amber-500/5 border border-white/10 hover:border-amber-500/30 transition-all duration-500">
                {/* Enhanced Icon */}
                <div className={`relative flex-shrink-0 w-12 h-12 rounded-xl bg-gradient-to-br ${activity.color} flex items-center justify-center shadow-xl group-hover:scale-110 group-hover:shadow-2xl transition-all duration-500`}>
                  <Icon className="w-6 h-6 text-white" />
                  
                  {/* Enhanced Status indicator */}
                  <div className={`absolute -top-1 -right-1 w-5 h-5 rounded-full ${getStatusColor(activity.status)} flex items-center justify-center border-2 border-current backdrop-blur-sm`}>
                    {getStatusIcon(activity.status)}
                  </div>
                </div>

                {/* Enhanced Content */}
                <div className="flex-1 min-w-0">
                  <h4 className="text-white font-medium group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:from-white group-hover:via-amber-200 group-hover:to-white group-hover:bg-clip-text transition-all duration-500">
                    {activity.title[currentLanguage as keyof typeof activity.title]}
                  </h4>
                  <p className="text-gray-400 text-sm mt-1 group-hover:text-amber-300/80 transition-colors duration-300">
                    {activity.description[currentLanguage as keyof typeof activity.description]}
                  </p>
                  <div className="flex items-center space-x-2 mt-2">
                    <Clock className="w-3 h-3 text-gray-500" />
                    <span className="text-gray-500 text-xs">{activity.time}</span>
                    {activity.type === 'zatca' && (
                      <>
                        <span className="text-gray-500">•</span>
                        <span className="text-green-400 text-xs font-medium">ZATCA ✓</span>
                      </>
                    )}
                    {activity.type === 'payment' && (
                      <>
                        <span className="text-gray-500">•</span>
                        <span className="text-amber-400 text-xs font-medium">﷼ Riyal</span>
                      </>
                    )}
                  </div>
                </div>

                {/* Saudi business indicator */}
                <div className="opacity-0 group-hover:opacity-100 transition-all duration-500 transform group-hover:scale-110">
                  <div className="w-3 h-3 rounded-full bg-gradient-to-r from-emerald-500 to-amber-500 shadow-lg"></div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Enhanced Footer with Saudi business context */}
      <div className="mt-6 pt-4 border-t border-gradient-to-r from-transparent via-amber-500/20 to-transparent">
        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-400">
            {currentLanguage === 'en' ? 'Last sync: 30 seconds ago' : 'آخر مزامنة: منذ 30 ثانية'}
          </span>
          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-1">
              <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
              <span className="text-emerald-400 text-xs font-medium">
                {currentLanguage === 'en' ? 'Live' : 'مباشر'}
              </span>
            </div>
            <div className="flex items-center space-x-1">
              <span className="text-amber-400 text-xs">🇸🇦</span>
              <span className="text-amber-400 text-xs font-medium">KSA</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}