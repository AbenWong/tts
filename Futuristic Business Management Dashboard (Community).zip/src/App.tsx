import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { TopNavigation } from './components/TopNavigation';

export default function App() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [currentLanguage, setCurrentLanguage] = useState('en');
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  // Track mouse movement for interactive background
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <div className={`min-h-screen transition-all duration-700 ease-out ${isDarkMode ? 'dark' : ''}`}>
      {/* Premium Dark Background */}
      <div className="fixed inset-0 overflow-hidden">
        {/* Base dark gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-gray-950 via-slate-900 to-gray-950"></div>
        
        {/* Secondary texture overlay */}
        <div className="absolute inset-0 bg-gradient-to-tr from-blue-950/20 via-transparent to-purple-950/20"></div>
        
        {/* Luxury mesh pattern */}
        <div className="absolute inset-0 opacity-30">
          <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="luxuryGrid" width="80" height="80" patternUnits="userSpaceOnUse">
                <path d="M 80 0 L 0 0 0 80" fill="none" stroke="url(#luxuryGradient)" strokeWidth="0.3"/>
              </pattern>
              <linearGradient id="luxuryGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#1e293b" stopOpacity={0.4}/>
                <stop offset="50%" stopColor="#475569" stopOpacity={0.2}/>
                <stop offset="100%" stopColor="#334155" stopOpacity={0.1}/>
              </linearGradient>
            </defs>
            <rect width="100%" height="100%" fill="url(#luxuryGrid)"/>
          </svg>
        </div>
        
        {/* Interactive premium spotlight */}
        <div 
          className="absolute w-[600px] h-[600px] bg-gradient-radial from-amber-900/15 via-amber-800/8 to-transparent rounded-full blur-3xl transition-all duration-500 ease-out pointer-events-none"
          style={{
            left: mousePosition.x - 300,
            top: mousePosition.y - 300,
            transform: 'translate3d(0, 0, 0)',
          }}
        ></div>
        
        {/* Subtle accent gradients */}
        <div className="absolute top-0 left-0 w-1/3 h-1/3 bg-gradient-radial from-blue-900/10 to-transparent blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-1/3 h-1/3 bg-gradient-radial from-purple-900/10 to-transparent blur-3xl"></div>
        
        {/* Premium floating elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {/* Sophisticated floating orbs */}
          <div className="absolute top-1/6 left-1/8 w-40 h-40 bg-gradient-to-br from-slate-700/10 to-slate-800/5 rounded-full blur-2xl animate-float"></div>
          <div className="absolute top-2/3 right-1/6 w-32 h-32 bg-gradient-to-br from-gray-700/8 to-gray-800/4 rounded-full blur-xl animate-float-delayed"></div>
          <div className="absolute top-1/2 left-2/3 w-48 h-48 bg-gradient-to-br from-slate-800/6 to-slate-900/3 rounded-full blur-3xl animate-float-slow"></div>
          
          {/* Premium accent dots */}
          <div className="absolute top-1/4 left-1/2 w-1 h-1 bg-amber-500/30 rounded-full animate-twinkle"></div>
          <div className="absolute top-3/5 right-1/3 w-1.5 h-1.5 bg-slate-400/20 rounded-full animate-twinkle-delayed"></div>
          <div className="absolute top-4/5 left-1/4 w-0.5 h-0.5 bg-gray-400/40 rounded-full animate-twinkle-slow"></div>
          <div className="absolute top-1/8 right-1/4 w-2 h-2 bg-slate-500/15 rounded-full animate-pulse"></div>
        </div>
        
        {/* Simplified luxury texture overlay */}
        <div className="absolute inset-0 opacity-[0.02] bg-gradient-to-br from-slate-700/10 via-transparent to-slate-600/5"></div>
      </div>

      {/* Main app container with enhanced depth */}
      <div className="relative z-10 flex min-h-screen">
        {/* Enhanced sidebar with better transitions */}
        <div className={`transition-all duration-500 ease-out ${sidebarCollapsed ? 'w-16' : 'w-80'}`}>
          <Sidebar 
            collapsed={sidebarCollapsed} 
            onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
            currentLanguage={currentLanguage}
          />
        </div>
        
        {/* Main content area with refined spacing */}
        <div className="flex-1 flex flex-col min-h-screen overflow-hidden">
          {/* Top navigation with enhanced styling */}
          <div className="sticky top-0 z-20">
            <TopNavigation 
              isDarkMode={isDarkMode}
              onThemeToggle={() => setIsDarkMode(!isDarkMode)}
              currentLanguage={currentLanguage}
              onLanguageChange={(lang) => setCurrentLanguage(lang)}
            />
          </div>
          
          {/* Dashboard content with improved scrolling */}
          <div className="flex-1 overflow-y-auto overflow-x-hidden">
            <div className="min-h-full">
              <Dashboard currentLanguage={currentLanguage} />
            </div>
          </div>
        </div>
      </div>

      {/* Modern offline status indicator */}
      <div className="fixed bottom-8 right-8 z-30 pointer-events-none">
        <div className="relative">
          <div className="w-12 h-12 bg-gradient-to-br from-slate-600/20 to-slate-700/10 rounded-full border border-slate-500/30 backdrop-blur-xl flex items-center justify-center">
            <div className="w-2 h-2 bg-green-400 rounded-full shadow-lg shadow-green-400/50"></div>
          </div>
          <div className="absolute inset-0 bg-gradient-to-br from-slate-600/10 to-transparent rounded-full blur-lg"></div>
        </div>
      </div>
    </div>
  );
}