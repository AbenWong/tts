import { useState } from "react";
import { Header } from "./components/Header";
import { MetricsRow } from "./components/MetricsRow";
import { MainVisualizationRow } from "./components/MainVisualizationRow";
import { CostBudgetRow } from "./components/CostBudgetRow";
import { SupplementaryInfoRow } from "./components/SupplementaryInfoRow";
import { CollapsibleRiskDashboard } from "./components/CollapsibleRiskDashboard";
import { StaffOverview } from "./components/StaffOverview";
import { Skeleton } from "./components/ui/skeleton";

export default function App() {
  const [isLoading, setIsLoading] = useState(true);

  // Simulate data loading
  useState(() => {
    setTimeout(() => setIsLoading(false), 1200);
  });

  return (
    <div className="min-h-screen bg-[#F3F3F3]">
      <Header />
      
      <main className="max-w-[1600px] mx-auto p-6 space-y-6">
        {/* Row 1: Core Metrics */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-[140px] rounded-lg" />
            ))}
          </div>
        ) : (
          <MetricsRow />
        )}

        {/* Row 2: Main Data Visualization */}
        {isLoading ? (
          <Skeleton className="h-[400px] rounded-lg" />
        ) : (
          <MainVisualizationRow />
        )}

        {/* Row 3: Cost & Budget Metrics */}
        {isLoading ? (
          <Skeleton className="h-[280px] rounded-lg" />
        ) : (
          <CostBudgetRow />
        )}

        {/* Row 4: Supplementary Information */}
        {isLoading ? (
          <Skeleton className="h-[300px] rounded-lg" />
        ) : (
          <SupplementaryInfoRow />
        )}

        {/* Row 5: Risk Indicators (Collapsible) */}
        {isLoading ? (
          <Skeleton className="h-[200px] rounded-lg" />
        ) : (
          <CollapsibleRiskDashboard />
        )}

        {/* Row 6: Employee & Attrition Overview */}
        {isLoading ? (
          <Skeleton className="h-[350px] rounded-lg" />
        ) : (
          <StaffOverview />
        )}
      </main>
    </div>
  );
}
