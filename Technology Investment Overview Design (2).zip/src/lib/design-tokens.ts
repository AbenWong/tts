// HSBC Design System Tokens
export const colors = {
  primary: {
    red: '#DB0011',
    darkRed: '#A8000B',
    black: '#000000',
    white: '#FFFFFF',
  },
  semantic: {
    success: '#3E701A',
    successLight: '#4C7C27',
    warning: '#FFBB33',
    error: '#A8000B',
    info: '#2D6980',
    infoLight: '#347893',
  },
  grayscale: {
    50: '#F3F3F3',
    100: '#EDEDED',
    200: '#D7D8D6',
    500: '#767676',
    900: '#333333',
  },
  chart: {
    blue: '#2D6980',
    green: '#4C7C27',
    pink: '#E26F98',
    teal: '#347893',
  },
} as const;

export const shadows = {
  card: '0 2px 8px rgba(0,0,0,0.1)',
  cardHover: '0 4px 16px rgba(0,0,0,0.15)',
  subtle: '0 1px 3px rgba(0,0,0,0.08)',
} as const;

export const transitions = {
  fast: '200ms cubic-bezier(0.4, 0, 0.2, 1)',
  medium: '300ms cubic-bezier(0.4, 0, 0.2, 1)',
  slow: '400ms cubic-bezier(0.4, 0, 0.2, 1)',
} as const;

export const spacing = {
  xs: '0.25rem',
  sm: '0.5rem',
  md: '1rem',
  lg: '1.5rem',
  xl: '2rem',
  '2xl': '3rem',
} as const;
