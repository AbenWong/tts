import { useState } from "react";
import { motion } from "motion/react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { shadows } from "../lib/design-tokens";

const data = [
  { category: "Telecom", "2024": 23.39, "2025 YTD": 0 },
  { category: "NetOpex", "2024": 74.1, "2025 YTD": 81.2 },
  { category: "Infra", "2024": 1.579, "2025 YTD": 1.53 },
  { category: "Cyber", "2024": 17.008, "2025 YTD": 0 },
  { category: "CTB", "2024": 89.2, "2025 YTD": 911.53 },
];

export function CategoryChart() {
  const [opacity, setOpacity] = useState({ "2024": 1, "2025 YTD": 1 });

  const handleMouseEnter = (dataKey: string) => {
    setOpacity({ ...opacity, [dataKey]: 0.5 });
  };

  const handleMouseLeave = (dataKey: string) => {
    setOpacity({ ...opacity, [dataKey]: 1 });
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3, delay: 0.1 }}
      whileHover={{ boxShadow: shadows.cardHover }}
      className="bg-white rounded-lg p-6 shadow-sm transition-all duration-200"
      style={{ boxShadow: shadows.card }}
    >
      <h2 className="text-[#333333] mb-6">TECH INVESTMENT - BY CATEGORY</h2>
      <ResponsiveContainer width="100%" height={350}>
        <BarChart data={data} layout="vertical" margin={{ left: 20 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#EDEDED" />
          <XAxis type="number" stroke="#767676" />
          <YAxis dataKey="category" type="category" stroke="#767676" width={80} />
          <Tooltip
            contentStyle={{
              backgroundColor: "white",
              border: "1px solid #EDEDED",
              borderRadius: "8px",
              boxShadow: shadows.card,
            }}
            formatter={(value: number) => `${value}m$`}
            cursor={{ fill: "rgba(219, 0, 17, 0.05)" }}
          />
          <Legend
            onMouseEnter={(e) => handleMouseEnter(e.dataKey as string)}
            onMouseLeave={(e) => handleMouseLeave(e.dataKey as string)}
            wrapperStyle={{ cursor: "pointer" }}
          />
          <Bar
            dataKey="2024"
            fill="#D7D8D6"
            radius={[0, 4, 4, 0]}
            animationDuration={800}
            opacity={opacity["2024"]}
          />
          <Bar
            dataKey="2025 YTD"
            fill="#DB0011"
            radius={[0, 4, 4, 0]}
            animationDuration={800}
            animationBegin={200}
            opacity={opacity["2025 YTD"]}
          />
        </BarChart>
      </ResponsiveContainer>
    </motion.div>
  );
}
