import { ArrowUp, Info } from "lucide-react";
import { motion } from "motion/react";
import { useCountUp } from "../hooks/useCountUp";
import { useInView } from "../hooks/useInView";
import { colors, shadows } from "../lib/design-tokens";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "./ui/tooltip";

interface MetricCardProps {
  title: string;
  value: number;
  suffix?: string;
  trend?: {
    value: string;
    direction: "up" | "down";
  };
  subtitle?: string;
  tooltip?: string;
  isPlaceholder?: boolean;
  delay?: number;
}

function MetricCard({
  title,
  value,
  suffix = "m$",
  trend,
  subtitle,
  tooltip,
  isPlaceholder,
  delay = 0,
}: MetricCardProps) {
  const { ref, isInView } = useInView({ threshold: 0.3 });
  const animatedValue = useCountUp(isInView ? value : 0, 1000);

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay }}
      whileHover={{
        y: -4,
        boxShadow: shadows.cardHover,
      }}
      className="bg-white rounded-lg p-6 shadow-sm transition-all duration-200"
      style={{ boxShadow: shadows.card }}
    >
      <div className="flex items-start justify-between mb-2">
        <div className="text-xs text-[#767676]">{title}</div>
        {tooltip && (
          <TooltipProvider>
            <Tooltip delayDuration={300}>
              <TooltipTrigger>
                <Info className="w-4 h-4 text-[#2D6980]" />
              </TooltipTrigger>
              <TooltipContent>
                <p className="max-w-[200px]">{tooltip}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        )}
      </div>

      {isPlaceholder ? (
        <div className="flex items-center justify-center h-20">
          <p className="text-sm text-[#767676] text-center">Data Preparing</p>
        </div>
      ) : (
        <>
          <motion.div
            className={trend ? "text-[#DB0011]" : "text-[#333333]"}
            style={{ fontSize: "32px", fontWeight: "700" }}
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.3, delay: delay + 0.2 }}
          >
            {animatedValue.toFixed(2)}
            {suffix}
          </motion.div>

          {trend && (
            <motion.div
              className="flex items-center gap-1 text-[#3E701A] mt-2"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: delay + 0.4 }}
            >
              <ArrowUp className="w-4 h-4" />
              <span className="text-sm">{trend.value}</span>
            </motion.div>
          )}

          {subtitle && (
            <div className="text-sm text-[#767676] mt-2">{subtitle}</div>
          )}
        </>
      )}
    </motion.div>
  );
}

export function MetricsRow() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <MetricCard
        title="TECH INVESTMENT - 2025 YTD (Q2)"
        value={163.39}
        trend={{ value: "YoY Growth +2%", direction: "up" }}
        delay={0}
      />
      <MetricCard
        title="TECH INVESTMENT - 2024 TOTAL"
        value={340.12}
        subtitle="29% of HBCN COST"
        delay={0.1}
      />
      <MetricCard
        title="Technology Investment Business Value Contribution Rate"
        value={0}
        isPlaceholder
        tooltip="Business value contribution rate metrics are being calculated"
        delay={0.2}
      />
    </div>
  );
}
