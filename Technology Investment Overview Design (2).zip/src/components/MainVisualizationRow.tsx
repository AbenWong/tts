import { CategoryChart } from "./CategoryChart";
import { QuarterlyChart } from "./QuarterlyChart";
import { DonutChart } from "./DonutChart";

export function MainVisualizationRow() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Column 1: Quarterly Investment Trend */}
      <div className="lg:col-span-1">
        <QuarterlyChart />
      </div>

      {/* Column 2: Category Chart */}
      <div className="lg:col-span-1">
        <CategoryChart />
      </div>

      {/* Column 3: CTB vs RTB Donut Chart */}
      <div className="lg:col-span-1">
        <DonutChart />
      </div>
    </div>
  );
}
