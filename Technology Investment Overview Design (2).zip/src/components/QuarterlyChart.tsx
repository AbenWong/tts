import { useState } from "react";
import { motion } from "motion/react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";
import { shadows } from "../lib/design-tokens";

const data = [
  { quarter: "Q1", amount: 76 },
  { quarter: "Q2", amount: 86 },
  { quarter: "Q3", amount: 0 },
  { quarter: "Q4", amount: 0 },
];

export function QuarterlyChart() {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3, delay: 0.2 }}
      whileHover={{ boxShadow: shadows.cardHover }}
      className="bg-white rounded-lg p-6 shadow-sm transition-all duration-200"
      style={{ boxShadow: shadows.card }}
    >
      <h2 className="text-[#333333] mb-6">TECH INVESTMENT - 2025 QUARTERLY</h2>
      <ResponsiveContainer width="100%" height={300}>
        <BarChart
          data={data}
          onMouseMove={(state) => {
            if (state.isTooltipActive) {
              setActiveIndex(state.activeTooltipIndex ?? null);
            } else {
              setActiveIndex(null);
            }
          }}
          onMouseLeave={() => setActiveIndex(null)}
        >
          <CartesianGrid strokeDasharray="3 3" stroke="#EDEDED" />
          <XAxis dataKey="quarter" stroke="#767676" />
          <YAxis
            stroke="#767676"
            label={{ value: "m$", angle: -90, position: "insideLeft" }}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: "white",
              border: "1px solid #EDEDED",
              borderRadius: "8px",
              boxShadow: shadows.card,
            }}
            formatter={(value: number) => [`${value}m$`, "Amount"]}
            cursor={{ fill: "rgba(219, 0, 17, 0.1)" }}
          />
          <Bar dataKey="amount" radius={[4, 4, 0, 0]} animationDuration={800}>
            {data.map((entry, index) => (
              <Cell
                key={`cell-${index}`}
                fill={activeIndex === index ? "#A8000B" : "#DB0011"}
                style={{
                  transform: activeIndex === index ? "scaleY(1.02)" : "scaleY(1)",
                  transformOrigin: "bottom",
                  transition: "all 0.2s cubic-bezier(0.4, 0, 0.2, 1)",
                }}
              />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </motion.div>
  );
}
