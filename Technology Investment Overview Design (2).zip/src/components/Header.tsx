import { User } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";

export function Header() {
  return (
    <header className="bg-white border-b border-[#EDEDED]">
      <div className="max-w-[1600px] mx-auto px-6 py-4 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center">
          <svg width="120" height="24" viewBox="0 0 120 24" fill="none">
            <rect x="0" y="0" width="24" height="24" fill="#DB0011"/>
            <rect x="6" y="6" width="12" height="12" fill="white"/>
            <rect x="9" y="9" width="6" height="6" fill="#DB0011"/>
            <text x="32" y="17" fill="#000000" fontFamily="Arial, sans-serif" fontSize="18" fontWeight="bold">HSBC</text>
          </svg>
        </div>

        {/* Center - Title and Filter */}
        <div className="flex items-center gap-4">
          <h1 className="text-[#333333]">Technology Investment & Risk Overview</h1>
          <Select defaultValue="2025-q2">
            <SelectTrigger className="w-[180px] border-[#D7D8D6]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="2025-q2">2025 YTD Q2</SelectItem>
              <SelectItem value="2025-q1">2025 YTD Q1</SelectItem>
              <SelectItem value="2024">2024 Full Year</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* User Icon */}
        <div className="flex items-center">
          <div className="w-10 h-10 rounded-full bg-[#F3F3F3] flex items-center justify-center">
            <User className="w-5 h-5 text-[#333333]" />
          </div>
        </div>
      </div>
    </header>
  );
}
