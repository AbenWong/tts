import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { AlertTriangle, CheckCircle2, XCircle, ChevronDown, ChevronUp, Search } from "lucide-react";
import { shadows } from "../lib/design-tokens";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./ui/table";
import { Badge } from "./ui/badge";

const allRiskData = [
  {
    id: 1,
    name: "KK System",
    category: "Infrastructure",
    status: "Amber",
    rootCause: "Insufficient resources",
    owner: "IT Operations",
  },
  {
    id: 2,
    name: "Data Migration Process",
    category: "Data Management",
    status: "Amber",
    rootCause: "Legacy system compatibility",
    owner: "Data Team",
  },
  {
    id: 3,
    name: "API Response Time",
    category: "Performance",
    status: "Amber",
    rootCause: "Increased transaction volume",
    owner: "Platform Team",
  },
  {
    id: 4,
    name: "Security Patch Management",
    category: "Security",
    status: "Green",
    rootCause: "N/A",
    owner: "Security Team",
  },
  {
    id: 5,
    name: "Backup Recovery Process",
    category: "Operations",
    status: "Green",
    rootCause: "N/A",
    owner: "Operations Team",
  },
  {
    id: 6,
    name: "Network Infrastructure",
    category: "Infrastructure",
    status: "Green",
    rootCause: "N/A",
    owner: "Network Team",
  },
];

type StatusFilter = "All" | "Amber" | "Red" | "Green";
type SortField = "name" | "category" | "status" | "rootCause" | "owner";
type SortDirection = "asc" | "desc";

export function CollapsibleRiskDashboard() {
  const [isExpanded, setIsExpanded] = useState(false);
  const [filterStatus, setFilterStatus] = useState<StatusFilter>("All");
  const [searchTerm, setSearchTerm] = useState("");
  const [sortField, setSortField] = useState<SortField>("name");
  const [sortDirection, setSortDirection] = useState<SortDirection>("asc");
  const [tableDataLoaded, setTableDataLoaded] = useState(false);

  const amberCount = allRiskData.filter((r) => r.status === "Amber").length;
  const redCount = allRiskData.filter((r) => r.status === "Red").length;
  const greenCount = allRiskData.filter((r) => r.status === "Green").length;

  const handleExpand = () => {
    setIsExpanded(!isExpanded);
    if (!tableDataLoaded) {
      // Simulate lazy loading
      setTimeout(() => setTableDataLoaded(true), 300);
    }
  };

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  // Filter and sort data
  let filteredData = allRiskData;

  // Apply status filter
  if (filterStatus !== "All") {
    filteredData = filteredData.filter((item) => item.status === filterStatus);
  }

  // Apply search filter
  if (searchTerm) {
    filteredData = filteredData.filter((item) =>
      item.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }

  // Apply sorting
  filteredData = [...filteredData].sort((a, b) => {
    const aValue = a[sortField].toLowerCase();
    const bValue = b[sortField].toLowerCase();
    if (sortDirection === "asc") {
      return aValue < bValue ? -1 : aValue > bValue ? 1 : 0;
    } else {
      return aValue > bValue ? -1 : aValue < bValue ? 1 : 0;
    }
  });

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.4 }}
      whileHover={{ boxShadow: shadows.cardHover }}
      className="bg-white rounded-lg p-6 shadow-sm transition-all duration-200"
      style={{ boxShadow: shadows.card }}
    >
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-[#333333]">Risk & Security - KRI Status</h2>
        <Button
          onClick={handleExpand}
          variant="outline"
          className="flex items-center gap-2 border-[#D7D8D6] hover:bg-[#F3F3F3]"
        >
          {isExpanded ? "Hide Details" : "View Details"}
          {isExpanded ? (
            <ChevronUp className="w-4 h-4" />
          ) : (
            <ChevronDown className="w-4 h-4" />
          )}
        </Button>
      </div>

      {/* Status Overview - Always Visible */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => setFilterStatus("All")}
          className={`p-4 rounded-lg border-2 transition-all ${
            filterStatus === "All"
              ? "border-[#DB0011] bg-[#FFF5F5]"
              : "border-[#EDEDED] bg-white hover:border-[#D7D8D6]"
          }`}
        >
          <div className="text-xs text-[#767676] mb-1">All KRIs</div>
          <div className="text-[#333333]" style={{ fontSize: "24px", fontWeight: "700" }}>
            {allRiskData.length}
          </div>
        </motion.button>

        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => {
            setFilterStatus("Amber");
            if (!isExpanded) setIsExpanded(true);
          }}
          className={`p-4 rounded-lg border-2 transition-all ${
            filterStatus === "Amber"
              ? "border-[#FFBB33] bg-[#FFF9E6]"
              : "border-[#EDEDED] bg-white hover:border-[#FFBB33]"
          }`}
        >
          <div className="flex items-center gap-2 mb-1">
            <AlertTriangle className="w-4 h-4 text-[#FFBB33]" />
            <span className="text-xs text-[#767676]">Amber</span>
          </div>
          <div className="text-[#FFBB33]" style={{ fontSize: "24px", fontWeight: "700" }}>
            {amberCount}
          </div>
        </motion.button>

        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => {
            setFilterStatus("Red");
            if (!isExpanded) setIsExpanded(true);
          }}
          className={`p-4 rounded-lg border-2 transition-all ${
            filterStatus === "Red"
              ? "border-[#DB0011] bg-[#FFF5F5]"
              : "border-[#EDEDED] bg-white hover:border-[#DB0011]"
          }`}
        >
          <div className="flex items-center gap-2 mb-1">
            <XCircle className="w-4 h-4 text-[#DB0011]" />
            <span className="text-xs text-[#767676]">Red</span>
          </div>
          <div className="text-[#767676]" style={{ fontSize: "24px", fontWeight: "700" }}>
            {redCount}
          </div>
        </motion.button>

        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => {
            setFilterStatus("Green");
            if (!isExpanded) setIsExpanded(true);
          }}
          className={`p-4 rounded-lg border-2 transition-all ${
            filterStatus === "Green"
              ? "border-[#3E701A] bg-[#F0F8EC]"
              : "border-[#EDEDED] bg-white hover:border-[#3E701A]"
          }`}
        >
          <div className="flex items-center gap-2 mb-1">
            <CheckCircle2 className="w-4 h-4 text-[#3E701A]" />
            <span className="text-xs text-[#767676]">Green</span>
          </div>
          <div className="text-[#3E701A]" style={{ fontSize: "24px", fontWeight: "700" }}>
            {greenCount}
          </div>
        </motion.button>
      </div>

      {/* Expandable Table Section */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <div className="mt-6 pt-6 border-t border-[#EDEDED]">
              {/* Search Bar */}
              <div className="mb-4 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-[#767676]" />
                <Input
                  type="text"
                  placeholder="Search by KRI Name..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 border-[#D7D8D6]"
                />
              </div>

              {/* Risk Table */}
              {tableDataLoaded ? (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-[#F3F3F3] hover:bg-[#F3F3F3]">
                        <TableHead
                          className="text-[#333333] cursor-pointer hover:bg-[#EDEDED]"
                          onClick={() => handleSort("name")}
                        >
                          <div className="flex items-center gap-2">
                            KRI Name
                            {sortField === "name" && (
                              <span className="text-xs">{sortDirection === "asc" ? "↑" : "↓"}</span>
                            )}
                          </div>
                        </TableHead>
                        <TableHead
                          className="text-[#333333] cursor-pointer hover:bg-[#EDEDED]"
                          onClick={() => handleSort("rootCause")}
                        >
                          <div className="flex items-center gap-2">
                            Root Cause
                            {sortField === "rootCause" && (
                              <span className="text-xs">{sortDirection === "asc" ? "↑" : "↓"}</span>
                            )}
                          </div>
                        </TableHead>
                        <TableHead
                          className="text-[#333333] text-center cursor-pointer hover:bg-[#EDEDED]"
                          onClick={() => handleSort("status")}
                        >
                          <div className="flex items-center justify-center gap-2">
                            Status
                            {sortField === "status" && (
                              <span className="text-xs">{sortDirection === "asc" ? "↑" : "↓"}</span>
                            )}
                          </div>
                        </TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      <AnimatePresence mode="wait">
                        {filteredData.map((risk, index) => (
                          <motion.tr
                            key={risk.id}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -10 }}
                            transition={{ delay: index * 0.05 }}
                            className={`transition-colors ${
                              index % 2 === 1 ? "bg-[#F3F3F3]" : "bg-white"
                            } hover:bg-[#EDEDED] cursor-pointer`}
                          >
                            <TableCell className="font-medium">{risk.name}</TableCell>
                            <TableCell className="text-sm">{risk.rootCause}</TableCell>
                            <TableCell className="text-center">
                              <div className="flex items-center justify-center gap-2">
                                <div
                                  className={`w-2 h-2 rounded-full ${
                                    risk.status === "Amber"
                                      ? "bg-[#FFBB33]"
                                      : risk.status === "Red"
                                      ? "bg-[#DB0011]"
                                      : "bg-[#3E701A]"
                                  }`}
                                />
                                <Badge
                                  className={`${
                                    risk.status === "Amber"
                                      ? "bg-[#FFF9E6] text-[#FFBB33] border-[#FFBB33]"
                                      : risk.status === "Red"
                                      ? "bg-[#FFF5F5] text-[#DB0011] border-[#DB0011]"
                                      : "bg-[#F0F8EC] text-[#3E701A] border-[#3E701A]"
                                  } border`}
                                >
                                  {risk.status}
                                </Badge>
                              </div>
                            </TableCell>
                          </motion.tr>
                        ))}
                      </AnimatePresence>
                    </TableBody>
                  </Table>

                  {filteredData.length === 0 && (
                    <div className="text-center py-8 text-[#767676]">
                      No KRIs found matching your criteria
                    </div>
                  )}
                </div>
              ) : (
                <div className="flex items-center justify-center py-8">
                  <div className="text-[#767676]">Loading table data...</div>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
