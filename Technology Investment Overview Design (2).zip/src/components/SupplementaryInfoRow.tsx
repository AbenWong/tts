import { BusinessTable } from "./BusinessTable";
import { MobileBankingCard } from "./MobileBankingCard";

export function SupplementaryInfoRow() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <BusinessTable />
      <MobileBankingCard />
    </div>
  );
}
