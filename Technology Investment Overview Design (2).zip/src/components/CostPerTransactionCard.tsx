import { Info, ArrowUp } from "lucide-react";
import { motion } from "motion/react";
import { useCountUp } from "../hooks/useCountUp";
import { useInView } from "../hooks/useInView";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "./ui/tooltip";
import { shadows } from "../lib/design-tokens";

export function CostPerTransactionCard() {
  const { ref, isInView } = useInView({ threshold: 0.3 });
  const animatedValue = useCountUp(isInView ? 9.06 : 0, 1000);

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.4, delay: 0.3 }}
      whileHover={{ boxShadow: shadows.cardHover }}
      className="bg-white rounded-lg p-6 shadow-sm transition-all duration-200"
      style={{ boxShadow: shadows.card }}
    >
      <div className="flex items-start justify-between mb-4">
        <h3 className="text-[#333333]">COST PER TRANSACTION - 2024</h3>
        <TooltipProvider>
          <Tooltip delayDuration={300}>
            <TooltipTrigger>
              <motion.div
                whileHover={{ scale: 1.1, rotate: 15 }}
                transition={{ duration: 0.2 }}
              >
                <Info className="w-4 h-4 text-[#2D6980]" />
              </motion.div>
            </TooltipTrigger>
            <TooltipContent>
              <p className="max-w-[280px]">
                Cost per transaction = Tech Investment 2024 / Transactions HUB
                <br />
                <br />
                Formula: 243,523.15 / 26,873.18 = 9.06 ¥
              </p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>

      <div className="space-y-4">
        <div>
          <div className="text-[#DB0011]" style={{ fontSize: "36px", fontWeight: "700" }}>
            {animatedValue.toFixed(2)} ¥
          </div>
          <div className="flex items-center gap-1 text-[#3E701A] mt-2">
            <ArrowUp className="w-4 h-4" />
            <span className="text-sm">Compared to last year growth +2%</span>
          </div>
        </div>

        <div className="pt-4 border-t border-[#EDEDED] space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs text-[#767676]">Tech investment 2024:</span>
            <span className="text-sm text-[#333333]">243,523.15</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-xs text-[#767676]">Transactions HUB:</span>
            <span className="text-sm text-[#333333]">26,873.18</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
