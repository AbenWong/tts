import { ArrowUp } from "lucide-react";
import { motion } from "motion/react";
import { useCountUp } from "../hooks/useCountUp";
import { useInView } from "../hooks/useInView";
import { shadows } from "../lib/design-tokens";
import { LineChart, Line, ResponsiveContainer } from "recharts";

const trendData = [
  { value: 21500 },
  { value: 21600 },
  { value: 21550 },
  { value: 21700 },
  { value: 21751 },
];

export function MobileBankingCard() {
  const { ref, isInView } = useInView({ threshold: 0.3 });
  const animatedUsers = useCountUp(isInView ? 21751 : 0, 1200);

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.4, delay: 0.3 }}
      whileHover={{ boxShadow: shadows.cardHover }}
      className="bg-white rounded-lg p-6 shadow-sm transition-all duration-200"
      style={{ boxShadow: shadows.card }}
    >
      <h3 className="text-[#333333] mb-4">Mobile Banking Users & Activity (CIB)</h3>

      <div className="space-y-4">
        <div>
          <div className="text-xs text-[#767676] mb-1">July Users</div>
          <div className="text-[#333333]" style={{ fontSize: "28px", fontWeight: "700" }}>
            {Math.floor(animatedUsers).toLocaleString()}
          </div>
        </div>

        <div>
          <div className="text-xs text-[#767676] mb-1">Activity Rate</div>
          <div className="text-[#DB0011]" style={{ fontSize: "28px", fontWeight: "700" }}>
            88.11%
          </div>
        </div>

        <div className="pt-2 border-t border-[#EDEDED]">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-[#767676]">vs Jun 2025</span>
            <div className="flex items-center gap-1 text-[#3E701A]">
              <ArrowUp className="w-3 h-3" />
              <span className="text-sm">+0.1%</span>
            </div>
          </div>

          <ResponsiveContainer width="100%" height={40}>
            <LineChart data={trendData}>
              <Line
                type="monotone"
                dataKey="value"
                stroke="#3E701A"
                strokeWidth={2}
                dot={false}
                animationDuration={1000}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </motion.div>
  );
}
