import { ArrowUp, Info } from "lucide-react";
import { motion } from "motion/react";
import { useCountUp } from "../../hooks/useCountUp";
import { useInView } from "../../hooks/useInView";
import { shadows } from "../../lib/design-tokens";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "../ui/tooltip";

export function StaffComposition() {
  const { ref, isInView } = useInView({ threshold: 0.3 });
  const totalStaff = useCountUp(isInView ? 401 : 0, 1000);
  const permStaff = useCountUp(isInView ? 138 : 0, 1000);
  const nonPermStaff = useCountUp(isInView ? 263 : 0, 1000);

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.5 }}
      whileHover={{ boxShadow: shadows.cardHover }}
      className="bg-white rounded-lg p-6 shadow-sm transition-all duration-200"
      style={{ boxShadow: shadows.card }}
    >
      <h3 className="text-[#333333] mb-6">Employee Composition Analysis</h3>

      {/* Total Staff */}
      <div className="mb-6 pb-6 border-b border-[#EDEDED]">
        <div className="flex items-center justify-between mb-2">
          <div className="text-xs text-[#767676]">Total Staff (2025 Aug)</div>
          <TooltipProvider>
            <Tooltip delayDuration={300}>
              <TooltipTrigger>
                <Info className="w-4 h-4 text-[#2D6980]" />
              </TooltipTrigger>
              <TooltipContent>
                <p>Perm: 138 + Non-Perm: 263 = 401</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
        <div className="text-[#DB0011]" style={{ fontSize: "32px", fontWeight: "700" }}>
          {Math.floor(totalStaff)}
        </div>
        <div className="flex items-center gap-1 text-[#3E701A] mt-2">
          <ArrowUp className="w-4 h-4" />
          <span className="text-sm">MoM Growth +0.5%</span>
        </div>
      </div>

      {/* Perm Staff */}
      <div className="mb-6">
        <div className="mb-3">
          <div className="text-sm text-[#333333] mb-1">{Math.floor(permStaff)} staff</div>
          <div className="text-xs text-[#767676]">34.4% of total bank staff</div>
          <div className="flex items-center gap-1 text-[#3E701A] mt-1">
            <ArrowUp className="w-3 h-3" />
            <span className="text-xs">MoM Growth +0.5%</span>
          </div>
        </div>

        <div className="space-y-2">
          <div className="text-xs text-[#767676] mb-2">Gender Ratio</div>
          
          {/* Male */}
          <div className="flex items-center gap-3">
            <div className="flex-1">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs text-[#767676]">Male</span>
                <span className="text-xs">95 (68.8%)</span>
              </div>
              <div className="h-2 bg-[#F3F3F3] rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-[#2D6980]"
                  initial={{ width: 0 }}
                  animate={isInView ? { width: "68.8%" } : {}}
                  transition={{ duration: 0.8, delay: 0.7 }}
                />
              </div>
            </div>
          </div>

          {/* Female */}
          <div className="flex items-center gap-3">
            <div className="flex-1">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs text-[#767676]">Female</span>
                <span className="text-xs">43 (31.2%)</span>
              </div>
              <div className="h-2 bg-[#F3F3F3] rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-[#E26F98]"
                  initial={{ width: 0 }}
                  animate={isInView ? { width: "31.2%" } : {}}
                  transition={{ duration: 0.8, delay: 0.8 }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Non-Perm Staff */}
      <div className="pt-6 border-t border-[#EDEDED]">
        <div className="text-sm text-[#333333] mb-1">{Math.floor(nonPermStaff)} staff</div>
        <div className="text-xs text-[#767676]">65.5% of total</div>
        <div className="flex items-center gap-1 text-[#3E701A] mt-1">
          <ArrowUp className="w-3 h-3" />
          <span className="text-xs">YoY Growth +0.5%</span>
        </div>
      </div>
    </motion.div>
  );
}
