import { motion } from "motion/react";
import { TrendingDown } from "lucide-react";
import { shadows } from "../../lib/design-tokens";
import { LineChart, Line, ResponsiveContainer } from "recharts";

const trendData = [
  { value: 3 },
  { value: 2 },
  { value: 1 },
  { value: 2 },
  { value: 0 },
];

export function AttritionAnalysis() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.7 }}
      whileHover={{ boxShadow: shadows.cardHover }}
      className="bg-white rounded-lg p-6 shadow-sm transition-all duration-200"
      style={{ boxShadow: shadows.card }}
    >
      <h3 className="text-[#333333] mb-6">Attrition Rate Analysis</h3>

      {/* General Attrition */}
      <div className="mb-6 pb-6 border-b border-[#EDEDED]">
        <div className="text-sm text-[#767676] mb-3">General Attrition Rate</div>
        
        <div className="flex items-baseline gap-2 mb-2">
          <div className="text-[#3E701A]" style={{ fontSize: "32px", fontWeight: "700" }}>
            0
          </div>
          <span className="text-sm text-[#767676]">staff</span>
        </div>
        
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs text-[#767676]">0% of total</span>
          
          {/* YTD Emphasized */}
          <motion.div
            className="px-3 py-1 rounded-md bg-[#FFF5F5]"
            whileHover={{ scale: 1.05 }}
          >
            <span className="text-xs text-[#767676] mr-1">YTD:</span>
            <span className="text-[#DB0011]" style={{ fontSize: "18px", fontWeight: "700" }}>
              2
            </span>
          </motion.div>
        </div>

        <ResponsiveContainer width="100%" height={40}>
          <LineChart data={trendData}>
            <Line
              type="monotone"
              dataKey="value"
              stroke="#3E701A"
              strokeWidth={2}
              dot={false}
              animationDuration={1000}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* High Performance Attrition */}
      <div>
        <div className="text-sm text-[#767676] mb-3">High Performance Attrition Rate</div>
        
        <div className="flex items-baseline gap-2 mb-2">
          <div className="text-[#3E701A]" style={{ fontSize: "32px", fontWeight: "700" }}>
            0
          </div>
          <span className="text-sm text-[#767676]">staff</span>
        </div>
        
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs text-[#767676]">0% of total</span>
          
          {/* YTD Emphasized */}
          <motion.div
            className="px-3 py-1 rounded-md bg-[#FFF5F5]"
            whileHover={{ scale: 1.05 }}
          >
            <span className="text-xs text-[#767676] mr-1">YTD:</span>
            <span className="text-[#DB0011]" style={{ fontSize: "18px", fontWeight: "700" }}>
              2
            </span>
          </motion.div>
        </div>

        <div className="flex items-center gap-2 p-3 bg-[#F0F8EC] rounded-lg mt-4">
          <TrendingDown className="w-4 h-4 text-[#3E701A]" />
          <span className="text-xs text-[#3E701A]">Excellent retention rate</span>
        </div>
      </div>
    </motion.div>
  );
}
