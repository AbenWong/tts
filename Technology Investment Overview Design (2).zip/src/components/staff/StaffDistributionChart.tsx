import { useState } from "react";
import { motion } from "motion/react";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip, Sector } from "recharts";
import { shadows } from "../../lib/design-tokens";

const data = [
  { name: "Perm", value: 138, color: "#DB0011" },
  { name: "Non-Perm Tech", value: 195, color: "#347893" },
  { name: "Non-Perm CMC", value: 68, color: "#4C7C27" },
];

const renderActiveShape = (props: any) => {
  const { cx, cy, innerRadius, outerRadius, startAngle, endAngle, fill } = props;

  return (
    <g>
      <Sector
        cx={cx}
        cy={cy}
        innerRadius={innerRadius}
        outerRadius={outerRadius + 10}
        startAngle={startAngle}
        endAngle={endAngle}
        fill={fill}
      />
    </g>
  );
};

export function StaffDistributionChart() {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.6 }}
      whileHover={{ boxShadow: shadows.cardHover }}
      className="bg-white rounded-lg p-6 shadow-sm transition-all duration-200"
      style={{ boxShadow: shadows.card }}
    >
      <h3 className="text-[#333333] mb-4">Employee Type Distribution</h3>
      
      <ResponsiveContainer width="100%" height={300}>
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={90}
            paddingAngle={3}
            dataKey="value"
            onMouseEnter={(_, index) => setActiveIndex(index)}
            onMouseLeave={() => setActiveIndex(null)}
            activeIndex={activeIndex ?? undefined}
            activeShape={renderActiveShape}
            animationDuration={1000}
          >
            {data.map((entry, index) => (
              <Cell
                key={`cell-${index}`}
                fill={entry.color}
                style={{
                  filter: activeIndex === index ? "brightness(1.1)" : "brightness(1)",
                  transition: "filter 0.2s",
                  cursor: "pointer",
                }}
              />
            ))}
          </Pie>
          <Tooltip
            formatter={(value: number) => [value, "Staff"]}
            contentStyle={{
              backgroundColor: "white",
              border: "1px solid #EDEDED",
              borderRadius: "8px",
              boxShadow: shadows.card,
            }}
          />
          <Legend
            verticalAlign="bottom"
            formatter={(value, entry: any) => `${value}: ${entry.payload.value}`}
            wrapperStyle={{ paddingTop: "20px" }}
          />
          <text
            x="50%"
            y="50%"
            textAnchor="middle"
            dominantBaseline="middle"
            style={{ fontSize: "24px", fontWeight: "700", fill: "#333333" }}
          >
            401
          </text>
          <text
            x="50%"
            y="55%"
            textAnchor="middle"
            dominantBaseline="middle"
            style={{ fontSize: "12px", fill: "#767676" }}
          >
            Total
          </text>
        </PieChart>
      </ResponsiveContainer>
    </motion.div>
  );
}
