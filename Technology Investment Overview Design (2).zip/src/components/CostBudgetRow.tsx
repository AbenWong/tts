import { CostPerTransactionCard } from "./CostPerTransactionCard";
import { BudgetCard } from "./BudgetCard";

export function CostBudgetRow() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <CostPerTransactionCard />
      <BudgetCard />
    </div>
  );
}
