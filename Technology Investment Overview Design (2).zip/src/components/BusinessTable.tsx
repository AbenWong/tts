import { motion } from "motion/react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./ui/table";
import { shadows } from "../lib/design-tokens";

const data = [
  { channel: "IWPB", online: "66.8%", digital: "58.9%" },
  { channel: "CIB", online: "24.24%", digital: "88.11%" },
  { channel: "MSS", online: "90%", digital: "100%" },
];

export function BusinessTable() {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.4, delay: 0.3 }}
      whileHover={{ boxShadow: shadows.cardHover }}
      className="bg-white rounded-lg p-6 shadow-sm transition-all duration-200"
      style={{ boxShadow: shadows.card }}
    >
      <h2 className="text-[#333333] mb-6">Online & Digital Business Proportion</h2>
      <Table>
        <TableHeader>
          <TableRow className="bg-[#F3F3F3] hover:bg-[#F3F3F3]">
            <TableHead className="text-[#333333]">Revenue Channel</TableHead>
            <TableHead className="text-[#333333]">Online%</TableHead>
            <TableHead className="text-[#333333]">Digital%</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {data.map((row, index) => (
            <motion.tr
              key={row.channel}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 + index * 0.1 }}
              className={`transition-colors duration-200 ${
                index % 2 === 1 ? "bg-[#F3F3F3]" : ""
              } hover:bg-[#EDEDED] cursor-pointer`}
            >
              <TableCell>{row.channel}</TableCell>
              <TableCell>{row.online}</TableCell>
              <TableCell>{row.digital}</TableCell>
            </motion.tr>
          ))}
        </TableBody>
      </Table>
    </motion.div>
  );
}
