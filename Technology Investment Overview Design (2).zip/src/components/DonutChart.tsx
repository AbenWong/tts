import { useState } from "react";
import { motion } from "motion/react";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip, Sector } from "recharts";
import { shadows } from "../lib/design-tokens";

const data = [
  { name: "CTB", value: 0.62, percentage: 62 },
  { name: "RTB", value: 0.38, percentage: 38 },
];

const COLORS = ["#DB0011", "#767676"];

const renderActiveShape = (props: any) => {
  const { cx, cy, innerRadius, outerRadius, startAngle, endAngle, fill } = props;

  return (
    <g>
      <Sector
        cx={cx}
        cy={cy}
        innerRadius={innerRadius}
        outerRadius={outerRadius + 8}
        startAngle={startAngle}
        endAngle={endAngle}
        fill={fill}
      />
    </g>
  );
};

export function DonutChart() {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3, delay: 0.5 }}
      whileHover={{ boxShadow: shadows.cardHover }}
      className="bg-white rounded-lg p-6 shadow-sm transition-all duration-200"
      style={{ boxShadow: shadows.card }}
    >
      <h2 className="text-[#333333] mb-4">TECH INVESTMENT CTB VS. RTB 2025 YTD(Q2)</h2>
      <ResponsiveContainer width="100%" height={280}>
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={50}
            outerRadius={80}
            paddingAngle={2}
            dataKey="value"
            onMouseEnter={(_, index) => setActiveIndex(index)}
            onMouseLeave={() => setActiveIndex(null)}
            activeIndex={activeIndex ?? undefined}
            activeShape={renderActiveShape}
            animationDuration={800}
          >
            {data.map((entry, index) => (
              <Cell
                key={`cell-${index}`}
                fill={COLORS[index]}
                style={{
                  filter:
                    activeIndex === index ? "brightness(1.1)" : "brightness(1)",
                  transition: "filter 0.2s",
                }}
              />
            ))}
          </Pie>
          <Tooltip
            formatter={(value: number) => `${value}m$`}
            contentStyle={{
              backgroundColor: "white",
              border: "1px solid #EDEDED",
              borderRadius: "8px",
              boxShadow: shadows.card,
            }}
          />
          <Legend
            formatter={(value, entry: any) =>
              `${value}: ${entry.payload.value}m$ (${entry.payload.percentage}%)`
            }
            verticalAlign="bottom"
          />
          <text
            x="50%"
            y="50%"
            textAnchor="middle"
            dominantBaseline="middle"
            style={{ fontSize: "20px", fontWeight: "700", fill: "#333333" }}
          >
            1.0m$
          </text>
        </PieChart>
      </ResponsiveContainer>
    </motion.div>
  );
}
