import { StaffComposition } from "./staff/StaffComposition";
import { StaffDistributionChart } from "./staff/StaffDistributionChart";
import { AttritionAnalysis } from "./staff/AttritionAnalysis";

export function StaffOverview() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <StaffComposition />
      <StaffDistributionChart />
      <AttritionAnalysis />
    </div>
  );
}
