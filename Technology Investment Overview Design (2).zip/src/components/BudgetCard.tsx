import { motion } from "motion/react";
import { useInView } from "../hooks/useInView";
import { Progress } from "./ui/progress";
import { shadows } from "../lib/design-tokens";

const budgetData = [
  { type: "CTB", budget: 50, actual: 49, achievement: 98 },
  { type: "RTB", budget: 30, actual: 29, achievement: 96.7 },
  { type: "Total", budget: 80, actual: 78, achievement: 97.5 },
];

export function BudgetCard() {
  const { ref, isInView } = useInView({ threshold: 0.3 });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3, delay: 0.6 }}
      whileHover={{ boxShadow: shadows.cardHover }}
      className="bg-white rounded-lg p-6 shadow-sm transition-all duration-200"
      style={{ boxShadow: shadows.card }}
    >
      <h3 className="text-[#333333] mb-4">IT Budget & Achievement Rate - 2025 YTD</h3>

      <div className="space-y-6">
        {budgetData.map((item, index) => (
          <motion.div
            key={item.type}
            initial={{ opacity: 0, x: -20 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ delay: 0.7 + index * 0.1 }}
            className="space-y-2"
          >
            <div className="flex justify-between items-baseline">
              <span className="text-sm text-[#333333]">{item.type}</span>
              <motion.span
                className="text-xs text-[#3E701A]"
                initial={{ opacity: 0 }}
                animate={isInView ? { opacity: 1 } : {}}
                transition={{ delay: 1 + index * 0.1 }}
              >
                {item.achievement}%
              </motion.span>
            </div>

            <Progress
              value={isInView ? item.achievement : 0}
              className="h-2"
              style={{
                transition: "all 0.8s cubic-bezier(0.4, 0, 0.2, 1)",
              }}
            />

            <div className="flex justify-between text-xs text-[#767676]">
              <span>Budget: {item.budget}m$</span>
              <span>Actual: {item.actual}m$</span>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
