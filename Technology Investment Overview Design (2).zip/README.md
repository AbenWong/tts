
  # Technology Investment Overview Design

  This is a code bundle for Technology Investment Overview Design. The original project is available at https://www.figma.com/design/WpO9qQDAWgxuPJ83nbXSrH/Technology-Investment-Overview-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  